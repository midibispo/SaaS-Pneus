
import { Role, Tire, TireCondition, TireStatus, User, Vehicle, Tenant, Brand, Supplier, Customer, Plan, Company, Collaborator, MaintenanceRecord, MaintenanceType, AxleDef, VehicleCategory, AlertRule, AxleRole } from '../types';

export const MOCK_USERS: User[] = [
  {
    id: '1',
    name: 'Roberto Admin',
    role: Role.ADMIN,
    avatar: 'https://i.pravatar.cc/150?u=1',
    tenantId: 't1'
  },
  {
    id: '2',
    name: 'Carlos Mecânico',
    role: Role.MECHANIC,
    avatar: 'https://i.pravatar.cc/150?u=2',
    tenantId: 't1'
  },
  {
    id: '3',
    name: 'Ana Auditora',
    role: Role.AUDITOR,
    avatar: 'https://i.pravatar.cc/150?u=3',
    tenantId: 't1'
  },
  {
    id: '4',
    name: 'Super Admin',
    role: Role.SUPER_ADMIN,
    avatar: 'https://i.pravatar.cc/150?u=4'
  }
];

export const MOCK_COMPANY: Company = {
  id: 'comp1',
  name: 'Transportadora Global Ltda',
  fantasyName: 'Global Transportes',
  cnpj: '12.345.678/0001-90',
  responsibleName: 'Roberto Almeida',
  responsibleEmail: 'roberto@globaltransp.com.br',
  phone: '(11) 3030-4040',
  address: {
    street: 'Av. das Nações Unidas',
    number: '1000',
    complement: 'Galpão 5',
    district: 'Vila Leopoldina',
    city: 'São Paulo',
    state: 'SP',
    zipCode: '05310-000'
  }
};

export const MOCK_COLLABORATORS: Collaborator[] = [
  {
    id: 'col1',
    name: 'Roberto Admin',
    cpf: '111.222.333-44',
    email: 'roberto@globaltransp.com.br',
    phone: '(11) 99999-1111',
    role: Role.ADMIN,
    admissionDate: '2022-01-10',
    active: true,
    notes: 'Gerente geral da frota.'
  },
  {
    id: 'col2',
    name: 'Carlos Mecânico',
    cpf: '222.333.444-55',
    email: 'carlos@globaltransp.com.br',
    phone: '(11) 98888-2222',
    role: Role.MECHANIC,
    admissionDate: '2023-05-15',
    active: true
  },
  {
    id: 'col3',
    name: 'Ana Auditora',
    cpf: '333.444.555-66',
    email: 'ana@auditoria.com',
    phone: '(11) 97777-3333',
    role: Role.AUDITOR,
    admissionDate: '2023-11-01',
    active: true
  },
  {
    id: 'col4',
    name: 'João Ex-Funcionário',
    cpf: '444.555.666-77',
    email: 'joao.antigo@email.com',
    phone: '(11) 90000-0000',
    role: Role.MECHANIC,
    admissionDate: '2021-02-01',
    resignationDate: '2023-12-01',
    active: false,
    notes: 'Saiu por motivos pessoais.'
  }
];

export const MOCK_TENANTS: Tenant[] = [
  {
    id: 't1',
    name: 'Transportadora Global Ltda',
    fantasyName: 'Global Transportes',
    document: '12.345.678/0001-90',
    address: {
        street: 'Av. Brasil',
        number: '100',
        district: 'Industrial',
        state: 'SP',
        zipCode: '01000-000'
    },
    contactName: 'Roberto Almeida',
    phone: '(11) 99999-8888',
    email: 'roberto@global.com',
    plan: 'Plano Pro',
    status: 'Active',
    expiresAt: '2024-12-31',
    assetLimit: 100,
    currentAssets: 45
  },
  {
    id: 't2',
    name: 'Logística Rápida SA',
    fantasyName: 'Rapida Log',
    document: '98.765.432/0001-10',
    address: {
        street: 'Rua das Flores',
        number: '500',
        district: 'Centro',
        state: 'RJ',
        zipCode: '20000-000'
    },
    contactName: 'Maria Souza',
    phone: '(21) 98888-7777',
    email: 'maria@lograpida.com',
    plan: 'Plano Basic',
    status: 'Expired',
    expiresAt: '2023-11-20',
    assetLimit: 20,
    currentAssets: 18
  }
];

export const MOCK_PLANS: Plan[] = [
  {
    id: 'p1',
    name: 'Plano Basic',
    price: 199.90,
    frequency: 'MONTHLY',
    assetLimit: 5,
    active: true,
    description: 'Ideal para pequenos transportadores autônomos.'
  },
  {
    id: 'p2',
    name: 'Plano Pro',
    price: 499.90,
    frequency: 'MONTHLY',
    assetLimit: 20,
    active: true,
    description: 'Para frotas médias em crescimento.'
  },
  {
    id: 'p3',
    name: 'Plano Enterprise',
    price: 999.90,
    frequency: 'MONTHLY',
    assetLimit: 100,
    active: true,
    description: 'Gestão completa para grandes transportadoras.'
  },
  {
    id: 'p4',
    name: 'Plano Anual Corporativo',
    price: 9990.00,
    frequency: 'YEARLY',
    assetLimit: 200,
    active: true,
    description: 'Economia e controle anual para grandes operações.'
  }
];

// Helper to generate IDs
let brandIdCounter = 1;
const createBrand = (name: string, type: 'TIRE' | 'VEHICLE' | 'RETREAD' | 'RETREADER'): Brand => ({
  id: `b${brandIdCounter++}`,
  name,
  type,
  active: true,
  // Add mock data for RETREADER if type matches
  ...(type === 'RETREADER' ? {
      fantasyName: name.split(' ')[0] + ' Recapagens',
      cnpj: '00.000.000/0001-99',
      contactName: 'Gerente Técnico',
      phone: '(11) 98888-0000',
      email: 'contato@recapadora.com',
      street: 'Rua das Indústrias',
      number: '500',
      district: 'Distrito Industrial',
      state: 'SP',
      zipCode: '04000-000'
  } : {})
});

const TIRE_BRANDS_LIST = [
  "Dunlop", "Goodyear", "Michelin", "Pirelli", "Bridgestone", "Continental",
  "Firestone", "Yokohama", "GT Radial", "Westlake", "Aeolus", "Goodride",
  "LingLong", "Hankook", "Levorin", "Maggion", "Drebor", "Fate", "Sumitomo", "Toyo"
];

const VEHICLE_BRANDS_LIST = [
  "Volkswagen / MAN", 
  "Ford", 
  "Mercedes-Benz", 
  "Volvo", 
  "Scania", 
  "Iveco", 
  "DAF",
  "Hyundai", 
  "International", 
  "Agrale", 
  "Foton", 
  "Shacman", 
  "Sinotruk (CNHTC)",
  "Effa Motors", 
  "JAC Motors", 
  "BYD", 
  "Kamaz", 
  "Mack Trucks", 
  "Kenworth", 
  "Peterbilt", 
  "Freightliner", 
  "Hino", 
  "Tata Motors",
  "Marcopolo", "Comil", "Caio" 
];

const RETREAD_BRANDS_LIST = [
  "Vipal", "Bandag", "Tipler", "Moreflex", "Marangoni", "Blackline", "Rexxon", "RecMix", "Silvercap", "Kraiburg"
];

const RETREADER_SHOPS_LIST = [
  "Recapadora Silva", "Recapadora Pneus Fortes", "Renova Pneus", "Recapadora Central"
];

export const MOCK_BRANDS: Brand[] = [
  ...TIRE_BRANDS_LIST.map(name => createBrand(name, 'TIRE')),
  ...VEHICLE_BRANDS_LIST.map(name => createBrand(name, 'VEHICLE')),
  ...RETREAD_BRANDS_LIST.map(name => createBrand(name, 'RETREAD')),
  ...RETREADER_SHOPS_LIST.map(name => createBrand(name, 'RETREADER')),
];

export const MOCK_SUPPLIERS: Supplier[] = [
  {
    id: 's1',
    name: 'Pneus e Cia Ltda',
    fantasyName: 'Pneus & Cia',
    cnpj: '12.345.678/0001-90',
    contactName: 'João Silva',
    phone: '(11) 98765-4321',
    email: 'vendas@pneusecia.com.br',
    active: true,
    street: 'Av. do Estado',
    number: '1000',
    district: 'Centro',
    state: 'SP',
    zipCode: '01010-000'
  },
  {
    id: 's2',
    name: 'Distribuidora Nacional SA',
    fantasyName: 'Dist. Nacional',
    cnpj: '98.765.432/0001-10',
    contactName: 'Maria Souza',
    phone: '(11) 91234-5678',
    email: 'contato@distnacional.com.br',
    active: true,
    street: 'Rodovia Anhanguera',
    number: 'km 15',
    district: 'Industrial',
    state: 'SP',
    zipCode: '05000-100'
  }
];

export const GLOBAL_VEHICLE_TYPES: Record<VehicleCategory, string[]> = {
  TRUCK: ["Toco (4x2)", "Truck (6x2)", "Bitruck (8x2)", "Cavalo Mecânico (4x2)", "Cavalo Mecânico (6x2)", "Cavalo Mecânico (6x4)"],
  TRAILER: ["Carreta 2 Eixos", "Carreta 3 Eixos (Vanderléia)", "Carreta 3 Eixos (LS)", "Bitrem", "Rodotrem"],
  BUS: ["Ônibus Urbano (4x2)", "Ônibus Rodoviário (6x2)", "Articulado"]
};

export const GLOBAL_VEHICLE_MODELS: Record<string, string[]> = {
  "Volkswagen / MAN": ["VW 24.280", "VW 26.280", "VW 31.280", "Meteor", "Constellation"],
  "Ford": ["Cargo 1119", "Cargo 2429", "Cargo 816", "F-4000"],
  "Mercedes-Benz": ["Accelo 1016", "Atego 2426", "Axor 2544", "Actros 2651"],
  "Volvo": ["FH 460", "FH 540", "VM 270", "VM 330"],
  "Scania": ["R 450", "R 500", "P 320", "P 360"],
  "Iveco": ["Tector 240E28", "Stralis 600S44", "Daily 35S14"],
  "DAF": ["XF 105", "XF 530", "CF 85"],
  "Marcopolo": ["Paradiso G7", "Paradiso G8", "Viaggio", "Torino"],
  "Comil": ["Campione", "Invictus", "Svelto"],
  "Caio": ["Apache Vip", "Millennium"]
};

export const VEHICLE_LAYOUTS: Record<string, AxleDef[]> = {
  "Toco (4x2)": [
    { isDual: false, role: 'STEER' },
    { isDual: true, role: 'DRIVE' }
  ],
  "Truck (6x2)": [
    { isDual: false, role: 'STEER' },
    { isDual: true, role: 'DRIVE' },
    { isDual: true, role: 'AUX' }
  ],
  "Bitruck (8x2)": [
    { isDual: false, role: 'STEER' },
    { isDual: false, role: 'STEER' },
    { isDual: true, role: 'DRIVE' },
    { isDual: true, role: 'AUX' }
  ],
  "Cavalo Mecânico (4x2)": [
     { isDual: false, role: 'STEER' },
     { isDual: true, role: 'DRIVE' }
  ],
  "Cavalo Mecânico (6x2)": [
    { isDual: false, role: 'STEER' },
    { isDual: true, role: 'DRIVE' },
    { isDual: true, role: 'AUX' }
  ],
  "Cavalo Mecânico (6x4)": [
    { isDual: false, role: 'STEER' },
    { isDual: true, role: 'DRIVE' },
    { isDual: true, role: 'DRIVE' }
  ],
  "Carreta 2 Eixos": [
    { isDual: true, role: 'TRAILER' },
    { isDual: true, role: 'TRAILER' }
  ],
  "Carreta 3 Eixos (LS)": [
    { isDual: true, role: 'TRAILER' },
    { isDual: true, role: 'TRAILER' },
    { isDual: true, role: 'TRAILER' }
  ],
  "Carreta 3 Eixos (Vanderléia)": [
    { isDual: true, role: 'TRAILER' },
    { isDual: true, role: 'TRAILER' },
    { isDual: true, role: 'TRAILER' }
  ],
   "Ônibus Urbano (4x2)": [
    { isDual: false, role: 'STEER' },
    { isDual: true, role: 'DRIVE' }
  ],
  "Ônibus Rodoviário (6x2)": [
    { isDual: false, role: 'STEER' },
    { isDual: true, role: 'DRIVE' },
    { isDual: false, role: 'AUX' }
  ],
  "Articulado": [
    { isDual: false, role: 'STEER' },
    { isDual: true, role: 'AUX' },
    { isDual: true, role: 'DRIVE' }
  ]
};

export const MOCK_VEHICLES: Vehicle[] = [
  { id: 'v1', plate: 'ABC-1234', category: 'TRUCK', type: 'Truck (6x2)', model: 'Constellation 24.280', brand: 'Volkswagen / MAN', odometer: 150000, status: 'ACTIVE', implement: 'Baú' },
  { id: 'v2', plate: 'XYZ-9876', category: 'TRUCK', type: 'Toco (4x2)', model: 'Cargo 1119', brand: 'Ford', odometer: 80000, status: 'ACTIVE', implement: 'Sider' },
  { id: 'v3', plate: 'DEF-5678', category: 'BUS', type: 'Ônibus Rodoviário (6x2)', model: 'Paradiso G7', brand: 'Marcopolo', odometer: 200000, status: 'MAINTENANCE' },
  { id: 'v4', plate: 'GHI-4321', category: 'TRAILER', type: 'Carreta 3 Eixos (LS)', model: 'Graneleira', brand: 'Randon', odometer: 50000, status: 'ACTIVE' },
];

export const MOCK_TIRES: Tire[] = [
    // Veículo v1 (Truck 6x2 = 2 (Steer) + 4 (Drive) + 4 (Aux) = 10 pneus)
    { id: 't1', serialNumber: '1001', brand: 'Michelin', model: 'X Multi Z', size: '295/80R22.5', status: TireStatus.INSTALLED, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 14, originalDepth: 16, currentPressure: 110, accumulatedMileage: 20000, location: 'ABC-1234', vehicleId: 'v1', position: '1L', purchaseDate: '2023-01-01', purchaseCost: 2500 },
    { id: 't2', serialNumber: '1002', brand: 'Michelin', model: 'X Multi Z', size: '295/80R22.5', status: TireStatus.INSTALLED, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 14, originalDepth: 16, currentPressure: 110, accumulatedMileage: 20000, location: 'ABC-1234', vehicleId: 'v1', position: '1R', purchaseDate: '2023-01-01', purchaseCost: 2500 },
    { id: 't3', serialNumber: '1003', brand: 'Bridgestone', model: 'R268', size: '295/80R22.5', status: TireStatus.INSTALLED, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 15, originalDepth: 17, currentPressure: 100, accumulatedMileage: 10000, location: 'ABC-1234', vehicleId: 'v1', position: '2L-OUT', purchaseDate: '2023-06-01', purchaseCost: 2300 },
    { id: 't4', serialNumber: '1004', brand: 'Bridgestone', model: 'R268', size: '295/80R22.5', status: TireStatus.INSTALLED, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 15, originalDepth: 17, currentPressure: 100, accumulatedMileage: 10000, location: 'ABC-1234', vehicleId: 'v1', position: '2L-IN', purchaseDate: '2023-06-01', purchaseCost: 2300 },
    { id: 't5', serialNumber: '1005', brand: 'Bridgestone', model: 'R268', size: '295/80R22.5', status: TireStatus.INSTALLED, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 15, originalDepth: 17, currentPressure: 100, accumulatedMileage: 10000, location: 'ABC-1234', vehicleId: 'v1', position: '2R-IN', purchaseDate: '2023-06-01', purchaseCost: 2300 },
    { id: 't6', serialNumber: '1006', brand: 'Bridgestone', model: 'R268', size: '295/80R22.5', status: TireStatus.INSTALLED, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 15, originalDepth: 17, currentPressure: 100, accumulatedMileage: 10000, location: 'ABC-1234', vehicleId: 'v1', position: '2R-OUT', purchaseDate: '2023-06-01', purchaseCost: 2300 },
    { id: 't7', serialNumber: '1007', brand: 'Continental', model: 'ContiHybrid', size: '295/80R22.5', status: TireStatus.INSTALLED, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 16, originalDepth: 16, currentPressure: 100, accumulatedMileage: 5000, location: 'ABC-1234', vehicleId: 'v1', position: '3L-OUT', purchaseDate: '2023-09-01', purchaseCost: 2200 },
    { id: 't8', serialNumber: '1008', brand: 'Continental', model: 'ContiHybrid', size: '295/80R22.5', status: TireStatus.INSTALLED, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 16, originalDepth: 16, currentPressure: 100, accumulatedMileage: 5000, location: 'ABC-1234', vehicleId: 'v1', position: '3L-IN', purchaseDate: '2023-09-01', purchaseCost: 2200 },
    { id: 't9', serialNumber: '1009', brand: 'Continental', model: 'ContiHybrid', size: '295/80R22.5', status: TireStatus.INSTALLED, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 16, originalDepth: 16, currentPressure: 100, accumulatedMileage: 5000, location: 'ABC-1234', vehicleId: 'v1', position: '3R-IN', purchaseDate: '2023-09-01', purchaseCost: 2200 },
    { id: 't9b', serialNumber: '1010', brand: 'Continental', model: 'ContiHybrid', size: '295/80R22.5', status: TireStatus.INSTALLED, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 16, originalDepth: 16, currentPressure: 100, accumulatedMileage: 5000, location: 'ABC-1234', vehicleId: 'v1', position: '3R-OUT', purchaseDate: '2023-09-01', purchaseCost: 2200 },
    
    // Estoque
    { id: 't10', serialNumber: '2001', brand: 'Goodyear', model: 'KMax S', size: '295/80R22.5', status: TireStatus.STOCK, condition: TireCondition.NEW, lifeCount: 0, currentDepth: 16, originalDepth: 16, currentPressure: 0, accumulatedMileage: 0, location: 'Estoque', purchaseDate: '2024-01-15', purchaseCost: 2400 },
    { id: 't11', serialNumber: '2002', brand: 'Continental', model: 'HSR2', size: '295/80R22.5', status: TireStatus.STOCK, condition: TireCondition.RETREADED, lifeCount: 1, currentDepth: 12, originalDepth: 12, currentPressure: 0, accumulatedMileage: 80000, location: 'Estoque', purchaseDate: '2022-01-01', purchaseCost: 1800, treadBrand: 'Vipal', retreader: 'Recapadora Silva', retreadCost: 600 },
    
    // Recapagem
    { id: 't12', serialNumber: '3001', brand: 'Dunlop', model: 'SP320', size: '295/80R22.5', status: TireStatus.AWAITING_RETREAD, condition: TireCondition.USED, lifeCount: 0, currentDepth: 3, originalDepth: 16, currentPressure: 0, accumulatedMileage: 60000, location: 'Recapadora Silva', retreadSendDate: '2024-02-01', purchaseDate: '2022-06-01', purchaseCost: 2100 },

    // Sucata
    { id: 't13', serialNumber: '4001', brand: 'Pirelli', model: 'FR85', size: '295/80R22.5', status: TireStatus.SCRAP, condition: TireCondition.USED, lifeCount: 2, currentDepth: 0, originalDepth: 16, currentPressure: 0, accumulatedMileage: 150000, location: 'Sucata', purchaseDate: '2020-01-01', purchaseCost: 2000 }
];

export const MOCK_CUSTOMERS: Customer[] = [
  { id: 'c1', name: 'Supermercados ABC', document: '11.222.333/0001-44', contactName: 'Mário Gerente', phone: '(11) 3333-4444', email: 'compras@abc.com', active: true, address: 'Rua das Compras, 100' },
  { id: 'c2', name: 'Indústria Metalúrgica XYZ', document: '55.666.777/0001-88', contactName: 'Eng. Paula', phone: '(11) 5555-6666', email: 'logistica@xyz.com', active: true, address: 'Av. Industrial, 2000' }
];

export const MOCK_MAINTENANCE: MaintenanceRecord[] = [
  { id: 'm1', tireId: '1001', vehicleId: 'v1', date: '2023-01-05', type: MaintenanceType.MOUNT, cost: 50, odometer: 130000, description: 'Montagem inicial', performedBy: 'Carlos Mecânico', position: '1L' },
  { id: 'm2', tireId: '1001', vehicleId: 'v1', date: '2023-02-05', type: MaintenanceType.PRESSURE, cost: 0, odometer: 135000, description: 'Calibragem de rotina', performedBy: 'Carlos Mecânico' },
  { id: 'm3', tireId: '3001', vehicleId: 'v1', date: '2024-02-01', type: MaintenanceType.DISMOUNT, cost: 40, odometer: 148000, description: 'Retirada para recapagem - Desgaste natural', performedBy: 'Carlos Mecânico', position: '2R-OUT' }
];

export const STANDARD_RULES: AlertRule[] = [
    { id: 'r1', name: 'Sulco Mínimo (Segurança)', description: 'Alertar quando sulco atingir limite de segurança TWI', value: 3, unit: 'mm', isActive: true, severity: 'HIGH' },
    { id: 'r2', name: 'Sulco para Recapagem', description: 'Alertar momento ideal para envio à recapagem', value: 5, unit: 'mm', isActive: true, severity: 'MEDIUM' },
    { id: 'r4', name: 'Reaperto de Rodas', description: 'Alertar para reaperto após troca de pneus', value: 100, unit: 'km', isActive: false, severity: 'LOW' },
    { id: 'r5', name: 'Intervalo de Calibragem', description: 'Alertar se veículo ficar sem calibragem por X dias', value: 15, unit: 'dias', isActive: true, severity: 'MEDIUM' }
];

export const MOCK_NOTIFICATIONS = [
  { id: 1, ruleId: 'r1', severity: 'high', title: 'Sulco Crítico', date: 'Hoje, 09:30', desc: 'Pneu 1001 atingiu 2mm (Abaixo do limite de segurança). Veículo ABC-1234.' },
  { id: 2, ruleId: 'r2', severity: 'medium', title: 'Recapagem Necessária', date: 'Ontem, 14:15', desc: 'Pneu 1003 com 4mm. Programar retirada para recapagem.' },
];
