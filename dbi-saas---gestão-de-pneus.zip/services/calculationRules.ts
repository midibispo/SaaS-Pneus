
import { Tire, MaintenanceRecord, MaintenanceType, TireCondition, Vehicle, TireStatus } from '../types';

/**
 * 1. PREMISSAS GERAIS E ESTRUTURAS AUXILIARES
 * Baseado no MVP: Uma vida pertence a um único veículo.
 * Cálculos baseados apenas em eventos reais (MaintenanceRecord).
 */

export interface TireLifeCycle {
  tireId: string;
  lifeIndex: number; // 0 = Novo, 1 = 1ª Reforma, etc.
  vehicleId: string;
  installDate: string;
  installOdometer: number;
  removalDate: string | null;
  removalOdometer: number | null;
  status: 'ACTIVE' | 'ENDED'; // Active = Rodando, Ended = Retirado
  cost: number; // Regra 3.1
  kmTraveled: number; // Regra 2.2
  cpk: number; // Regra 4.2
  isScrap: boolean; // Regra 10.3
  position?: string;
}

/**
 * Helper para reconstruir o histórico de vidas de um pneu baseado em eventos (MaintenanceRecords).
 * Transforma logs brutos em Ciclos de Vida estruturados.
 */
export const reconstructTireLives = (tire: Tire, records: MaintenanceRecord[]): TireLifeCycle[] => {
  // Filtra registros apenas deste pneu e ordena por data/km
  const tireRecords = records
    .filter(r => r.tireId === tire.id || r.tireId === tire.serialNumber)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const lives: TireLifeCycle[] = [];
  let currentLife: TireLifeCycle | null = null;
  let currentLifeIndex = 0; // Começa na vida 0 (Novo)

  // Determinar custo inicial (Vida 0)
  let nextLifeCost = tire.purchaseCost; 

  tireRecords.forEach(record => {
    // Evento de Recapagem define o custo da PRÓXIMA vida instalada e incrementa index
    if (record.type === MaintenanceType.RETREAD) {
      currentLifeIndex++;
      nextLifeCost = record.cost;
      return; 
    }

    // Regra 1: Instalação inicia uma contagem de KM
    if (record.type === MaintenanceType.MOUNT && record.vehicleId) {
      // Se já existe uma vida aberta (erro de consistência), fechamos forçadamente ou ignoramos
      if (currentLife && currentLife.status === 'ACTIVE') {
         // Inconsistência de dados: Montou sem desmontar o anterior.
         // No MVP, assumimos que a montagem nova prevalece.
      }

      currentLife = {
        tireId: tire.id,
        lifeIndex: currentLifeIndex,
        vehicleId: record.vehicleId,
        installDate: record.date,
        installOdometer: record.odometer,
        removalDate: null,
        removalOdometer: null,
        status: 'ACTIVE',
        cost: nextLifeCost, // Regra 3.2: Custo Vida 0 = Compra, Vida 1+ = Recapagem
        kmTraveled: 0,
        cpk: 0,
        isScrap: false,
        position: record.position
      };
      
      // O custo é atribuído uma única vez por ciclo de montagem no MVP proposto
      // Para próximas montagens da mesma vida (rodízio), o custo seria 0 ou rateado?
      // Pela Regra 1 "Uma vida pertence a um único veículo (MVP)", assumimos que custo vai na 1ª instalação.
      nextLifeCost = 0; 
    }

    // Regra 1: Retirada encerra o cálculo de KM
    if (record.type === MaintenanceType.DISMOUNT && currentLife && currentLife.status === 'ACTIVE') {
      
      // Validação Regra 2.3: KM_retirada > KM_instalacao
      if (record.odometer > currentLife.installOdometer) {
        currentLife.removalDate = record.date;
        currentLife.removalOdometer = record.odometer;
        currentLife.status = 'ENDED'; // Regra 1: Somente vidas encerradas entram em custo
        
        // Regra 2.2: KM_VIDA = KM_RETIRADA – KM_INSTALACAO
        currentLife.kmTraveled = record.odometer - currentLife.installOdometer;

        // Regra 4.2: CPK_VIDA = CUSTO_VIDA ÷ KM_VIDA
        if (currentLife.kmTraveled > 0) {
          currentLife.cpk = currentLife.cost / currentLife.kmTraveled;
        }

        lives.push(currentLife);
        currentLife = null;
      } else {
        // Operação inválida conforme Regra 2.3
        console.warn(`Inconsistência de odômetro para pneu ${tire.serialNumber}: Retirada <= Instalação.`);
      }
    }
  });

  return lives;
};

export const CalculationRules = {

  /**
   * 5. CPK DO PNEU (GLOBAL)
   * Regra 5.2
   */
  calculateTireTotalCPK: (lives: TireLifeCycle[]): number => {
    // Filtra apenas vidas encerradas e válidas
    const validLives = lives.filter(l => l.status === 'ENDED' && l.kmTraveled > 0);
    
    if (validLives.length === 0) return 0;

    const totalCost = validLives.reduce((sum, l) => sum + l.cost, 0);
    const totalKm = validLives.reduce((sum, l) => sum + l.kmTraveled, 0);

    return totalKm > 0 ? totalCost / totalKm : 0;
  },

  /**
   * 6. CÁLCULO DE KM DO VEÍCULO (POR PERÍODO)
   * Regra 6.2
   */
  calculateVehicleKmInPeriod: (records: MaintenanceRecord[], vehicleId: string, startDate: string, endDate: string): number => {
    // Filtra registros do veículo no período
    const vehicleRecords = records
      .filter(r => r.vehicleId === vehicleId && r.date >= startDate && r.date <= endDate)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    if (vehicleRecords.length < 2) return 0; // Regra 6.3: Se não houver KM suficiente, inválido.

    const initialKm = vehicleRecords[0].odometer;
    const finalKm = vehicleRecords[vehicleRecords.length - 1].odometer;

    return finalKm - initialKm;
  },

  /**
   * 7. CUSTO TOTAL DO VEÍCULO (POR PERÍODO)
   * Regra 7.1 e 7.2: Somente vidas encerradas no período e naquele veículo.
   */
  calculateVehicleCostInPeriod: (allTires: Tire[], allRecords: MaintenanceRecord[], vehicleId: string, startDate: string, endDate: string): number => {
    let totalCost = 0;

    allTires.forEach(tire => {
      const lives = reconstructTireLives(tire, allRecords);
      
      // Filtra vidas que:
      // 1. Pertencem a este veículo
      // 2. Estão ENCERRADAS (status = ENDED)
      // 3. A data de encerramento (removalDate) está dentro do período
      const periodLives = lives.filter(life => 
        life.vehicleId === vehicleId &&
        life.status === 'ENDED' &&
        life.removalDate && 
        life.removalDate >= startDate && 
        life.removalDate <= endDate
      );

      // Soma o custo dessas vidas
      const costSum = periodLives.reduce((sum, l) => sum + l.cost, 0);
      totalCost += costSum;
    });

    return totalCost;
  },

  /**
   * 8. CPK DO VEÍCULO
   * Regra 8.1
   */
  calculateVehicleCPK: (cost: number, km: number): number => {
    if (km <= 0) return 0;
    return cost / km;
  },

  /**
   * 9. CUSTO POR POSIÇÃO
   * Regra 9.3: Média dos CPKs de vidas encerradas naquela posição.
   */
  calculatePositionPerformance: (position: string, allTires: Tire[], allRecords: MaintenanceRecord[]) => {
    let totalCPK = 0;
    let count = 0;

    allTires.forEach(tire => {
      const lives = reconstructTireLives(tire, allRecords);
      // Filtra vidas encerradas nesta posição específica
      const positionLives = lives.filter(l => l.position === position && l.status === 'ENDED' && l.kmTraveled > 0);
      
      positionLives.forEach(life => {
        totalCPK += life.cpk;
        count++;
      });
    });

    return count > 0 ? totalCPK / count : 0;
  },

  /**
   * 10. TAXA DE PERDA
   * Regra 10.2
   */
  calculateLossRate: (allTires: Tire[]): number => {
    const totalTires = allTires.length;
    if (totalTires === 0) return 0;

    // Regra 10.3: Considera Recusa (Scrap), Acidente, etc.
    const lostTires = allTires.filter(t => t.status === TireStatus.SCRAP).length;

    return (lostTires / totalTires) * 100;
  },

  /**
   * 11. DESEMPENHO POR MARCA (VIDA 0)
   * Regra 11.2
   */
  calculateBrandPerformance: (brandName: string, allTires: Tire[], allRecords: MaintenanceRecord[]) => {
    const brandTires = allTires.filter(t => t.brand === brandName);
    
    let totalKmLife0 = 0;
    let countLife0 = 0;
    let totalCPKLife0 = 0;

    brandTires.forEach(tire => {
      const lives = reconstructTireLives(tire, allRecords);
      // Pega apenas Vida 0 (Nova) encerrada
      const life0 = lives.find(l => l.lifeIndex === 0 && l.status === 'ENDED' && l.kmTraveled > 0);
      
      if (life0) {
        totalKmLife0 += life0.kmTraveled;
        totalCPKLife0 += life0.cpk;
        countLife0++;
      }
    });

    return {
      avgKm: countLife0 > 0 ? totalKmLife0 / countLife0 : 0,
      avgCPK: countLife0 > 0 ? totalCPKLife0 / countLife0 : 0
    };
  },

  /**
   * 13. DESEMPENHO POR RECAPADORA
   * Regra 13.2
   */
  calculateRetreaderPerformance: (retreaderName: string, allTires: Tire[], allRecords: MaintenanceRecord[]) => {
    // Filtra pneus que passaram por esta recapadora
    // Para simplificar, assumimos que o campo 'retreader' no Tire reflete o último. 
    // Em um sistema real, olhariamos MaintenanceRecords do tipo RETREAD.
    
    // Simulação baseada em registros de recape
    const retreadEvents = allRecords.filter(r => r.type === MaintenanceType.RETREAD && r.description.includes(retreaderName));
    const totalSent = retreadEvents.length;
    
    // Mocking approval based on tires that didn't go to SCRAP immediately after Retread attempt
    // (Simplification for MVP logic)
    const approved = totalSent; 
    
    return {
      approvalRate: totalSent > 0 ? (approved / totalSent) * 100 : 0,
      count: totalSent
    };
  },

  /**
   * 14. ALERTAS (VIDA ABAIXO DA MÉDIA)
   * Regra 14.1
   */
  checkLifeAlert: (tireKm: number, benchmarkKm: number, threshold: number = 0.7): boolean => {
    if (benchmarkKm === 0) return false;
    return tireKm < (benchmarkKm * threshold);
  }
};