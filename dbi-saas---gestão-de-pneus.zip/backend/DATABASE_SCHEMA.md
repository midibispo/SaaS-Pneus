
# Arquitetura de Banco de Dados (ER Diagram)

Este diagrama representa a estrutura relacional sugerida para o PostgreSQL, suportando as regras de negócio do SaaS.

> **Nota:** Para visualizar este diagrama, você pode usar a extensão "Markdown Preview Mermaid Support" no VS Code ou colar o código abaixo no [Mermaid Live Editor](https://mermaid.live/).

```mermaid
erDiagram
    %% --- SAAS CORE ---
    PLAN {
        uuid id PK
        string name
        decimal price
        int asset_limit
        enum frequency "MONTHLY|YEARLY"
    }

    TENANT {
        uuid id PK
        string name
        string document "CNPJ"
        uuid plan_id FK
        string status "ACTIVE|SUSPENDED"
        date expires_at
    }

    USER {
        uuid id PK
        uuid tenant_id FK
        string name
        string email
        string password_hash
        enum role "ADMIN|MECHANIC|AUDITOR"
    }

    %% --- CONFIGURATIONS ---
    BRAND {
        uuid id PK
        string name
        enum type "TIRE|VEHICLE|RETREAD"
        boolean is_global "True if system default"
        uuid tenant_id FK "Nullable (if custom brand)"
    }

    SUPPLIER {
        uuid id PK
        uuid tenant_id FK
        string name
        string document "CNPJ"
        enum type "RESELLER|RETREADER"
    }

    %% --- FLEET ---
    VEHICLE {
        uuid id PK
        uuid tenant_id FK
        string plate
        string model
        string brand_name
        string category "TRUCK|TRAILER|BUS"
        int odometer
        string status "ACTIVE|MAINTENANCE"
    }

    %% --- TIRE ASSETS (CORE) ---
    TIRE {
        uuid id PK
        uuid tenant_id FK
        string serial_number "Fogo"
        string brand_name
        string model
        string size
        
        %% Location State
        enum status "STOCK|INSTALLED|RETREADING|SCRAP"
        uuid vehicle_id FK "Nullable"
        string position "1L, 1R, etc (Nullable)"
        uuid supplier_id FK "Nullable (Location if Retreading)"
        
        %% Technical State
        int life_count "0=New, 1=Retread"
        decimal current_depth_mm
        decimal original_depth_mm
        int accumulated_mileage
        
        %% Financial
        decimal purchase_cost
        date purchase_date
        
        %% Retread Specifics (Current Life)
        string tread_brand "Marca Banda"
        string tread_model
    }

    %% --- OPERATIONS & HISTORY ---
    MAINTENANCE_RECORD {
        uuid id PK
        uuid tenant_id FK
        uuid tire_id FK
        uuid vehicle_id FK "Nullable"
        uuid performed_by_user_id FK
        
        timestamp date
        enum type "MOUNT|DISMOUNT|PRESSURE|RETREAD|REPAIR"
        
        int odometer_snapshot
        decimal cost
        string description
        
        %% Snapshot data for history integrity
        string position_snapshot
        decimal depth_snapshot
    }

    %% --- RELATIONSHIPS ---

    PLAN ||--o{ TENANT : "defines limits for"
    TENANT ||--o{ USER : "has employees"
    TENANT ||--o{ VEHICLE : "owns fleet"
    TENANT ||--o{ TIRE : "owns assets"
    TENANT ||--o{ SUPPLIER : "manages"
    TENANT ||--o{ MAINTENANCE_RECORD : "audit log"

    VEHICLE ||--o{ TIRE : "has installed"
    
    %% History links
    TIRE ||--o{ MAINTENANCE_RECORD : "lifecycle events"
    VEHICLE ||--o{ MAINTENANCE_RECORD : "service history"
    USER ||--o{ MAINTENANCE_RECORD : "performed"
    
    %% Config links
    SUPPLIER ||--o{ TIRE : "currently holding (retread)"
```

## Explicação das Entidades Principais

### 1. `TIRE` (O Ativo Principal)
Armazena o estado **atual** do pneu.
*   **Regra de Negócio (Bloqueio Dianteira):** O backend verifica `life_count` > 0 antes de permitir um `UPDATE` onde `position` comece com '1'.
*   **Rastreabilidade:** `vehicle_id` e `position` indicam onde ele está agora. Se ambos forem NULL e `status` for STOCK, está no estoque.

### 2. `MAINTENANCE_RECORD` (A Fonte da Verdade)
Cada vez que um pneu se move, calibra ou reforma, uma linha é inserida aqui.
*   **Cálculo de CPK:** O backend soma `cost` de todos os registros de um pneu e divide pelo delta de KM (calculado via snapshots de odômetro).
*   **Imutabilidade:** Registros antigos não devem ser alterados para manter a integridade dos relatórios financeiros.

### 3. `TENANT` (Multi-tenancy)
Todas as tabelas críticas (`VEHICLE`, `TIRE`, `MAINTENANCE`, `USER`) possuem uma coluna `tenant_id`.
*   **Segurança:** Todas as queries SQL devem incluir `WHERE tenant_id = ?` para garantir o isolamento de dados entre clientes.
