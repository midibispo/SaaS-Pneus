
# Estrutura do Backend - SaaS Gestão de Pneus

Este documento define a arquitetura sugerida para a API que substituirá o `mockData.ts`. O objetivo é criar um sistema escalável, multi-tenant (SaaS) e robusto.

## 1. Stack Tecnológica Sugerida

*   **Linguagem:** TypeScript (Node.js)
*   **Framework:** NestJS (recomendado pela estrutura modular) ou Express.js.
*   **Banco de Dados:** PostgreSQL (Relacional é ideal para a integridade dos dados de frota).
*   **ORM:** Prisma ou TypeORM.
*   **Autenticação:** JWT (JSON Web Tokens) com Refresh Tokens.
*   **Infra:** Docker containers.

## 2. Estrutura de Pastas (Clean Architecture)

A estrutura visa separar as regras de negócio (Core) da infraestrutura (Web/DB).

```
/backend
  /src
    /config             # Variáveis de ambiente, configurações de DB, constantes globais.
    
    /modules            # Módulos da aplicação (Feature-based)
      /auth             # Autenticação e Gestão de Usuários
      /fleet            # Veículos e Estrutura de Eixos
      /tires            # Pneus, Estoque e Ciclo de Vida
      /maintenance      # Registros de Manutenção e Ordens de Serviço
      /companies        # Gestão de Tenants (SaaS) e Fornecedores
      
    # Dentro de cada módulo (ex: /tires):
      /controllers      # Lida com Req/Res HTTP (Entrada)
      /services         # Regras de Negócio, Validações, Lógica Pura
      /repositories     # Acesso ao Banco de Dados (Abstração do ORM)
      /dtos             # Data Transfer Objects (Validação de entrada - ex: Zod/ClassValidator)
      /entities         # Definição das Entidades do Domínio
      
    /shared             # Código compartilhado
      /middlewares      # AuthGuard, Logging, ErrorHandling
      /utils            # Formatadores, Helpers de Data
      /providers        # Serviços externos (Storage, Email, etc.)
      
    /database
      /migrations       # Scripts de versionamento do banco
      /seeds            # Dados iniciais
      
  /tests                # Testes Unitários e de Integração
  app.ts                # Configuração do App
  server.ts             # Entry Point
```

## 3. Rotas da API (Endpoints Principais)

As rotas são desenhadas seguindo o padrão RESTful.

### 🔐 Autenticação & Acesso (`/api/auth`)
| Método | Rota | Descrição | Payload Exemplo |
| :--- | :--- | :--- | :--- |
| POST | `/login` | Autentica usuário e retorna tokens | `{ email, password }` |
| POST | `/refresh` | Renova token de acesso | `{ refreshToken }` |
| GET | `/me` | Retorna dados do usuário logado e permissões | - |
| POST | `/forgot-password` | Inicia fluxo de recuperação de senha | `{ email }` |

### 🏢 Tenants & Configurações (`/api/companies`)
| Método | Rota | Descrição | Payload Exemplo |
| :--- | :--- | :--- | :--- |
| GET | `/profile` | Dados da empresa do usuário logado | - |
| PUT | `/profile` | Atualiza dados da empresa | `{ name, address, ... }` |
| GET | `/users` | Lista colaboradores | - |
| POST | `/users` | Cria novo colaborador | `{ name, role, email... }` |

### 🚛 Frota & Veículos (`/api/vehicles`)
| Método | Rota | Descrição |
| :--- | :--- | :--- |
| GET | `/` | Lista veículos (com paginação e filtros: placa, status) |
| POST | `/` | Cadastra novo veículo |
| GET | `/:id` | Detalhes do veículo, incluindo esquema de pneus atual |
| PUT | `/:id` | Atualiza dados (ex: hodômetro, status) |
| GET | `/:id/history` | Histórico de movimentações do veículo |

### 🔘 Pneus & Ciclo de Vida (`/api/tires`)
*O núcleo da lógica de negócio.*

| Método | Rota | Descrição | Payload/Query |
| :--- | :--- | :--- | :--- |
| GET | `/` | Inventário de pneus | `?status=STOCK&brand=Michelin` |
| POST | `/` | Cadastra pneu (entrada estoque) | `{ serial, brand, size, cost... }` |
| GET | `/:id` | Detalhes do pneu e ciclo de vida | - |
| PUT | `/:id` | Edição de dados cadastrais | - |
| POST | `/:id/move` | **Ação:** Instalar, Desmontar ou Rodízio | `{ vehicleId, position, odometer, date }` |
| POST | `/:id/send-retread` | **Ação:** Enviar para Recapagem | `{ supplierId, date, odometer }` |
| POST | `/:id/return-retread` | **Ação:** Retorno de Recapagem | `{ approved, newDepth, cost... }` |
| POST | `/:id/scrap` | **Ação:** Enviar para Sucata | `{ reason, odometer, date }` |

### 🔧 Manutenção & Serviços (`/api/maintenance`)
| Método | Rota | Descrição |
| :--- | :--- | :--- |
| GET | `/` | Lista de registros de manutenção |
| POST | `/` | Registra nova manutenção (ex: Calibragem, Reparo) |
| DELETE | `/:id` | Remove um registro (apenas admin) |

### 📊 Relatórios & Dashboard (`/api/reports`)
| Método | Rota | Descrição |
| :--- | :--- | :--- |
| GET | `/dashboard` | KPIs resumidos (Cards do Dashboard) |
| GET | `/costs` | Relatório financeiro (CPK, Custos totais) |
| GET | `/performance` | Desempenho por marca/modelo |

## 4. Regras de Negócio Críticas (Backend Enforced)

Estas regras devem ser validadas na camada `Services` antes de persistir no banco:

1.  **Bloqueio de Dianteira:** Ao receber um `POST /tires/:id/move` com destino `1L` ou `1R`, verificar se `tire.lifeCount > 0`. Se sim, retornar `400 Bad Request`.
2.  **Consistência de Hodômetro:** Em qualquer operação que envolva KM, verificar se `novo_km >= ultimo_km_registrado`.
3.  **Unicidade de Posição:** Um veículo não pode ter dois pneus na mesma posição (ex: dois pneus em `1L`). O backend deve desmontar o anterior ou rejeitar a operação.
4.  **Multi-tenancy:** Todo acesso ao banco deve ter um `WHERE tenant_id = X` forçado pelo middleware ou repositório, garantindo que uma transportadora não veja dados de outra.
