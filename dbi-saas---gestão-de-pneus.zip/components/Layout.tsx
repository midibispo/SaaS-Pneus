
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Truck, 
  Disc, 
  FileText, 
  ShieldCheck, 
  LogOut, 
  Menu, 
  X,
  Repeat,
  Activity,
  Settings,
  Database,
  Tag,
  Briefcase,
  Users,
  CreditCard,
  Building,
  Wrench,
  Bell,
  RefreshCw
} from 'lucide-react';
import { User, Role } from '../types';
import { clsx } from 'clsx';

interface LayoutProps {
  children: React.ReactNode;
  user: User;
  onLogout: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, user, onLogout }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();

  const NavItem = ({ to, icon: Icon, label, restrictedTo, state }: { to: string, icon: any, label: string, restrictedTo?: Role[], state?: any }) => {
    if (restrictedTo && !restrictedTo.includes(user.role)) return null;
    
    // Check if active based on path.
    const isActive = location.pathname === to && (!state || JSON.stringify(location.state) === JSON.stringify(state));

    return (
      <Link
        to={to}
        state={state}
        onClick={() => setIsSidebarOpen(false)}
        className={clsx(
          "flex items-center gap-3 px-4 py-3 rounded-xl transition-all mb-1 font-medium",
          isActive 
            ? "bg-[#f97316] text-white shadow-md shadow-orange-500/20" 
            : "text-slate-500 hover:bg-orange-50 hover:text-[#f97316]"
        )}
      >
        <Icon size={20} className="shrink-0" />
        <span className="whitespace-nowrap">{label}</span>
      </Link>
    );
  };

  const SidebarContent = () => (
    <>
      <nav className="flex-1 p-4 overflow-y-auto">
        {user.role === Role.SUPER_ADMIN ? (
            <>
              <div className="text-sm font-extrabold text-[#001529] uppercase tracking-wide px-4 mb-3 mt-4">Administração</div>
              <NavItem to="/super-admin" icon={ShieldCheck} label="Gestão Tenants" />
              <NavItem to="/manage-plans" icon={CreditCard} label="Planos de Usabilidade" />
            </>
        ) : (
          <>
            <div className="text-sm font-extrabold text-[#001529] uppercase tracking-wide px-4 mb-3 mt-2">OPERACIONAL</div>
            <NavItem to="/dashboard" icon={LayoutDashboard} label="Dashboard" />
            <NavItem to="/vehicles" icon={Truck} label="Mapa de veículos" />
            <NavItem to="/inventory" icon={Disc} label="Estoque de pneus" />
            <NavItem to="/lifecycle" icon={Activity} label="Ciclo de vida" />
            <NavItem to="/maintenance" icon={Wrench} label="Manutenções" />
            <NavItem to="/alerts" icon={Bell} label="Alertas" />
            <NavItem to="/reports" icon={FileText} label="Relatórios" />
            
            <div className="text-sm font-extrabold text-[#001529] uppercase tracking-wide px-4 mb-3 mt-6">CADASTROS</div>
            <NavItem to="/manage-vehicles" icon={Settings} label="Veículos" />
            <NavItem to="/manage-tires" icon={Database} label="Pneus (Master)" />
            <NavItem to="/manage-brands" icon={Tag} label="Marcas" />
            <NavItem to="/manage-suppliers" icon={Briefcase} label="Fornecedores" />
            <NavItem to="/collaborators" icon={Users} label="Funcionários" />
            <NavItem to="/manage-brands" icon={RefreshCw} label="Recapadoras" state={{ tab: 'RETREADER' }} />
          </>
        )}
      </nav>

      <div className="p-4 border-t border-slate-100">
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors text-sm font-medium"
        >
          <LogOut size={18} />
          Sair
        </button>
      </div>
    </>
  );

  return (
    <div className="flex flex-col h-screen bg-slate-50 overflow-hidden">
      {/* FULL WIDTH HEADER */}
      <header className="h-16 lg:h-20 border-b border-slate-800 flex items-center justify-between px-4 lg:px-8 shadow-md shrink-0 z-40 relative overflow-hidden bg-[#001529]">
         
         {/* Content Wrapper (z-10) */}
         <div className="flex items-center gap-4 relative z-10">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 text-slate-300 hover:bg-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-600"
            >
              <Menu size={24} />
            </button>
            
            {/* FROTA INTELIGENTE Logo */}
            <div className="flex flex-col select-none">
              <div className="text-2xl lg:text-3xl font-black text-white tracking-tighter leading-none flex items-center">
                FR<span className="text-[#f97316]">O</span>TA
              </div>
              <div className="text-[9px] lg:text-[10px] font-bold text-white tracking-[0.35em] leading-none ml-0.5 mt-0.5 opacity-90">
                INTELIGENTE
              </div>
            </div>
         </div>

         <div className="flex items-center gap-4 lg:gap-6 relative z-10">
            {user.tenantId && (
               <span className="hidden sm:inline-flex items-center px-3 py-1 rounded-full bg-[#0f253a]/80 backdrop-blur-md border border-slate-600 text-slate-200 text-xs font-bold uppercase tracking-wide whitespace-nowrap">
                 {user.tenantId === 't1' ? 'Global Transp.' : 'Demo'}
               </span>
            )}

            <div className="flex items-center gap-3 pl-4 lg:pl-6 border-l border-slate-700/50 h-8">
               <div className="text-right hidden md:block">
                  <p className="text-sm font-bold text-white leading-tight">{user.name}</p>
                  <span className="text-[10px] font-bold text-slate-300 bg-[#0f253a]/80 px-2 py-0.5 rounded-full inline-block mt-0.5 border border-slate-700/50">
                    {user.role}
                  </span>
               </div>
               <img 
                 src={user.avatar} 
                 alt={user.name} 
                 className="w-8 h-8 lg:w-10 lg:h-10 rounded-full border-2 border-slate-500 shadow-sm object-cover" 
               />
            </div>
         </div>
      </header>

      {/* CONTENT AREA */}
      <div className="flex flex-1 overflow-hidden relative">
        
        {/* Floating Sidebar (Desktop) */}
        <aside className="hidden lg:flex flex-col w-64 m-5 rounded-3xl bg-white shadow-xl border border-slate-100 z-30 overflow-hidden shrink-0">
           <SidebarContent />
        </aside>

        {/* Mobile/Tablet Sidebar (Drawer) */}
        <div className={clsx(
          "fixed inset-0 z-[60] lg:hidden",
          isSidebarOpen ? "pointer-events-auto" : "pointer-events-none"
        )}>
           {/* Backdrop */}
           <div 
              className={clsx("absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300", isSidebarOpen ? "opacity-100" : "opacity-0")}
              onClick={() => setIsSidebarOpen(false)}
           />
           {/* Drawer */}
           <div className={clsx(
              "absolute top-0 bottom-0 left-0 w-[280px] bg-white shadow-2xl transform transition-transform duration-300 ease-out flex flex-col h-full",
              isSidebarOpen ? "translate-x-0" : "-translate-x-full"
           )}>
              <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                 <span className="font-bold text-slate-800">Menu</span>
                 <button onClick={() => setIsSidebarOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full"><X size={20}/></button>
              </div>
              <SidebarContent />
           </div>
        </div>

        {/* Main Page Content */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden p-3 md:p-4 lg:p-6 bg-slate-50 w-full relative">
           <div className="max-w-7xl mx-auto min-h-full pb-20 lg:pb-0">
             {children}
           </div>
        </main>

      </div>
    </div>
  );
};
