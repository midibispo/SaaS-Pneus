
import React from 'react';
import { Vehicle, Tire, TireStatus, AxleRole } from '../types';
import { VEHICLE_LAYOUTS } from '../services/mockData';
import { clsx } from 'clsx';

interface VehicleSchematicProps {
  vehicle: Vehicle;
  tires: Tire[];
  onTireClick: (tire: Tire | undefined, position: string) => void;
  readOnly?: boolean;
}

// Helper to find tire at position
const getTireAt = (tires: Tire[], position: string) => tires.find(t => t.position === position);

const TireNode = ({ tire, position, onClick }: { tire?: Tire, position: string, onClick: () => void }) => {
  const getStatusColor = (status?: TireStatus) => {
    switch (status) {
      case TireStatus.INSTALLED: return 'bg-slate-800 border-slate-600';
      case TireStatus.AWAITING_RETREAD: return 'bg-yellow-500 border-yellow-600';
      case TireStatus.SCRAP: return 'bg-red-500 border-red-600';
      default: return 'bg-slate-200 border-slate-300 border-dashed';
    }
  };

  const depthColor = (depth: number) => {
    if (depth > 10) return 'text-emerald-500';
    if (depth > 5) return 'text-yellow-500';
    return 'text-red-500';
  }

  return (
    <div 
      onClick={onClick}
      className={clsx(
        "w-16 h-12 rounded border-2 flex flex-col items-center justify-center cursor-pointer transition-all hover:scale-105 shadow-sm relative group z-10",
        getStatusColor(tire?.status)
      )}
    >
      {tire ? (
        <>
           {/* Position Label - More compact */}
           <div className="absolute -left-1 -top-3 text-[9px] font-bold text-slate-500 bg-white px-1 rounded shadow-sm z-30">{position}</div>
           
           {/* Life Indicator */}
           <div className={clsx(
             "absolute -right-2 -top-2 w-5 h-5 rounded-full flex items-center justify-center border-2 border-white z-20 shadow-sm",
             tire.lifeCount === 0 ? "bg-emerald-500" : "bg-blue-600"
           )}>
             <span className="text-[8px] text-white font-bold">V{tire.lifeCount}</span>
           </div>
           
           <span className="text-[9px] text-white font-mono font-bold truncate max-w-full px-1">{tire.serialNumber.split('-')[1] || tire.serialNumber}</span>
           <div className="mt-0.5 w-full bg-slate-900/50 text-center px-1 rounded-sm">
             <span className={clsx("text-[8px] font-bold", depthColor(tire.currentDepth))}>{tire.currentDepth}mm</span>
           </div>
        </>
      ) : (
        <span className="text-slate-400 text-[10px] font-bold">{position}</span>
      )}
    </div>
  );
};

// Axle Component
const Axle = ({ tires, axleNumber, isDual, role, onTireClick }: { tires: Tire[], axleNumber: number, isDual: boolean, role: AxleRole, onTireClick: any }) => {
  
  // Style config for roles
  const roleConfig = {
      STEER: { label: 'DIR', color: 'bg-blue-100 text-blue-700 border-blue-200' },
      DRIVE: { label: 'TRA', color: 'bg-orange-100 text-orange-700 border-orange-200' },
      AUX:   { label: 'AUX', color: 'bg-slate-200 text-slate-600 border-slate-300' },
      TRAILER: { label: 'LIV', color: 'bg-slate-100 text-slate-500 border-slate-200' }
  }[role];

  return (
    <div className="flex flex-col items-center justify-between h-full min-h-[220px] bg-slate-50 rounded-xl py-4 px-3 mx-2 border border-slate-200 shadow-inner min-w-[140px]">
      
      {/* Left Side (Driver Side) */}
      <div className="flex flex-col gap-2 items-center">
        {isDual ? (
            <div className="flex gap-1">
                <TireNode position={`${axleNumber}L-OUT`} tire={getTireAt(tires, `${axleNumber}L-OUT`)} onClick={() => onTireClick(getTireAt(tires, `${axleNumber}L-OUT`), `${axleNumber}L-OUT`)} />
                <TireNode position={`${axleNumber}L-IN`} tire={getTireAt(tires, `${axleNumber}L-IN`)} onClick={() => onTireClick(getTireAt(tires, `${axleNumber}L-IN`), `${axleNumber}L-IN`)} />
            </div>
        ) : (
            <TireNode position={`${axleNumber}L`} tire={getTireAt(tires, `${axleNumber}L`)} onClick={() => onTireClick(getTireAt(tires, `${axleNumber}L`), `${axleNumber}L`)} />
        )}
      </div>
      
      {/* Axle Bar with Role Indicator NEXT TO IT */}
      <div className="relative h-full min-h-[4rem] my-2 flex items-center justify-center">
         {/* The Bar */}
         <div className="w-4 bg-slate-300 h-full rounded-full shadow-inner border border-slate-400 flex items-center justify-center">
            <span className="text-[10px] font-bold text-slate-500 -rotate-90 whitespace-nowrap">Eixo {axleNumber}</span>
         </div>

         {/* The Badge (Floating to the side) */}
         <div className={clsx(
            "absolute left-6 flex items-center justify-center w-8 h-5 rounded border shadow-sm z-20 font-bold text-[9px]",
            roleConfig.color
         )}>
            {roleConfig.label}
         </div>
      </div>
      
      {/* Right Side (Passenger Side) */}
      <div className="flex flex-col gap-2 items-center">
        {isDual ? (
            <div className="flex gap-1">
                <TireNode position={`${axleNumber}R-IN`} tire={getTireAt(tires, `${axleNumber}R-IN`)} onClick={() => onTireClick(getTireAt(tires, `${axleNumber}R-IN`), `${axleNumber}R-IN`)} />
                <TireNode position={`${axleNumber}R-OUT`} tire={getTireAt(tires, `${axleNumber}R-OUT`)} onClick={() => onTireClick(getTireAt(tires, `${axleNumber}R-OUT`), `${axleNumber}R-OUT`)} />
            </div>
        ) : (
            <TireNode position={`${axleNumber}R`} tire={getTireAt(tires, `${axleNumber}R`)} onClick={() => onTireClick(getTireAt(tires, `${axleNumber}R`), `${axleNumber}R`)} />
        )}
      </div>
    </div>
  );
};

export const VehicleSchematic: React.FC<VehicleSchematicProps> = ({ vehicle, tires, onTireClick }) => {
  
  const getAxleConfig = () => {
    const type = vehicle.type || '';
    // Default to a basic 2-axle steer/drive if unknown
    const layout = VEHICLE_LAYOUTS[type] || [
        {isDual: false, role: 'STEER'}, 
        {isDual: true, role: 'DRIVE'}
    ]; 
    
    const isTrailer = vehicle.category === 'TRAILER';
    let currentAxleNum = isTrailer ? 1 : 1; 
    
    return layout.map((axle, i) => ({
        axleNumber: currentAxleNum + i,
        isDual: axle.isDual,
        role: axle.role
    }));
  };

  const axleConfig = getAxleConfig();

  return (
    <div className="flex items-center py-8 overflow-x-auto w-full px-4 justify-start bg-white rounded-lg min-h-[300px]">
      
      {/* Front / Cabin Logic */}
      {vehicle.category === 'BUS' ? (
        <div className="h-56 w-32 bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg mr-4 shadow-lg flex flex-col items-center justify-between text-white font-bold tracking-wider border-r-4 border-slate-900 relative shrink-0 py-4">
            <div className="w-24 h-40 bg-sky-900/40 rounded border border-white/20 backdrop-blur-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-bl from-white/10 to-transparent"></div>
            </div>
            <span className="text-xs uppercase bg-black/20 px-2 rounded">{vehicle.plate}</span>
        </div>
      ) : vehicle.category === 'TRUCK' ? (
        <div className="h-56 w-24 bg-gradient-to-r from-slate-700 to-slate-900 rounded-l-3xl rounded-r-lg mr-4 shadow-lg flex flex-col items-center justify-center text-white font-bold tracking-wider border-r-4 border-slate-900 relative shrink-0">
          <div className="absolute left-2 h-40 w-8 bg-sky-900/30 rounded-full blur-sm"></div>
          <div className="absolute -top-2 right-4 w-2 h-8 bg-slate-800 rounded-sm border border-slate-600"></div>
          <div className="absolute -bottom-2 right-4 w-2 h-8 bg-slate-800 rounded-sm border border-slate-600"></div>
          <span className="-rotate-90 whitespace-nowrap text-lg">{vehicle.plate}</span>
        </div>
      ) : (
        // TRAILER FRONT (GRANELEIRA / BAÚ STYLE)
        <div className="h-56 w-20 bg-gradient-to-r from-slate-200 to-slate-300 rounded-l-lg rounded-r-md mr-8 shadow-lg flex flex-col items-center justify-between border-r-4 border-slate-400 relative shrink-0 py-2 border-y border-l border-slate-300">
            {/* Visual ribs for trailer wall */}
            <div className="w-full h-full flex flex-col justify-evenly px-2 opacity-30">
                <div className="w-full h-1 bg-slate-400 rounded-full"></div>
                <div className="w-full h-1 bg-slate-400 rounded-full"></div>
                <div className="w-full h-1 bg-slate-400 rounded-full"></div>
                <div className="w-full h-1 bg-slate-400 rounded-full"></div>
                <div className="w-full h-1 bg-slate-400 rounded-full"></div>
                <div className="w-full h-1 bg-slate-400 rounded-full"></div>
            </div>
            
            {/* Kingpin Indicator */}
            <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-4 h-6 bg-slate-700 rounded-b-md border-x-2 border-b-2 border-slate-500 shadow-sm" title="Pino Rei"></div>
            
            {/* Front Label */}
            <div className="absolute -left-8 top-1/2 -translate-y-1/2 -rotate-90">
               <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Frontal</span>
            </div>
        </div>
      )}

      {/* Axles Flowing Right */}
      {axleConfig.map((config, index) => (
        <React.Fragment key={config.axleNumber}>
          <Axle 
            tires={tires} 
            axleNumber={config.axleNumber} 
            isDual={config.isDual} 
            role={config.role}
            onTireClick={onTireClick} 
          />
          {index < axleConfig.length - 1 && (
            <div className="w-8 h-4 bg-slate-200 mx-[-0.5rem] z-0 shadow-inner rounded border-t border-b border-slate-300"></div>
          )}
        </React.Fragment>
      ))}
      
      {/* Rear Bumper Hint */}
      <div className="h-32 w-2 bg-slate-300 rounded-full ml-2"></div>
    </div>
  );
};
