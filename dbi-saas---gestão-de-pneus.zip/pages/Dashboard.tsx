
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { User, TireStatus, AlertRule } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { AlertTriangle, TrendingUp, Truck, Activity, Disc, AlertCircle, ArrowRight, Settings } from 'lucide-react';
import { MOCK_TIRES, MOCK_VEHICLES, STANDARD_RULES, MOCK_NOTIFICATIONS } from '../services/mockData';

const COLORS = ['#0ea5e9', '#10b981', '#f59e0b', '#ef4444'];

export const DashboardPage: React.FC<{ user: User }> = ({ user }) => {
  const navigate = useNavigate();

  // Load Rules from localStorage to filter alerts
  const savedRules = localStorage.getItem('dbi_rules');
  const rules: AlertRule[] = savedRules ? JSON.parse(savedRules) : STANDARD_RULES;

  // Filter alerts based on active rules
  const recentAlerts = MOCK_NOTIFICATIONS.filter(alert => {
      const rule = rules.find(r => r.id === alert.ruleId);
      return rule ? rule.isActive : true; 
  });

  // Count high severity alerts that are active
  const criticalAlertsCount = recentAlerts.filter(a => a.severity === 'high').length;

  // Calculated stats from mocks
  const totalVehicles = MOCK_VEHICLES.length;
  const totalTires = MOCK_TIRES.length;
  const installedTires = MOCK_TIRES.filter(t => t.status === TireStatus.INSTALLED).length;
  const retreadingTires = MOCK_TIRES.filter(t => t.status === TireStatus.AWAITING_RETREAD).length;
  
  const statusData = [
    { name: 'Instalados', value: installedTires },
    { name: 'Estoque', value: MOCK_TIRES.filter(t => t.status === TireStatus.STOCK).length },
    { name: 'Recapagem', value: retreadingTires },
    { name: 'Sucata', value: MOCK_TIRES.filter(t => t.status === TireStatus.SCRAP).length },
  ];

  const brandData = [
    { name: 'Michelin', value: 400 },
    { name: 'Bridgestone', value: 300 },
    { name: 'Goodyear', value: 300 },
    { name: 'Continental', value: 200 },
  ];

  const StatCard = ({ title, value, icon: Icon, color, subtext }: any) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-start justify-between hover:shadow-md transition-shadow">
      <div>
        <p className="text-sm font-bold text-slate-500 uppercase tracking-wide">{title}</p>
        <h3 className="text-3xl font-black text-slate-800 mt-2">{value}</h3>
        {subtext && <p className="text-xs text-slate-400 mt-2 font-medium">{subtext}</p>}
      </div>
      <div className={`p-3 rounded-xl ${color} bg-opacity-10 text-${color.replace('bg-', '').replace('-500', '-600')}`}>
        <Icon size={24} className={color.replace('bg-', 'text-')} />
      </div>
    </div>
  );

  const handleAlertClick = (alert: any) => {
      // Logic to navigate to specific context
      // In a real app, we would pass the ID to filters
      navigate(alert.link);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Dashboard Operacional</h1>
          <p className="text-slate-500">Monitoramento em tempo real da frota</p>
        </div>
        <div className="flex gap-2">
            <button className="px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-lg text-sm font-bold hover:bg-slate-50 flex items-center gap-2">
                <Activity size={16} /> Relatório Diário
            </button>
        </div>
      </div>

      {/* KPI Cards - Row 1 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <StatCard 
            title="Total Veículos" 
            value={totalVehicles} 
            icon={Truck} 
            color="bg-slate-700" 
            subtext="Frota Ativa"
        />
        <StatCard 
            title="Total Pneus" 
            value={totalTires} 
            icon={Disc} 
            color="bg-primary-500" 
            subtext="Ativos Controlados"
        />
        <StatCard 
            title="Em Rodagem" 
            value={installedTires} 
            icon={Truck} 
            color="bg-emerald-500" 
            subtext={`${((installedTires/totalTires)*100).toFixed(0)}% da frota`}
        />
        <StatCard 
            title="Em Recapagem" 
            value={retreadingTires} 
            icon={Activity} 
            color="bg-orange-500" 
            subtext="Fora de operação"
        />
        <StatCard 
            title="Alertas Críticos" 
            value={criticalAlertsCount} 
            icon={AlertTriangle} 
            color="bg-red-500" 
            subtext="Requer atenção imediata"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Charts Section - Takes 2/3 width */}
        <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Status Distribution */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                    <h3 className="text-sm font-bold text-slate-800 uppercase mb-6">Status da Frota</h3>
                    <div className="h-48">
                        <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                            data={statusData}
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={70}
                            paddingAngle={5}
                            dataKey="value"
                            >
                            {statusData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                            </Pie>
                            <Tooltip />
                        </PieChart>
                        </ResponsiveContainer>
                    </div>
                    <div className="flex justify-center gap-3 mt-2 flex-wrap">
                        {statusData.map((entry, index) => (
                            <div key={index} className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
                                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                                {entry.name} ({entry.value})
                            </div>
                        ))}
                    </div>
                </div>

                {/* Performance Chart */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                    <h3 className="text-sm font-bold text-slate-800 uppercase mb-6">Pneus por Marca</h3>
                    <div className="h-48">
                        <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={brandData}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} />
                            <XAxis dataKey="name" tick={{fontSize: 10}} interval={0} />
                            <YAxis tick={{fontSize: 10}} />
                            <Tooltip cursor={{fill: 'transparent'}} />
                            <Bar dataKey="value" fill="#0ea5e9" radius={[4, 4, 0, 0]} barSize={30} />
                        </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        </div>

        {/* Recent Alerts - Takes 1/3 width */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden flex flex-col">
            <div className="p-5 border-b border-slate-100 bg-red-50/50 flex justify-between items-center">
                <h3 className="text-sm font-bold text-red-700 uppercase flex items-center gap-2">
                    <AlertCircle size={18} /> Alertas Recentes
                </h3>
                <div className="flex items-center gap-2">
                    <span className="bg-red-100 text-red-700 text-xs font-bold px-2 py-0.5 rounded-full">{recentAlerts.length} Novos</span>
                    <button 
                        onClick={() => navigate('/alerts')} 
                        className="text-red-400 hover:text-red-600 transition-colors p-1"
                        title="Configurar Regras de Alerta"
                    >
                        <Settings size={14} />
                    </button>
                </div>
            </div>
            <div className="divide-y divide-slate-100 overflow-y-auto flex-1">
                {recentAlerts.length > 0 ? (
                    recentAlerts.map((alert) => (
                        <div 
                            key={alert.id} 
                            onClick={() => handleAlertClick(alert)}
                            className="p-4 hover:bg-slate-50 transition-colors cursor-pointer group relative"
                        >
                            <div className="flex items-start gap-3">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                                    alert.severity === 'high' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'
                                }`}>
                                    <AlertTriangle size={16} />
                                </div>
                                <div className="flex-1">
                                    <p className="font-bold text-slate-800 text-sm group-hover:text-primary-600 transition-colors flex items-center justify-between">
                                        {alert.title}
                                        <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 text-primary-400 transition-opacity" />
                                    </p>
                                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">{alert.desc}</p>
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="p-8 text-center text-slate-400 text-sm">
                        Nenhum alerta ativo.
                    </div>
                )}
            </div>
            <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
                <button 
                    onClick={() => navigate('/alerts')}
                    className="text-xs font-bold text-slate-500 hover:text-primary-600 uppercase tracking-wide w-full"
                >
                    Ver todos os alertas
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
