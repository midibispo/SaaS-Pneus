
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { MOCK_BRANDS } from '../services/mockData';
import { Brand } from '../types';
import { Plus, Edit2, Trash2, Search, Save, X, CheckCircle, XCircle, Truck, Disc, RefreshCw, Briefcase, MapPin, Phone, Mail, AlertCircle } from 'lucide-react';
import { clsx } from 'clsx';

export const ManageBrandsPage: React.FC = () => {
  const location = useLocation();
  const [brands, setBrands] = useState<Brand[]>(MOCK_BRANDS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBrand, setEditingBrand] = useState<Brand | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Tab State
  const [activeTab, setActiveTab] = useState<'VEHICLE' | 'TIRE' | 'RETREAD' | 'RETREADER'>('VEHICLE');

  useEffect(() => {
     if (location.state && (location.state as any).tab) {
         setActiveTab((location.state as any).tab);
     }
  }, [location.state]);

  // Form State
  const [formData, setFormData] = useState<Partial<Brand>>({
    name: '',
    type: 'VEHICLE',
    active: true,
    fantasyName: '',
    cnpj: '',
    contactName: '',
    phone: '',
    email: '',
    street: '',
    number: '',
    district: '',
    state: '',
    zipCode: ''
  });

  const filteredBrands = brands.filter(b => 
    b.type === activeTab &&
    b.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Lista de nomes existentes para autocomplete e validação
  const existingNames = brands
    .filter(b => b.type === activeTab)
    .map(b => b.name);

  const handleOpenModal = (brand?: Brand) => {
    // Bloqueia edição para tipos restritos, apenas permite NOVO
    if (brand && activeTab !== 'RETREADER') {
        return; 
    }

    if (brand) {
      setEditingBrand(brand);
      setFormData(brand);
    } else {
      setEditingBrand(null);
      setFormData({
        name: '',
        type: activeTab,
        active: true,
        fantasyName: '',
        cnpj: '',
        contactName: '',
        phone: '',
        email: '',
        street: '',
        number: '',
        district: '',
        state: '',
        zipCode: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.name) return alert('Razão Social / Nome é obrigatório');
    if (activeTab === 'RETREADER' && !formData.cnpj) return alert('CNPJ é obrigatório para Recapadoras');

    // Verificação de Duplicidade (Case Insensitive)
    const normalizedName = formData.name.trim().toLowerCase();
    const isDuplicate = brands.some(b => 
        b.type === activeTab && 
        b.name.toLowerCase() === normalizedName && 
        b.id !== editingBrand?.id
    );

    if (isDuplicate) {
        alert(`A marca "${formData.name}" já está cadastrada nesta categoria.`);
        return;
    }

    if (editingBrand) {
      setBrands(prev => prev.map(b => b.id === editingBrand.id ? { ...b, ...formData } as Brand : b));
    } else {
      const newBrand: Brand = {
        ...formData,
        id: `b${Date.now()}`,
      } as Brand;
      setBrands(prev => [...prev, newBrand]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Excluir este registro?')) {
      setBrands(prev => prev.filter(b => b.id !== id));
    }
  };

  const getTabLabel = (type: string) => {
      switch(type) {
          case 'VEHICLE': return 'Marcas de Veículos';
          case 'TIRE': return 'Marcas de Pneus';
          case 'RETREAD': return 'Marcas de Bandas';
          case 'RETREADER': return 'Recapadoras';
          default: return '';
      }
  };

  const getTabIcon = (type: string) => {
      switch(type) {
          case 'VEHICLE': return Truck;
          case 'TIRE': return Disc;
          case 'RETREAD': return RefreshCw;
          case 'RETREADER': return Briefcase;
          default: return Disc;
      }
  };

  // Verifica se o nome digitado já existe para feedback visual
  const nameExists = formData.name && existingNames.some(name => name.toLowerCase() === formData.name?.toLowerCase());

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">
              {activeTab === 'RETREADER' ? 'Cadastro de Recapadoras' : 'Cadastro de Marcas'}
          </h1>
          <p className="text-slate-500">
              {activeTab === 'RETREADER' ? 'Gestão de parceiros de recapagem' : 
               'Lista unificada de marcas do sistema'}
          </p>
        </div>
        
        {/* Botão de Adicionar sempre visível, pois "apenas acrescentar" é permitido */}
        <button 
        onClick={() => handleOpenModal()}
        className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors shadow-sm shadow-primary-500/30"
        >
        <Plus size={18} /> Novo Cadastro
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-200">
         <nav className="-mb-px flex space-x-8 overflow-x-auto">
            {(['VEHICLE', 'TIRE', 'RETREAD', 'RETREADER'] as const).map((type) => {
                const Icon = getTabIcon(type);
                return (
                    <button
                        key={type}
                        onClick={() => setActiveTab(type)}
                        className={clsx(
                            "whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors flex items-center gap-2",
                            activeTab === type
                                ? "border-primary-500 text-primary-600"
                                : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
                        )}
                    >
                        <Icon size={18} />
                        {getTabLabel(type)}
                    </button>
                );
            })}
         </nav>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
         <div className="relative">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input 
               type="text" 
               placeholder={`Buscar em ${getTabLabel(activeTab)}...`}
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" 
             />
         </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left whitespace-nowrap">
            <thead className="bg-slate-50 text-xs text-slate-500 uppercase border-b border-slate-100">
                <tr>
                <th className="px-6 py-4">Nome</th>
                {activeTab === 'RETREADER' && (
                    <>
                        <th className="px-6 py-4">Documento</th>
                        <th className="px-6 py-4">Contato</th>
                    </>
                )}
                {activeTab !== 'RETREADER' && <th className="px-6 py-4">Categoria</th>}
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Ações</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
                {filteredBrands.map(brand => (
                <tr key={brand.id} className="hover:bg-slate-50">
                    <td className="px-6 py-4">
                        <span className="font-bold text-slate-800">{brand.name}</span>
                        {brand.fantasyName && <div className="text-xs text-slate-500">{brand.fantasyName}</div>}
                        {activeTab === 'RETREADER' && brand.street && (
                            <div className="text-xs text-slate-500 flex items-center gap-1 mt-1">
                                <MapPin size={10} /> {brand.street}, {brand.number} - {brand.state}
                            </div>
                        )}
                    </td>

                    {activeTab === 'RETREADER' && (
                        <>
                            <td className="px-6 py-4 font-mono text-slate-600">{brand.cnpj || '-'}</td>
                            <td className="px-6 py-4 text-slate-600">
                                {brand.contactName && <div className="font-medium text-xs">{brand.contactName}</div>}
                                <div className="text-xs flex gap-2 mt-1">
                                    {brand.phone && <span title={brand.phone}><Phone size={12}/></span>}
                                    {brand.email && <span title={brand.email}><Mail size={12}/></span>}
                                </div>
                            </td>
                        </>
                    )}

                    {activeTab !== 'RETREADER' && (
                        <td className="px-6 py-4">
                        <span className={clsx(
                            "px-2 py-1 rounded-full text-xs font-bold",
                            brand.type === 'TIRE' ? "bg-blue-50 text-blue-700" :
                            brand.type === 'RETREAD' ? "bg-orange-50 text-orange-700" : 
                            brand.type === 'VEHICLE' ? "bg-purple-50 text-purple-700" : "bg-emerald-50 text-emerald-700"
                        )}>
                            {getTabLabel(brand.type)}
                        </span>
                        </td>
                    )}

                    <td className="px-6 py-4">
                    {brand.active ? (
                        <span className="flex items-center gap-1 text-emerald-600 text-xs font-bold"><CheckCircle size={14}/> Ativo</span>
                    ) : (
                        <span className="flex items-center gap-1 text-red-500 text-xs font-bold"><XCircle size={14}/> Inativo</span>
                    )}
                    </td>
                    <td className="px-6 py-4 text-right flex justify-end gap-2">
                    {activeTab === 'RETREADER' ? (
                        <>
                            <button onClick={() => handleOpenModal(brand)} className="text-blue-500 hover:text-blue-700 p-1"><Edit2 size={16} /></button>
                            <button onClick={() => handleDelete(brand.id)} className="text-red-500 hover:text-red-700 p-1"><Trash2 size={16} /></button>
                        </>
                    ) : (
                        <span className="text-xs text-slate-400 italic">Somente Leitura</span>
                    )}
                    </td>
                </tr>
                ))}
            </tbody>
            </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
          <div className={clsx("bg-white rounded-xl shadow-2xl w-full z-10 p-6 animate-scale-in", activeTab === 'RETREADER' ? "max-w-xl max-h-[90vh] overflow-y-auto" : "max-w-md")}>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-slate-800">{editingBrand ? 'Editar Cadastro' : 'Novo Cadastro'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
            </div>
            
            <div className="space-y-4">
              
              {/* RAZÃO SOCIAL / NOME */}
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">
                    {activeTab === 'RETREADER' ? 'Razão Social' : 'Nome da Marca'}
                </label>
                <div className="relative">
                    <input 
                    type="text" 
                    value={formData.name}
                    list="brand-suggestions"
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    className={clsx(
                        "w-full border rounded-lg px-3 py-2 outline-none focus:border-primary-500",
                        nameExists && !editingBrand ? "border-red-300 bg-red-50 text-red-700" : "border-slate-300"
                    )}
                    placeholder="Digite para buscar ou adicionar..."
                    autoComplete="off"
                    />
                    <datalist id="brand-suggestions">
                        {existingNames.map(name => (
                            <option key={name} value={name} />
                        ))}
                    </datalist>
                </div>
                {nameExists && !editingBrand && (
                    <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                        <AlertCircle size={12} /> Esta marca já está cadastrada.
                    </p>
                )}
              </div>

              {/* CAMPOS ESPECÍFICOS PARA RECAPADORAS */}
              {activeTab === 'RETREADER' && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Fantasia</label>
                            <input 
                                type="text" 
                                value={formData.fantasyName || ''}
                                onChange={e => setFormData({...formData, fantasyName: e.target.value})}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">CNPJ</label>
                            <input 
                                type="text" 
                                value={formData.cnpj || ''}
                                onChange={e => setFormData({...formData, cnpj: e.target.value})}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 font-mono"
                                placeholder="00.000.000/0000-00"
                            />
                        </div>
                    </div>

                    <div className="border-t border-slate-100 my-2 pt-2">
                        <h4 className="text-xs font-bold text-slate-800 uppercase mb-3 flex items-center gap-2"><MapPin size={14} className="text-primary-500"/> Endereço</h4>
                        
                        <div className="grid grid-cols-4 gap-3 mb-3">
                             <div className="col-span-1">
                                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">CEP</label>
                                <input 
                                    type="text" 
                                    value={formData.zipCode || ''}
                                    onChange={e => setFormData({...formData, zipCode: e.target.value})}
                                    className="w-full border border-slate-300 rounded-lg px-2 py-2 outline-none focus:border-primary-500 text-sm"
                                />
                             </div>
                             <div className="col-span-2">
                                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Logradouro</label>
                                <input 
                                    type="text" 
                                    value={formData.street || ''}
                                    onChange={e => setFormData({...formData, street: e.target.value})}
                                    className="w-full border border-slate-300 rounded-lg px-2 py-2 outline-none focus:border-primary-500 text-sm"
                                />
                             </div>
                             <div className="col-span-1">
                                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Número</label>
                                <input 
                                    type="text" 
                                    value={formData.number || ''}
                                    onChange={e => setFormData({...formData, number: e.target.value})}
                                    className="w-full border border-slate-300 rounded-lg px-2 py-2 outline-none focus:border-primary-500 text-sm"
                                />
                             </div>
                        </div>
                        <div className="grid grid-cols-3 gap-3">
                             <div className="col-span-2">
                                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Bairro</label>
                                <input 
                                    type="text" 
                                    value={formData.district || ''}
                                    onChange={e => setFormData({...formData, district: e.target.value})}
                                    className="w-full border border-slate-300 rounded-lg px-2 py-2 outline-none focus:border-primary-500 text-sm"
                                />
                             </div>
                             <div className="col-span-1">
                                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">UF</label>
                                <input 
                                    type="text" 
                                    value={formData.state || ''}
                                    onChange={e => setFormData({...formData, state: e.target.value})}
                                    className="w-full border border-slate-300 rounded-lg px-2 py-2 outline-none focus:border-primary-500 text-sm"
                                    maxLength={2}
                                />
                             </div>
                        </div>
                    </div>

                    <div className="border-t border-slate-100 my-2 pt-2">
                        <h4 className="text-xs font-bold text-slate-800 uppercase mb-3 flex items-center gap-2"><Briefcase size={14} className="text-primary-500"/> Contato Principal</h4>
                        
                        <div className="space-y-3">
                             <div>
                                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Nome Responsável</label>
                                <input 
                                    type="text" 
                                    value={formData.contactName || ''}
                                    onChange={e => setFormData({...formData, contactName: e.target.value})}
                                    className="w-full border border-slate-300 rounded-lg px-2 py-2 outline-none focus:border-primary-500 text-sm"
                                />
                             </div>
                             <div className="grid grid-cols-2 gap-3">
                                 <div>
                                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Email</label>
                                    <input 
                                        type="email" 
                                        value={formData.email || ''}
                                        onChange={e => setFormData({...formData, email: e.target.value})}
                                        className="w-full border border-slate-300 rounded-lg px-2 py-2 outline-none focus:border-primary-500 text-sm"
                                    />
                                 </div>
                                 <div>
                                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Telefone</label>
                                    <input 
                                        type="text" 
                                        value={formData.phone || ''}
                                        onChange={e => setFormData({...formData, phone: e.target.value})}
                                        className="w-full border border-slate-300 rounded-lg px-2 py-2 outline-none focus:border-primary-500 text-sm"
                                    />
                                 </div>
                             </div>
                        </div>
                    </div>
                  </>
              )}

              <div className="flex items-center gap-2 mt-4 pt-4 border-t border-slate-100">
                 <input 
                    type="checkbox" 
                    checked={formData.active} 
                    onChange={e => setFormData({...formData, active: e.target.checked})}
                    className="w-5 h-5 text-primary-600 rounded"
                 />
                 <label className="text-sm text-slate-700 font-medium">Cadastro Ativo</label>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setIsModalOpen(false)} className="flex-1 py-2 text-slate-600 font-bold bg-slate-100 rounded-lg hover:bg-slate-200">Cancelar</button>
              <button onClick={handleSave} className="flex-1 py-2 text-white font-bold bg-primary-600 rounded-lg hover:bg-primary-700 flex items-center justify-center gap-2">
                 <Save size={18} /> Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
