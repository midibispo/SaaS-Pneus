
import React, { useState } from 'react';
import { Role } from '../types';
import { Mail, Lock, Eye, EyeOff, CheckCircle, ArrowLeft, Send } from 'lucide-react';
import { clsx } from 'clsx';

interface LoginProps {
  onLogin: (role: Role) => void;
}

// Credenciais de teste
const TEST_ACCOUNTS = [
  { role: Role.ADMIN, label: 'Gestor', email: 'gestor@frota.com.br', pass: '123456' },
  { role: Role.MECHANIC, label: 'Mecânico', email: 'mecanico@frota.com.br', pass: '123456' },
  { role: Role.AUDITOR, label: 'Auditor', email: 'auditor@frota.com.br', pass: '123456' },
  { role: Role.SUPER_ADMIN, label: 'S. Admin', email: 'admin@dbi.com.br', pass: '123456' },
];

export const LoginPage: React.FC<LoginProps> = ({ onLogin }) => {
  // State for Login View
  const [view, setView] = useState<'LOGIN' | 'FORGOT'>('LOGIN');
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // State for Reset View
  const [resetEmail, setResetEmail] = useState('');
  const [isResetSent, setIsResetSent] = useState(false);

  const handleLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulação de delay de rede
    setTimeout(() => {
      const account = TEST_ACCOUNTS.find(acc => acc.email === email && acc.pass === password);

      if (account) {
        onLogin(account.role);
      } else {
        // Fallback genérico para testes manuais que não usam os botões rápidos
        if (email && password) {
             onLogin(Role.ADMIN);
        } else {
             setError('E-mail ou senha inválidos.');
             setIsLoading(false);
        }
      }
    }, 800);
  };

  const handleResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetEmail) {
        setError('Por favor, informe seu e-mail.');
        return;
    }
    setError('');
    setIsLoading(true);

    // Simulação de envio
    setTimeout(() => {
        setIsLoading(false);
        setIsResetSent(true);
    }, 1500);
  };

  const fillCredentials = (acc: typeof TEST_ACCOUNTS[0]) => {
    setEmail(acc.email);
    setPassword(acc.pass);
    setError('');
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-slate-900 font-sans">
      
      {/* Background Gradient Blue */}
      <div className="absolute inset-0 z-0 bg-gradient-to-br from-slate-900 via-[#0f172a] to-[#1e3a8a]"></div>
      
      {/* Texture Overlay (Optional subtle noise/pattern) */}
      <div className="absolute inset-0 z-0 opacity-20" style={{backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '40px 40px'}}></div>

      {/* Main Card */}
      <div className="relative z-10 w-full max-w-[420px] bg-white/95 backdrop-blur-2xl rounded-[32px] shadow-2xl p-10 m-4 border border-white/20 animate-scale-in">
        
        {/* Header / Logo */}
        <div className="flex flex-col items-center mb-8 select-none">
          <div className="text-4xl font-black text-[#1e293b] tracking-tighter leading-none flex items-center">
            FR<span className="text-[#f97316]">O</span>TA
          </div>
          <div className="text-[10px] font-bold text-[#1e293b] tracking-[0.4em] leading-none ml-1 mt-1 opacity-80 uppercase">
            Inteligente
          </div>
        </div>

        {/* VIEW: LOGIN */}
        {view === 'LOGIN' && (
            <div className="animate-fade-in">
                <form onSubmit={handleLogin} className="space-y-6">
                
                {/* Email Input */}
                <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase ml-1">E-mail</label>
                    <div className="relative group">
                    <Mail className="absolute left-0 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-[#1e3a8a] transition-colors" size={20} />
                    <input 
                        type="email" 
                        placeholder="seunome@empresa.com.br" 
                        className="w-full pl-8 pr-4 py-3 bg-transparent border-b-2 border-slate-200 focus:border-[#1e3a8a] outline-none text-slate-800 placeholder-slate-300 font-medium transition-all"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    </div>
                </div>

                {/* Password Input */}
                <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-500 uppercase ml-1">Senha</label>
                    <div className="relative group">
                    <Lock className="absolute left-0 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-[#1e3a8a] transition-colors" size={20} />
                    <input 
                        type={showPassword ? "text" : "password"} 
                        placeholder="********" 
                        className="w-full pl-8 pr-10 py-3 bg-transparent border-b-2 border-slate-200 focus:border-[#1e3a8a] outline-none text-slate-800 placeholder-slate-300 font-medium transition-all"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    <button 
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-0 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-2"
                    >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                    </div>
                </div>

                {error && (
                    <div className="text-red-500 text-xs font-bold text-center bg-red-50 py-2 rounded animate-pulse">
                    {error}
                    </div>
                )}

                <div className="flex justify-end items-center text-sm">
                    <button 
                        type="button"
                        onClick={() => { setView('FORGOT'); setError(''); }}
                        className="text-[#1e3a8a] hover:text-[#f97316] font-bold text-xs transition-colors"
                    >
                    Esqueci minha senha
                    </button>
                </div>

                <button 
                    type="submit" 
                    disabled={isLoading}
                    className="w-full bg-[#1e3a8a] hover:bg-[#1e40af] text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-900/20 transition-all active:scale-95 flex items-center justify-center gap-2 uppercase tracking-wide text-sm"
                >
                    {isLoading ? (
                    <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                    ) : (
                    'Entrar'
                    )}
                </button>
                </form>

                {/* Quick Access for Demo (Testing purposes) */}
                <div className="mt-10 pt-6 border-t border-slate-100">
                <p className="text-[10px] text-center text-slate-400 uppercase font-bold tracking-wider mb-3">
                    Acesso Rápido (Ambiente de Teste)
                </p>
                <div className="flex justify-center gap-2 flex-wrap">
                    {TEST_ACCOUNTS.map((acc) => (
                    <button
                        key={acc.role}
                        onClick={() => fillCredentials(acc)}
                        className="text-[10px] px-3 py-1.5 rounded-lg bg-slate-50 text-slate-500 hover:bg-[#1e3a8a] hover:text-white transition-colors font-bold border border-slate-200 uppercase tracking-wide"
                        title={`${acc.email} / ${acc.pass}`}
                    >
                        {acc.label}
                    </button>
                    ))}
                </div>
                </div>
            </div>
        )}

        {/* VIEW: FORGOT PASSWORD */}
        {view === 'FORGOT' && (
            <div className="animate-fade-in">
                {!isResetSent ? (
                    <>
                        <div className="mb-6 text-center">
                            <h3 className="text-xl font-bold text-slate-800 mb-2">Recuperar Senha</h3>
                            <p className="text-sm text-slate-500">Informe seu e-mail para receber as instruções de redefinição.</p>
                        </div>

                        <form onSubmit={handleResetSubmit} className="space-y-6">
                            <div className="space-y-1">
                                <label className="text-xs font-bold text-slate-500 uppercase ml-1">E-mail Cadastrado</label>
                                <div className="relative group">
                                <Mail className="absolute left-0 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-[#1e3a8a] transition-colors" size={20} />
                                <input 
                                    type="email" 
                                    placeholder="seunome@empresa.com.br" 
                                    className="w-full pl-8 pr-4 py-3 bg-transparent border-b-2 border-slate-200 focus:border-[#1e3a8a] outline-none text-slate-800 placeholder-slate-300 font-medium transition-all"
                                    value={resetEmail}
                                    onChange={(e) => setResetEmail(e.target.value)}
                                    autoFocus
                                />
                                </div>
                            </div>

                            {error && (
                                <div className="text-red-500 text-xs font-bold text-center bg-red-50 py-2 rounded animate-pulse">
                                {error}
                                </div>
                            )}

                            <button 
                                type="submit" 
                                disabled={isLoading}
                                className="w-full bg-[#f97316] hover:bg-[#ea580c] text-white font-bold py-4 rounded-xl shadow-lg shadow-orange-500/20 transition-all active:scale-95 flex items-center justify-center gap-2 uppercase tracking-wide text-sm"
                            >
                                {isLoading ? (
                                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                                ) : (
                                <>
                                    <Send size={18} /> Enviar Solicitação
                                </>
                                )}
                            </button>
                        </form>
                    </>
                ) : (
                    <div className="text-center py-8 animate-scale-in">
                        <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4 text-emerald-600">
                            <CheckCircle size={32} />
                        </div>
                        <h3 className="text-xl font-bold text-slate-800 mb-2">Solicitação Enviada!</h3>
                        <p className="text-sm text-slate-500 mb-6">
                            Verifique sua caixa de entrada no e-mail <strong>{resetEmail}</strong> para redefinir sua senha.
                        </p>
                    </div>
                )}

                <div className="mt-6 text-center">
                    <button 
                        onClick={() => { setView('LOGIN'); setIsResetSent(false); setResetEmail(''); setError(''); }}
                        className="text-slate-400 hover:text-slate-600 font-bold text-xs flex items-center justify-center gap-2 mx-auto transition-colors"
                    >
                        <ArrowLeft size={14} /> Voltar para Login
                    </button>
                </div>
            </div>
        )}

      </div>
      
      {/* Footer text outside card */}
      <div className="absolute bottom-4 text-white/60 text-xs font-medium tracking-wide">
        © 2024 Sistema de Gestão de Pneus – Frota Inteligente
      </div>
    </div>
  );
};
