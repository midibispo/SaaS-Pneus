
import React, { useState, useEffect } from 'react';
import { AlertTriangle, AlertCircle, CheckCircle, Settings, X, Save, Sliders, Info, ArrowRight } from 'lucide-react';
import { AlertRule, MaintenanceType } from '../types';
import { STANDARD_RULES, MOCK_NOTIFICATIONS, MOCK_VEHICLES, MOCK_MAINTENANCE } from '../services/mockData';
import { useNavigate, useLocation } from 'react-router-dom';

export const AlertsPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const isFromWelcome = location.state?.fromWelcome;

  // Inicializa regras do localStorage ou usa o padrão
  const [rules, setRules] = useState<AlertRule[]>(() => {
    const saved = localStorage.getItem('dbi_rules');
    return saved ? JSON.parse(saved) : STANDARD_RULES;
  });

  const [activeAlerts, setActiveAlerts] = useState<any[]>([]);

  // Inicializa os alertas filtrando pelos que tem regra ativa e GERA alertas dinâmicos
  useEffect(() => {
    // 1. Alertas Mockados (Base)
    const mockAlerts = MOCK_NOTIFICATIONS.filter(alert => {
        const rule = rules.find(r => r.id === alert.ruleId);
        return rule ? rule.isActive : true; 
    });

    // 2. Geração Dinâmica: Alerta de Calibragem (Regra r5)
    let dynamicAlerts: any[] = [];
    const calibrationRule = rules.find(r => r.name === 'Intervalo de Calibragem' || r.id === 'r5');

    if (calibrationRule && calibrationRule.isActive) {
        const limitDays = calibrationRule.value;
        const today = new Date();

        MOCK_VEHICLES.forEach(vehicle => {
            // Encontra a última calibragem deste veículo
            const lastPressureCheck = MOCK_MAINTENANCE
                .filter(r => r.vehicleId === vehicle.id && r.type === MaintenanceType.PRESSURE)
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

            let daysDiff = 0;
            let lastDateStr = 'Nunca';

            if (lastPressureCheck) {
                const lastDate = new Date(lastPressureCheck.date);
                const timeDiff = today.getTime() - lastDate.getTime();
                daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
                lastDateStr = lastPressureCheck.date;
            } else {
                // Se nunca foi calibrado (no mock), assume uma data muito antiga para forçar o alerta, ou ignora se for veículo novo
                // Para demo, vamos assumir 30 dias se não houver registro
                daysDiff = 30; 
            }

            if (daysDiff > limitDays) {
                dynamicAlerts.push({
                    id: `dyn-cal-${vehicle.id}-${Date.now()}`,
                    ruleId: calibrationRule.id,
                    severity: calibrationRule.severity.toLowerCase(),
                    title: 'Calibragem Atrasada',
                    date: 'Hoje',
                    desc: `Veículo ${vehicle.plate} sem calibragem há ${daysDiff} dias (Limite: ${limitDays} dias).`,
                    link: '/maintenance' // Link para resolver
                });
            }
        });
    }

    setActiveAlerts([...dynamicAlerts, ...mockAlerts]);
  }, [rules]); 

  // Se veio do Welcome, abre o modal automaticamente
  useEffect(() => {
      if (isFromWelcome) {
          setIsRulesModalOpen(true);
      }
  }, [isFromWelcome]);

  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);

  const handleToggleRule = (id: string) => {
      setRules(prev => prev.map(r => r.id === id ? { ...r, isActive: !r.isActive } : r));
  };

  const handleUpdateRuleValue = (id: string, newValue: number) => {
      setRules(prev => prev.map(r => r.id === id ? { ...r, value: newValue } : r));
  };

  const saveRules = () => {
      localStorage.setItem('dbi_rules', JSON.stringify(rules));
      
      // Lógica de Setup Inicial: Salva flag e redireciona para Dashboard
      localStorage.setItem('dbi_setup_complete', 'true');
      
      // Dispara evento para o App.tsx saber que o setup acabou sem precisar de reload
      window.dispatchEvent(new Event('dbi:setupComplete'));
      
      setIsRulesModalOpen(false);
      
      if (isFromWelcome) {
          navigate('/dashboard', { replace: true });
      } else {
          alert("Regras atualizadas com sucesso!");
          // Recarrega a lógica do useEffect
          const calibrationRule = rules.find(r => r.id === 'r5');
          if (calibrationRule) {
             // Força re-render simples via state update implícito se necessário, mas o useEffect [rules] já cuida disso
          }
      }
  };

  const handleDismissAlert = (id: number | string) => {
      setActiveAlerts(prev => prev.filter(a => a.id !== id));
  };

  const activeRulesSummary = rules.filter(r => r.isActive);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-800">Alertas e Regras</h1>
           <p className="text-slate-500">Notificações operacionais e configuração de parâmetros de alerta</p>
        </div>
        <button 
            onClick={() => setIsRulesModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg text-slate-600 hover:text-primary-600 hover:border-primary-200 hover:bg-slate-50 font-medium transition-all shadow-sm"
        >
            <Settings size={18} /> Configurar Regras
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Active Alerts List */}
          <div className="lg:col-span-2 space-y-4">
              <h3 className="font-bold text-slate-800 uppercase text-sm mb-2">Alertas Ativos</h3>
              {activeAlerts.length > 0 ? (
                  activeAlerts.map(alert => (
                    <div key={alert.id} className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex gap-4 items-start animate-fade-in">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                            alert.severity === 'high' ? 'bg-red-100 text-red-600' : 
                            alert.severity === 'medium' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'
                        }`}>
                            {alert.severity === 'high' ? <AlertTriangle size={20} /> : <AlertCircle size={20} />}
                        </div>
                        <div className="flex-1">
                            <div className="flex justify-between items-start">
                                <h4 className="font-bold text-slate-800">{alert.title}</h4>
                                <span className="text-xs text-slate-400 font-medium">{alert.date}</span>
                            </div>
                            <p className="text-sm text-slate-600 mt-1">{alert.desc}</p>
                            <div className="flex gap-3 mt-3">
                                <button 
                                    onClick={() => handleDismissAlert(alert.id)}
                                    className="text-xs font-bold text-slate-400 hover:text-red-500 transition-colors"
                                >
                                    Ignorar
                                </button>
                                {alert.link && (
                                    <button 
                                        onClick={() => navigate(alert.link)}
                                        className="text-xs font-bold text-primary-600 hover:text-primary-800 transition-colors flex items-center gap-1"
                                    >
                                        Resolver <ArrowRight size={12}/>
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                  ))
              ) : (
                  <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-200 animate-fade-in">
                      <CheckCircle className="mx-auto text-emerald-500 mb-3" size={32} />
                      <h3 className="text-slate-800 font-bold">Tudo Certo!</h3>
                      <p className="text-slate-500 text-sm">Nenhum alerta ativo no momento.</p>
                  </div>
              )}
          </div>

          {/* Rules Configuration Summary */}
          <div className="space-y-4">
              <h3 className="font-bold text-slate-800 uppercase text-sm mb-2">Regras Ativas (Resumo)</h3>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 space-y-6">
                  {activeRulesSummary.length > 0 ? (
                      activeRulesSummary.slice(0, 5).map(rule => (
                        <div key={rule.id}>
                            <div className="flex justify-between items-center mb-1">
                                <h4 className="font-bold text-slate-700 text-sm">{rule.name}</h4>
                                <span className="text-xs font-bold text-primary-600 bg-primary-50 px-2 py-0.5 rounded-full">{rule.value} {rule.unit}</span>
                            </div>
                            <p className="text-xs text-slate-500 mb-2">{rule.description}</p>
                            <div className="w-full bg-slate-100 rounded-full h-1.5">
                                <div className={`h-1.5 rounded-full w-2/3 ${
                                    rule.severity === 'HIGH' ? 'bg-red-500' : 
                                    rule.severity === 'MEDIUM' ? 'bg-orange-500' : 'bg-blue-500'
                                }`}></div>
                            </div>
                        </div>
                      ))
                  ) : (
                      <p className="text-sm text-slate-400 text-center py-4">Nenhuma regra ativa.</p>
                  )}
                  
                  <button 
                    onClick={() => setIsRulesModalOpen(true)}
                    className="w-full py-2 bg-slate-50 text-slate-600 text-xs font-bold rounded-lg hover:bg-slate-100"
                  >
                      Gerenciar Todas as Regras
                  </button>
              </div>
          </div>
      </div>

      {/* Rules Management Modal */}
      {isRulesModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => !isFromWelcome && setIsRulesModalOpen(false)}></div>
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl z-10 overflow-hidden animate-scale-in flex flex-col max-h-[90vh]">
                <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center shrink-0">
                    <div className="flex items-center gap-3">
                        <div className="bg-white p-2 rounded-lg shadow-sm border border-slate-200 text-slate-600">
                            <Sliders size={20} />
                        </div>
                        <div>
                            <h3 className="font-bold text-lg text-slate-800">
                                {isFromWelcome ? 'Configuração Inicial de Regras' : 'Gerenciar Regras de Alerta'}
                            </h3>
                            <p className="text-xs text-slate-500">Defina os parâmetros para geração automática de notificações</p>
                        </div>
                    </div>
                    {!isFromWelcome && (
                        <button onClick={() => setIsRulesModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
                    )}
                </div>
                
                <div className="p-6 overflow-y-auto flex-1 bg-slate-50/50">
                    <div className="space-y-4">
                        {rules.map(rule => (
                            <div key={rule.id} className={`bg-white p-4 rounded-xl border transition-all ${rule.isActive ? 'border-slate-200 shadow-sm' : 'border-slate-100 opacity-60 grayscale'}`}>
                                <div className="flex items-start justify-between gap-4">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-1">
                                            <h4 className="font-bold text-slate-800">{rule.name}</h4>
                                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                                                rule.severity === 'HIGH' ? 'bg-red-100 text-red-600' : 
                                                rule.severity === 'MEDIUM' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'
                                            }`}>
                                                {rule.severity === 'HIGH' ? 'Crítico' : rule.severity === 'MEDIUM' ? 'Médio' : 'Baixo'}
                                            </span>
                                        </div>
                                        <p className="text-sm text-slate-500 mb-3">{rule.description}</p>
                                        
                                        <div className="flex items-center gap-3">
                                            <label className="text-xs font-bold text-slate-600 uppercase">Valor Limite:</label>
                                            <div className="flex items-center gap-2">
                                                <input 
                                                    type="number" 
                                                    value={rule.value} 
                                                    onChange={(e) => handleUpdateRuleValue(rule.id, Number(e.target.value))}
                                                    disabled={!rule.isActive}
                                                    className="w-20 px-2 py-1 border border-slate-300 rounded text-center font-bold text-slate-800 focus:border-primary-500 outline-none"
                                                />
                                                <span className="text-sm font-bold text-slate-500">{rule.unit}</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex flex-col items-center gap-2">
                                        <label className="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox" checked={rule.isActive} onChange={() => handleToggleRule(rule.id)} className="sr-only peer" />
                                            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                                        </label>
                                        <span className="text-[10px] font-bold text-slate-400 uppercase">{rule.isActive ? 'Ativo' : 'Inativo'}</span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="p-4 bg-white border-t border-slate-100 flex justify-end gap-3 shrink-0">
                    {!isFromWelcome && (
                        <button onClick={() => setIsRulesModalOpen(false)} className="px-6 py-2 text-slate-600 font-bold bg-slate-100 rounded-lg hover:bg-slate-200">Cancelar</button>
                    )}
                    <button onClick={saveRules} className="px-6 py-2 text-white font-bold bg-primary-600 rounded-lg hover:bg-primary-700 flex items-center gap-2 shadow-lg shadow-primary-500/20">
                        <Save size={18} /> 
                        {isFromWelcome ? 'Salvar e Ir para Dashboard' : 'Salvar Configurações'}
                        {isFromWelcome && <ArrowRight size={18} />}
                    </button>
                </div>
            </div>
          </div>
      )}
    </div>
  );
};
