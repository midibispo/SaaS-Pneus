
import React, { useState, useMemo } from 'react';
import { MOCK_TIRES, MOCK_BRANDS, MOCK_VEHICLES } from '../services/mockData';
import { Tire, TireStatus, TireCondition, Brand } from '../types';
import { Plus, Edit2, Trash2, Search, Save, X } from 'lucide-react';
import { clsx } from 'clsx';

const TIRE_SIZES = [
  "275/80R22.5", "295/80R22.5", "315/80R22.5", "11R22.5", "12R22.5",
  "255/70R22.5", "215/75R17.5", "385/65R22.5", "385/55R22.5",
  "425/65R22.5", "245/70R19.5", "275/70R22.5", "305/70R22.5",
  "445/65R22.5", "13R22.5", "14R20"
];

export const ManageTiresPage: React.FC = () => {
  const [tires, setTires] = useState<Tire[]>(MOCK_TIRES);
  // Local state for brands to allow adding new ones immediately
  const [availableBrands, setAvailableBrands] = useState<Brand[]>(MOCK_BRANDS.filter(b => b.type === 'TIRE'));
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTire, setEditingTire] = useState<Tire | null>(null);
  
  // New Brand State
  const [isAddingBrand, setIsAddingBrand] = useState(false);
  const [newBrandName, setNewBrandName] = useState('');

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [brandFilter, setBrandFilter] = useState('');
  const [vehicleFilter, setVehicleFilter] = useState('');

  // Form State
  const [formData, setFormData] = useState<Partial<Tire>>({
    serialNumber: '',
    brand: '',
    model: '',
    size: '295/80R22.5',
    status: TireStatus.STOCK,
    condition: TireCondition.NEW,
    lifeCount: 0,
    currentDepth: 16,
    purchaseCost: 0
  });

  // Dynamic Model List
  const availableModels = useMemo(() => {
    const models = new Set(tires.map(t => t.model));
    return Array.from(models).sort();
  }, [tires]);

  const filteredTires = tires.filter(t => {
    const matchesSearch = t.serialNumber.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBrand = brandFilter ? t.brand === brandFilter : true;
    const matchesVehicle = vehicleFilter ? t.vehicleId === vehicleFilter : true;
    return matchesSearch && matchesBrand && matchesVehicle;
  });

  const handleOpenModal = (tire?: Tire) => {
    if (tire) {
      setEditingTire(tire);
      setFormData(tire);
    } else {
      setEditingTire(null);
      setFormData({
        serialNumber: '',
        brand: availableBrands[0]?.name || '',
        model: '',
        size: '295/80R22.5',
        status: TireStatus.STOCK,
        condition: TireCondition.NEW,
        lifeCount: 0,
        currentDepth: 16,
        purchaseCost: 0
      });
    }
    setIsAddingBrand(false);
    setIsModalOpen(true);
  };

  const handleBrandChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const val = e.target.value;
      if (val === 'NEW_BRAND_OPTION') {
          setIsAddingBrand(true);
          setNewBrandName('');
      } else {
          setIsAddingBrand(false);
          setFormData({...formData, brand: val});
      }
  };

  const saveNewBrand = () => {
      if (!newBrandName.trim()) return alert("Digite o nome da marca.");
      
      // Standardize: Capitalize First Letter
      const formattedName = newBrandName.trim().charAt(0).toUpperCase() + newBrandName.trim().slice(1);
      
      // Check duplicate
      if (availableBrands.some(b => b.name.toLowerCase() === formattedName.toLowerCase())) {
          alert("Marca já existe na lista.");
          setFormData({...formData, brand: formattedName}); // Select existing
          setIsAddingBrand(false);
          return;
      }

      // Add to list
      const newBrandObj: Brand = {
          id: `nb${Date.now()}`,
          name: formattedName,
          type: 'TIRE',
          active: true
      };
      
      setAvailableBrands(prev => [...prev, newBrandObj].sort((a,b) => a.name.localeCompare(b.name)));
      setFormData({...formData, brand: formattedName});
      setIsAddingBrand(false);
  };

  const handleSave = () => {
    if (!formData.serialNumber || !formData.brand || !formData.model) return alert('Preencha os campos obrigatórios: Fogo, Marca e Modelo');

    const normalizedSerial = formData.serialNumber.trim();
    const normalizedModel = formData.model.trim().toUpperCase();

    const duplicate = tires.find(t => t.serialNumber === normalizedSerial && t.id !== editingTire?.id);
    
    if (duplicate) {
        alert("ERRO DE VALIDAÇÃO: Já existe um pneu cadastrado com este número de fogo.");
        return;
    }

    if (editingTire) {
      setTires(prev => prev.map(t => t.id === editingTire.id ? { ...t, ...formData, serialNumber: normalizedSerial, model: normalizedModel } as Tire : t));
    } else {
      const newTire: Tire = {
        ...formData,
        serialNumber: normalizedSerial,
        model: normalizedModel,
        id: `t${Date.now()}`,
        accumulatedMileage: 0,
        originalDepth: 16,
        currentPressure: 0,
        location: 'Estoque'
      } as Tire;
      setTires(prev => [...prev, newTire]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Atenção: Excluir um pneu apagará todo seu histórico. Confirmar?')) {
      setTires(prev => prev.filter(t => t.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Cadastro de Pneus (Master)</h1>
          <p className="text-slate-500">Gestão administrativa de todos os ativos</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors"
        >
          <Plus size={18} /> Cadastrar Pneu
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4">
         <div className="relative flex-1">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input 
               type="text" 
               placeholder="Buscar por número de fogo..." 
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" 
             />
         </div>
         <div className="flex gap-2">
            <select 
              value={brandFilter}
              onChange={e => setBrandFilter(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white outline-none focus:border-primary-500"
            >
               <option value="">Todas as Marcas</option>
               {availableBrands.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
            </select>
            <select 
              value={vehicleFilter}
              onChange={e => setVehicleFilter(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white outline-none focus:border-primary-500"
            >
               <option value="">Todos os Veículos</option>
               {MOCK_VEHICLES.map(v => <option key={v.id} value={v.id}>{v.plate}</option>)}
            </select>
         </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left whitespace-nowrap">
            <thead className="bg-slate-50 text-xs text-slate-500 uppercase border-b border-slate-100">
                <tr>
                <th className="px-6 py-4">Fogo (ID)</th>
                <th className="px-6 py-4">Marca / Modelo</th>
                <th className="px-6 py-4">Medida</th>
                <th className="px-6 py-4">Condição</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Localização</th>
                <th className="px-6 py-4 text-right">Ações</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
                {filteredTires.map(tire => (
                <tr key={tire.id} className="hover:bg-slate-50">
                    <td className="px-6 py-4 font-bold text-slate-800 font-mono">{tire.serialNumber}</td>
                    <td className="px-6 py-4 text-slate-600">
                        {tire.lifeCount === 0 ? (
                            <span>{tire.brand} {tire.model}</span>
                        ) : (
                            <div className="flex flex-col">
                                <span className="font-bold text-slate-700">{tire.treadBrand || 'Recapado S/ Marca'}</span>
                                <span className="text-[10px] text-slate-400">Carcaça: {tire.brand} {tire.model}</span>
                            </div>
                        )}
                    </td>
                    <td className="px-6 py-4 text-slate-600">{tire.size}</td>
                    <td className="px-6 py-4">
                        <span className={clsx(
                            "px-2 py-1 rounded-full text-xs font-bold",
                            tire.lifeCount === 0 ? "bg-emerald-50 text-emerald-700" : "bg-blue-50 text-blue-700"
                        )}>
                            V{tire.lifeCount} ({tire.condition})
                        </span>
                    </td>
                    <td className="px-6 py-4">
                        <span className={clsx(
                            "font-medium",
                            tire.status === TireStatus.INSTALLED ? "text-emerald-600" :
                            tire.status === TireStatus.SCRAP ? "text-red-600" : "text-slate-600"
                        )}>{tire.status}</span>
                    </td>
                    <td className="px-6 py-4 text-slate-500">
                        {tire.location} {tire.position ? `(${tire.position})` : ''}
                    </td>
                    <td className="px-6 py-4 text-right flex justify-end gap-2">
                    <button onClick={() => handleOpenModal(tire)} className="text-blue-500 hover:text-blue-700 p-1"><Edit2 size={16} /></button>
                    <button onClick={() => handleDelete(tire.id)} className="text-red-500 hover:text-red-700 p-1"><Trash2 size={16} /></button>
                    </td>
                </tr>
                ))}
            </tbody>
            </table>
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg z-10 p-6 animate-scale-in">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-slate-800">{editingTire ? 'Editar Cadastro de Pneu' : 'Novo Pneu'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Número de Fogo</label>
                    <input 
                    type="text" 
                    value={formData.serialNumber}
                    onChange={e => setFormData({...formData, serialNumber: e.target.value})}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 font-mono"
                    />
                </div>
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Medida</label>
                    <select 
                        value={formData.size}
                        onChange={e => setFormData({...formData, size: e.target.value})}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                    >
                        {TIRE_SIZES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Marca (Carcaça)</label>
                  {!isAddingBrand ? (
                      <select 
                        value={formData.brand}
                        onChange={handleBrandChange}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                      >
                        <option value="">Selecione...</option>
                        {availableBrands.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
                        <option disabled>──────────</option>
                        <option value="NEW_BRAND_OPTION" className="font-bold text-primary-600">+ Cadastrar Nova Marca...</option>
                      </select>
                  ) : (
                      <div className="flex gap-2">
                          <input 
                            type="text" 
                            value={newBrandName}
                            onChange={(e) => setNewBrandName(e.target.value)}
                            placeholder="Nova Marca"
                            className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                            autoFocus
                          />
                          <button onClick={saveNewBrand} className="px-3 bg-primary-600 text-white rounded-lg text-xs font-bold">OK</button>
                          <button onClick={() => setIsAddingBrand(false)} className="px-2 text-slate-400 hover:text-slate-600"><X size={16}/></button>
                      </div>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Modelo</label>
                  <input 
                    type="text" 
                    value={formData.model}
                    onChange={e => setFormData({...formData, model: e.target.value})}
                    list="tire-model-suggestions"
                    placeholder="Digite o modelo..."
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 uppercase"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">O sistema aprenderá novos modelos automaticamente.</p>
                  <datalist id="tire-model-suggestions">
                      {availableModels.map(m => <option key={m} value={m} />)}
                  </datalist>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Custo Compra (R$)</label>
                    <input 
                      type="number" 
                      value={formData.purchaseCost}
                      onChange={e => setFormData({...formData, purchaseCost: Number(e.target.value)})}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Sulco Inicial (mm)</label>
                    <input 
                      type="number" 
                      value={formData.currentDepth} // Using current depth as init for new
                      onChange={e => setFormData({...formData, currentDepth: Number(e.target.value)})}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                    />
                 </div>
              </div>

              <div>
                 <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status Inicial</label>
                 <select 
                    value={formData.status}
                    onChange={e => setFormData({...formData, status: e.target.value as any})}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                    disabled={!!editingTire} 
                 >
                    <option value={TireStatus.STOCK}>Em Estoque</option>
                    <option value={TireStatus.INSTALLED}>Instalado (Requer Veículo)</option>
                 </select>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setIsModalOpen(false)} className="flex-1 py-2 text-slate-600 font-bold bg-slate-100 rounded-lg hover:bg-slate-200">Cancelar</button>
              <button onClick={handleSave} className="flex-1 py-2 text-white font-bold bg-primary-600 rounded-lg hover:bg-primary-700 flex items-center justify-center gap-2">
                 <Save size={18} /> Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
