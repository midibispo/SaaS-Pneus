
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, TireStatus, Tire, TreadType, Vehicle, MaintenanceType, MaintenanceRecord, TireCondition } from '../types';
import { MOCK_TIRES, MOCK_VEHICLES, VEHICLE_LAYOUTS, MOCK_MAINTENANCE, MOCK_BRANDS } from '../services/mockData';
import { reconstructTireLives } from '../services/calculationRules';
import { Search, CheckCircle, XCircle, RefreshCw, Trash2, ArrowRight, Truck, LayoutList, Grid, History, Calendar, Wrench, AlertTriangle, ChevronDown, ChevronRight, Circle, Edit2, MapPin, MoreVertical, ArrowRightLeft, Plus, X, Disc, Save, Gauge, PlayCircle, StopCircle, ThumbsUp, ThumbsDown, DollarSign } from 'lucide-react';
import { clsx } from 'clsx';

export const LifecyclePage: React.FC<{ user: User }> = ({ user }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TireStatus>(TireStatus.INSTALLED);
  const [viewMode, setViewMode] = useState<'LIST' | 'GROUP_VEHICLE'>('LIST');
  const [expandedVehicles, setExpandedVehicles] = useState<Set<string>>(new Set());
  
  // Local State for Data Manipulation (Simulating DB)
  const [localTires, setLocalTires] = useState<Tire[]>(MOCK_TIRES);
  const [localMaintenance, setLocalMaintenance] = useState<MaintenanceRecord[]>(MOCK_MAINTENANCE);

  // Modals Data State
  const [historyModalTire, setHistoryModalTire] = useState<Tire | null>(null);

  // --- ACTIONS STATE ---
  // Move/Rotate Modal
  const [moveModalTire, setMoveModalTire] = useState<Tire | null>(null);
  const [moveTargetPosition, setMoveTargetPosition] = useState('');
  
  // Retread/Scrap Modal (Sending TO Retread/Scrap/Stock)
  const [removalModalTire, setRemovalModalTire] = useState<Tire | null>(null);
  const [removalAction, setRemovalAction] = useState<'RETREAD' | 'SCRAP' | 'STOCK' | null>(null);
  const [opDate, setOpDate] = useState(new Date().toISOString().split('T')[0]);
  const [opKm, setOpKm] = useState(0);
  const [opReason, setOpReason] = useState('');

  // Return From Retread Modal (Process Return)
  const [returnModalTire, setReturnModalTire] = useState<Tire | null>(null);
  const [returnForm, setReturnForm] = useState({
      date: new Date().toISOString().split('T')[0],
      result: 'APPROVED' as 'APPROVED' | 'REJECTED',
      cost: 0,
      retreader: '', // NEW: Recapadora
      treadBrand: '',
      treadModel: '',
      treadType: 'LISA' as TreadType, // NEW: Tipo de Banda
      newDepth: 12,
      rejectionReason: '',
      detailedReason: '' 
  });

  // Data for Dropdowns
  const retreaders = MOCK_BRANDS.filter(b => b.type === 'RETREADER');
  const treadBrands = MOCK_BRANDS.filter(b => b.type === 'RETREAD');
  const treadModels = ["KMAX D", "KMAX S", "VL130", "VT110", "BDL", "BDR-HG", "R168", "ZA65"]; // Mock list for dropdown

  // Install Modal State
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [installForm, setInstallForm] = useState({
      tireId: '',
      vehicleId: '',
      position: '',
      date: new Date().toISOString().split('T')[0],
      odometer: 0,
      depth: 0
  });

  // Filter tires based on active tab using local state
  const filteredTires = localTires.filter(t => t.status === activeTab);
  const stockTires = localTires.filter(t => t.status === TireStatus.STOCK);

  const toggleVehicle = (vehicleId: string) => {
    const newExpanded = new Set(expandedVehicles);
    if (newExpanded.has(vehicleId)) {
        newExpanded.delete(vehicleId);
    } else {
        newExpanded.add(vehicleId);
    }
    setExpandedVehicles(newExpanded);
  };

  // --- Logic Helpers ---

  const getValidPositions = (vehicleId?: string) => {
      if (!vehicleId) return [];
      const vehicle = MOCK_VEHICLES.find(v => v.id === vehicleId);
      if (!vehicle || !vehicle.type) return [];
      
      const layout = VEHICLE_LAYOUTS[vehicle.type];
      if (!layout) return [];

      let positions: string[] = [];
      layout.forEach((axle, index) => {
          const axleNum = index + 1;
          if (axle.isDual) {
              positions.push(`${axleNum}L-OUT`, `${axleNum}L-IN`, `${axleNum}R-IN`, `${axleNum}R-OUT`);
          } else {
              positions.push(`${axleNum}L`, `${axleNum}R`);
          }
      });
      return positions;
  };

  const isFrontAxle = (pos: string) => pos.startsWith('1');

  // Helper to extract last 3 movements for the table column
  const getLastMovements = (tire: Tire) => {
      return localMaintenance
        .filter(r => (r.tireId === tire.id || r.tireId === tire.serialNumber) && 
                     [MaintenanceType.MOUNT, MaintenanceType.ROTATION, MaintenanceType.DISMOUNT].includes(r.type))
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 3);
  };

  // Helper Display Brand Logic
  const getTireBrandDisplay = (tire: Tire) => {
      if (tire.lifeCount === 0) {
          return <span className="text-slate-600">{tire.brand} {tire.model}</span>;
      }
      return (
          <div className="flex flex-col">
              <span className="font-bold text-slate-700">{tire.treadBrand || 'Banda N/A'}</span>
              <span className="text-[10px] text-slate-400">Carcaça: {tire.brand}</span>
          </div>
      );
  };

  // --- Handlers for Opening Modals ---

  const openMoveModal = (tire: Tire) => {
      setMoveModalTire(tire);
      setMoveTargetPosition('');
  };

  const openRemovalModal = (tire: Tire, action: 'RETREAD' | 'SCRAP' | 'STOCK') => {
      setRemovalModalTire(tire);
      setRemovalAction(action);
      setOpReason('');
      
      // Try to find current vehicle odometer
      const vehicle = MOCK_VEHICLES.find(v => v.id === tire.vehicleId);
      setOpKm(vehicle ? vehicle.odometer : 0);
  };

  const openReturnModal = (tire: Tire) => {
      setReturnModalTire(tire);
      setReturnForm({
          date: new Date().toISOString().split('T')[0],
          result: 'APPROVED',
          cost: 0,
          retreader: '',
          treadBrand: '',
          treadModel: '',
          treadType: TreadType.LISA,
          newDepth: 12,
          rejectionReason: '',
          detailedReason: ''
      });
  };

  // --- Handlers for Confirming Actions ---

  const handleConfirmMove = () => {
      if (!moveModalTire || !moveTargetPosition) return alert("Selecione a posição de destino.");
      
      // REGRA DE SEGURANÇA: Bloqueio de Recapados na Dianteira
      // Bloquear pneu recapado (lifeCount > 0) na dianteira (Posição começa com '1')
      if (isFrontAxle(moveTargetPosition) && moveModalTire.lifeCount > 0) {
          return alert("⛔ BLOQUEIO DE SEGURANÇA ⛔\n\nÉ PROIBIDO instalar pneus RECAPADOS no EIXO DIANTEIRO.\n\nOperação cancelada.");
      }

      const sourcePosition = moveModalTire.position!;
      
      // Check if there is a tire in the target position (for swap)
      const targetTire = localTires.find(t => 
          t.vehicleId === moveModalTire.vehicleId && 
          t.status === TireStatus.INSTALLED && 
          t.position === moveTargetPosition
      );

      // Validação Secundária (Swap): Pneu destino (se recapado) não pode ir pra frente
      if (targetTire) {
          if (isFrontAxle(sourcePosition) && targetTire.lifeCount > 0) {
               return alert(`⛔ BLOQUEIO DE SEGURANÇA ⛔\n\nO pneu da posição destino (${targetTire.serialNumber}) é RECAPADO e não pode ir para a DIANTEIRA.`);
          }
      }

      // Update Local State
      const updatedTires = localTires.map(t => {
          // Source Tire moves to Target
          if (t.id === moveModalTire.id) {
              return { ...t, position: moveTargetPosition };
          }
          // Target Tire (if exists) moves to Source (SWAP)
          if (targetTire && t.id === targetTire.id) {
              return { ...t, position: sourcePosition };
          }
          return t;
      });
      setLocalTires(updatedTires);

      // Add History Record for Source
      const newRecordSource: MaintenanceRecord = {
          id: `m-rot-s-${Date.now()}`,
          tireId: moveModalTire.id,
          vehicleId: moveModalTire.vehicleId,
          date: new Date().toISOString().split('T')[0],
          type: MaintenanceType.ROTATION,
          cost: 0,
          odometer: 0,
          description: targetTire 
            ? `Rodízio (Troca) com ${targetTire.serialNumber}: ${sourcePosition} <-> ${moveTargetPosition}`
            : `Rodízio: ${sourcePosition} -> ${moveTargetPosition}`,
          performedBy: 'Usuário Atual',
          position: moveTargetPosition
      };

      let newRecords = [newRecordSource];

      // Add History Record for Target (if swapped)
      if (targetTire) {
          const newRecordTarget: MaintenanceRecord = {
              id: `m-rot-t-${Date.now()}`,
              tireId: targetTire.id,
              vehicleId: targetTire.vehicleId,
              date: new Date().toISOString().split('T')[0],
              type: MaintenanceType.ROTATION,
              cost: 0,
              odometer: 0,
              description: `Rodízio (Troca) com ${moveModalTire.serialNumber}: ${moveTargetPosition} <-> ${sourcePosition}`,
              performedBy: 'Usuário Atual',
              position: sourcePosition
          };
          newRecords.push(newRecordTarget);
      }

      setLocalMaintenance(prev => [...newRecords, ...prev]);

      alert(targetTire 
        ? `SUCESSO: Rodízio realizado entre ${moveModalTire.serialNumber} e ${targetTire.serialNumber}.`
        : `SUCESSO: Pneu ${moveModalTire.serialNumber} movido para ${moveTargetPosition}.`
      );
      setMoveModalTire(null);
  };

  const handleConfirmRemoval = () => {
      if (!removalModalTire || !removalAction) return;
      if (removalAction === 'SCRAP' && !opReason) return alert("Motivo é obrigatório para descarte.");

      let newStatus = TireStatus.STOCK;
      let actionLabel = 'Estoque';
      
      // FLUXO 5.1: Retirada para Recapagem
      if (removalAction === 'RETREAD') {
          newStatus = TireStatus.AWAITING_RETREAD;
          actionLabel = 'Recapagem';
          // Não exige recapadora/banda aqui.
      } else if (removalAction === 'SCRAP') {
          newStatus = TireStatus.SCRAP;
          actionLabel = 'Sucata';
      }

      // Update Tire
      const updatedTires = localTires.map(t => {
          if (t.id === removalModalTire.id) {
              return {
                  ...t,
                  status: newStatus,
                  vehicleId: undefined,
                  position: undefined,
                  location: removalAction === 'STOCK' ? 'Estoque' : (removalAction === 'RETREAD' ? 'Aguardando Coleta/Envio' : 'Sucata'),
                  retreadSendDate: removalAction === 'RETREAD' ? opDate : undefined // Grava Data de Envio
              };
          }
          return t;
      });
      setLocalTires(updatedTires);

      // Add History
      const newRecord: MaintenanceRecord = {
          id: `m-rem-${Date.now()}`,
          tireId: removalModalTire.id,
          vehicleId: removalModalTire.vehicleId,
          date: opDate,
          type: MaintenanceType.DISMOUNT,
          cost: 0,
          odometer: opKm,
          description: `Retirada para ${actionLabel}. Motivo: ${opReason || (removalAction === 'STOCK' ? 'Devolução ao Estoque' : 'Desgaste Natural')}`,
          performedBy: 'Usuário Atual',
          position: removalModalTire.position
      };
      setLocalMaintenance(prev => [newRecord, ...prev]);

      alert(`SUCESSO: Pneu ${removalModalTire.serialNumber} enviado para ${actionLabel}.\nKM: ${opKm}\nData: ${opDate}`);
      
      setRemovalModalTire(null);
      setRemovalAction(null);
  };

  const handleConfirmReturn = () => {
      if (!returnModalTire) return;

      let updatedTire: Tire;
      let newMaintenance: MaintenanceRecord;

      // FLUXO 5.3: Retorno da Recapagem
      if (returnForm.result === 'APPROVED') {
          // APROVADO: Volta para Estoque como Recapado
          updatedTire = {
              ...returnModalTire,
              status: TireStatus.STOCK, // Volta para o estoque para ser montado depois
              condition: TireCondition.RETREADED,
              lifeCount: returnModalTire.lifeCount + 1, // Cria nova vida
              currentDepth: returnForm.newDepth,
              originalDepth: returnForm.newDepth, // Reset sulco original da nova vida
              
              // Dados Obrigatórios no Retorno
              treadBrand: returnForm.treadBrand,
              treadModel: returnForm.treadModel,
              treadType: returnForm.treadType,
              retreader: returnForm.retreader,
              retreadCost: returnForm.cost,
              retreadReturnDate: returnForm.date,
              
              location: 'Estoque (Recapado)'
          };

          newMaintenance = {
              id: `m-ret-ok-${Date.now()}`,
              tireId: returnModalTire.id,
              date: returnForm.date,
              type: MaintenanceType.RETREAD,
              cost: returnForm.cost,
              odometer: 0, // Não registra KM no retorno
              description: `Retorno de Recapagem (Aprovado). Recapadora: ${returnForm.retreader}. Banda: ${returnForm.treadBrand} ${returnForm.treadModel} (${returnForm.treadType}). Nova Vida: ${updatedTire.lifeCount}`,
              performedBy: returnForm.retreader || 'Recapadora Externa'
          };

      } else {
          // REPROVADO: Vai para Sucata
          updatedTire = {
              ...returnModalTire,
              status: TireStatus.SCRAP,
              location: 'Sucata (Recusado na Recapagem)'
          };

          const fullReason = returnForm.detailedReason 
            ? `${returnForm.rejectionReason} | Obs: ${returnForm.detailedReason}` 
            : returnForm.rejectionReason;

          newMaintenance = {
              id: `m-ret-fail-${Date.now()}`,
              tireId: returnModalTire.id,
              date: returnForm.date,
              type: MaintenanceType.INSPECTION, 
              cost: 0,
              odometer: 0,
              description: `Recusa na Recapagem. Motivo: ${fullReason}`,
              performedBy: 'Recapadora Externa'
          };
      }

      // Update State
      const updatedTiresList = localTires.map(t => t.id === returnModalTire.id ? updatedTire : t);
      setLocalTires(updatedTiresList);
      setLocalMaintenance(prev => [newMaintenance, ...prev]);

      alert(returnForm.result === 'APPROVED' 
        ? `SUCESSO: Pneu ${returnModalTire.serialNumber} recapado e retornado ao estoque.`
        : `SUCESSO: Pneu ${returnModalTire.serialNumber} recusado e enviado para sucata.`
      );
      setReturnModalTire(null);
  };

  // --- Install Logic ---
  const handleOpenInstallModal = () => {
      setInstallForm({
          tireId: '',
          vehicleId: '',
          position: '',
          date: new Date().toISOString().split('T')[0],
          odometer: 0,
          depth: 0
      });
      setIsInstallModalOpen(true);
  };

  const handleVehicleChange = (vehicleId: string) => {
      const vehicle = MOCK_VEHICLES.find(v => v.id === vehicleId);
      setInstallForm(prev => ({
          ...prev,
          vehicleId,
          odometer: vehicle ? vehicle.odometer : 0,
          position: '' // Reset position when vehicle changes
      }));
  };

  const handleTireChange = (tireId: string) => {
      const tire = stockTires.find(t => t.id === tireId);
      setInstallForm(prev => ({
          ...prev,
          tireId,
          depth: tire ? tire.currentDepth : 0
      }));
  };

  const handleInstallConfirm = () => {
      if (!installForm.tireId || !installForm.vehicleId || !installForm.position) {
          return alert("Preencha todos os campos obrigatórios (Pneu, Veículo, Posição).");
      }
      const vehicle = MOCK_VEHICLES.find(v => v.id === installForm.vehicleId);
      const tire = stockTires.find(t => t.id === installForm.tireId);

      if (!tire || !vehicle) return;

      // REGRA DE SEGURANÇA: Bloqueio de Recapados na Dianteira
      if (isFrontAxle(installForm.position) && tire.lifeCount > 0) {
          return alert(`⛔ BLOQUEIO DE SEGURANÇA ⛔\n\nÉ PROIBIDO instalar pneus RECAPADOS (Vida ${tire.lifeCount}) no EIXO DIANTEIRO.\n\nSelecione um pneu NOVO (Vida 0).`);
      }

      // 1. Atualizar o Pneu no Estado Local
      const updatedTires = localTires.map(t => {
          if (t.id === tire.id) {
              return {
                  ...t,
                  status: TireStatus.INSTALLED,
                  vehicleId: vehicle.id,
                  position: installForm.position,
                  location: vehicle.plate,
                  currentDepth: installForm.depth || t.currentDepth // Atualiza sulco se informado
              };
          }
          return t;
      });
      setLocalTires(updatedTires);

      // 2. Criar Registro de Manutenção (Histórico)
      const newMaintenance: MaintenanceRecord = {
          id: `m-inst-${Date.now()}`,
          tireId: tire.id, // Referência
          vehicleId: vehicle.id,
          date: installForm.date,
          type: MaintenanceType.MOUNT,
          cost: 0, // Custo de montagem (pode ser ajustável futuramente)
          odometer: installForm.odometer,
          description: `Instalação no veículo ${vehicle.plate}`,
          performedBy: 'Usuário Atual',
          position: installForm.position
      };
      setLocalMaintenance(prev => [newMaintenance, ...prev]);

      alert(`SUCESSO: Pneu ${tire.serialNumber} instalado no veículo ${vehicle.plate} na posição ${installForm.position}.`);
      setIsInstallModalOpen(false);
  };

  // Helper to group tires by vehicle
  const getTiresByVehicle = () => {
    const grouped: Record<string, Tire[]> = {};
    filteredTires.forEach(tire => {
        const vId = tire.vehicleId || 'unassigned';
        if (!grouped[vId]) grouped[vId] = [];
        grouped[vId].push(tire);
    });
    return grouped;
  };

  const groupedTires = activeTab === TireStatus.INSTALLED && viewMode === 'GROUP_VEHICLE' ? getTiresByVehicle() : {};

  // Mock History Generator - Now Dynamic using Local Maintenance
  const getTireHistory = (tire: Tire | null) => {
    if (!tire) return [];
    const history = localMaintenance
        .filter(r => r.tireId === tire.id || r.tireId === tire.serialNumber)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    return history;
  };

  const getMaintenanceIcon = (type: MaintenanceType) => {
      switch(type) {
          case MaintenanceType.MOUNT: return <Truck size={14}/>;
          case MaintenanceType.DISMOUNT: return <ArrowRight size={14}/>;
          case MaintenanceType.ROTATION: return <ArrowRightLeft size={14}/>;
          case MaintenanceType.PRESSURE: return <Gauge size={14}/>;
          default: return <Wrench size={14}/>;
      }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-800">Ciclo de Vida</h1>
           <p className="text-slate-500">Monitoramento de Pneus em Uso, Recapagem e Descarte</p>
        </div>
        <button 
            onClick={handleOpenInstallModal}
            className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-bold hover:bg-primary-700 shadow-sm transition-colors"
        >
            <Plus size={18} /> Nova Instalação
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-200">
         <nav className="-mb-px flex space-x-8 overflow-x-auto">
            <button
               onClick={() => setActiveTab(TireStatus.INSTALLED)}
               className={clsx(
                  "whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors flex items-center gap-2",
                  activeTab === TireStatus.INSTALLED
                     ? "border-emerald-500 text-emerald-600"
                     : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
               )}
            >
               <Truck size={16} />
               Em Uso (Instalados)
               <span className={clsx(
                   "ml-2 py-0.5 px-2 rounded-full text-xs",
                   activeTab === TireStatus.INSTALLED ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"
               )}>
                  {localTires.filter(t => t.status === TireStatus.INSTALLED).length}
               </span>
            </button>

            <button
               onClick={() => setActiveTab(TireStatus.AWAITING_RETREAD)}
               className={clsx(
                  "whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors flex items-center gap-2",
                  activeTab === TireStatus.AWAITING_RETREAD
                     ? "border-orange-500 text-orange-600"
                     : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
               )}
            >
               <RefreshCw size={16} />
               Aguardando / Em Recapagem
               <span className={clsx(
                   "ml-2 py-0.5 px-2 rounded-full text-xs",
                   activeTab === TireStatus.AWAITING_RETREAD ? "bg-orange-100 text-orange-700" : "bg-slate-100 text-slate-600"
               )}>
                  {localTires.filter(t => t.status === TireStatus.AWAITING_RETREAD).length}
               </span>
            </button>

            <button
               onClick={() => setActiveTab(TireStatus.SCRAP)}
               className={clsx(
                  "whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors flex items-center gap-2",
                  activeTab === TireStatus.SCRAP
                     ? "border-red-500 text-red-600"
                     : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
               )}
            >
               <Trash2 size={16} />
               Sucata / Descarte
               <span className={clsx(
                   "ml-2 py-0.5 px-2 rounded-full text-xs",
                   activeTab === TireStatus.SCRAP ? "bg-red-100 text-red-700" : "bg-slate-100 text-slate-600"
               )}>
                  {localTires.filter(t => t.status === TireStatus.SCRAP).length}
               </span>
            </button>
         </nav>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4 justify-between items-center">
         <div className="relative flex-1 w-full">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input type="text" placeholder="Buscar por fogo, marca..." className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" />
         </div>
         
         {/* View Toggle (Only for Installed) */}
         {activeTab === TireStatus.INSTALLED && (
             <div className="flex bg-slate-100 p-1 rounded-lg">
                 <button 
                    onClick={() => setViewMode('LIST')}
                    className={clsx(
                        "p-2 rounded-md transition-all",
                        viewMode === 'LIST' ? "bg-white shadow text-primary-600" : "text-slate-500 hover:text-slate-700"
                    )}
                    title="Visualizar Lista"
                 >
                    <LayoutList size={20} />
                 </button>
                 <button 
                    onClick={() => setViewMode('GROUP_VEHICLE')}
                    className={clsx(
                        "p-2 rounded-md transition-all",
                        viewMode === 'GROUP_VEHICLE' ? "bg-white shadow text-primary-600" : "text-slate-500 hover:text-slate-700"
                    )}
                    title="Agrupar por Veículo"
                 >
                    <Grid size={20} />
                 </button>
             </div>
         )}
      </div>

      {/* CONTENT AREA */}
      
      {/* View: Grouped by Vehicle */}
      {activeTab === TireStatus.INSTALLED && viewMode === 'GROUP_VEHICLE' ? (
         <div className="space-y-4">
             {Object.entries(groupedTires).map(([vehicleId, tires]) => {
                 const vehicle = MOCK_VEHICLES.find(v => v.id === vehicleId);
                 const plate = vehicle ? vehicle.plate : "Sem Veículo / Não Atribuído";
                 const isExpanded = expandedVehicles.has(vehicleId);

                 return (
                     <div key={vehicleId} className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden transition-all">
                         <button 
                             onClick={() => toggleVehicle(vehicleId)}
                             className="w-full px-6 py-4 bg-white hover:bg-slate-50 border-b border-slate-50 flex justify-between items-center transition-colors text-left"
                         >
                             <div className="flex items-center gap-4">
                                 <div className={clsx("transition-transform duration-200", isExpanded ? "rotate-180" : "")}>
                                     <ChevronDown size={20} className="text-slate-400" />
                                 </div>
                                 <div className="w-10 h-10 bg-primary-50 rounded-full flex items-center justify-center text-primary-600">
                                     <Truck size={20} />
                                 </div>
                                 <div>
                                     <h3 className="font-bold text-slate-800 text-lg">{plate}</h3>
                                     <p className="text-xs text-slate-500">{tires.length} Pneus</p>
                                 </div>
                             </div>
                         </button>

                         {isExpanded && (
                             <div className="p-4 bg-slate-50/50">
                                 <div className="overflow-x-auto border rounded-lg bg-white">
                                     <table className="w-full text-sm text-left">
                                         <thead className="bg-slate-50 text-xs text-slate-500 uppercase border-b border-slate-100">
                                             <tr>
                                                 <th className="px-4 py-3">Posição</th>
                                                 <th className="px-4 py-3">Fogo</th>
                                                 <th className="px-4 py-3">Vida</th>
                                                 <th className="px-4 py-3">Sulcos</th>
                                                 <th className="px-4 py-3 text-right">Ações</th>
                                             </tr>
                                         </thead>
                                         <tbody className="divide-y divide-slate-100">
                                             {tires.sort((a,b) => a.position?.localeCompare(b.position || '') || 0).map(tire => (
                                                 <tr key={tire.id} className="hover:bg-slate-50">
                                                     <td className="px-4 py-3 font-bold text-slate-800">{tire.position}</td>
                                                     <td className="px-4 py-3 font-mono text-slate-600">{tire.serialNumber}</td>
                                                     <td className="px-4 py-3"><span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded text-xs font-bold">V{tire.lifeCount}</span></td>
                                                     <td className="px-4 py-3 font-bold">{tire.currentDepth}mm</td>
                                                     <td className="px-4 py-3 text-right">
                                                         <button 
                                                             onClick={() => setHistoryModalTire(tire)}
                                                             className="text-primary-600 hover:text-primary-800 text-xs font-bold flex items-center gap-1 ml-auto"
                                                         >
                                                             <History size={14} /> Histórico
                                                         </button>
                                                     </td>
                                                 </tr>
                                             ))}
                                         </tbody>
                                     </table>
                                 </div>
                             </div>
                         )}
                     </div>
                 );
             })}
         </div>
      ) : (
        /* View: Standard Table List */
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="overflow-x-auto pb-4">
                <table className="w-full text-sm text-left">
                <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-b border-slate-100">
                    <tr>
                        <th className="px-6 py-4">Fogo</th>
                        <th className="px-6 py-4">Marca / Modelo</th>
                        <th className="px-6 py-4">Vida Atual</th>
                        <th className="px-6 py-4">Status / Local</th>
                        {activeTab === TireStatus.INSTALLED && (
                            <th className="px-6 py-4">Posição</th>
                        )}
                        <th className="px-6 py-4 text-right">Ações Rápidas</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {filteredTires.map(tire => (
                        <tr key={tire.id} className="hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 font-bold text-slate-800 font-mono">{tire.serialNumber}</td>
                            <td className="px-6 py-4">
                                {getTireBrandDisplay(tire)}
                            </td>
                            <td className="px-6 py-4">
                                <span className={clsx(
                                    "w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white",
                                    tire.lifeCount === 0 ? "bg-emerald-500" : "bg-blue-600"
                                )}>V{tire.lifeCount}</span>
                            </td>
                            <td className="px-6 py-4">
                                <span className={clsx(
                                    "px-2 py-1 rounded-full text-xs font-bold",
                                    tire.status === TireStatus.INSTALLED ? "bg-emerald-100 text-emerald-700" :
                                    tire.status === TireStatus.AWAITING_RETREAD ? "bg-orange-100 text-orange-700" : 
                                    "bg-red-100 text-red-700"
                                )}>
                                {tire.status}
                                </span>
                                {tire.status === TireStatus.INSTALLED && (
                                <div className="text-xs font-bold text-slate-600 mt-1">
                                    {tire.location}
                                </div>
                                )}
                                {tire.status === TireStatus.AWAITING_RETREAD && tire.retreadSendDate && (
                                    <div className="text-xs text-orange-600 mt-1 flex items-center gap-1">
                                        <Calendar size={10} /> Enviado: {tire.retreadSendDate}
                                    </div>
                                )}
                            </td>
                            
                            {activeTab === TireStatus.INSTALLED && (
                                <td className="px-6 py-4 text-slate-600 font-bold">{tire.position}</td>
                            )}

                            <td className="px-6 py-4 text-right">
                                <div className="flex justify-end gap-2 items-center">
                                    {activeTab === TireStatus.INSTALLED && (
                                        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                                            <button 
                                                onClick={() => openMoveModal(tire)}
                                                className="p-1.5 bg-white text-blue-600 hover:bg-blue-600 hover:text-white rounded border border-slate-200 transition-colors shadow-sm"
                                                title="Mover / Rodízio"
                                            >
                                                <ArrowRightLeft size={16} />
                                            </button>
                                            <button 
                                                onClick={() => openRemovalModal(tire, 'STOCK')}
                                                className="p-1.5 bg-white text-emerald-500 hover:bg-emerald-500 hover:text-white rounded border border-slate-200 transition-colors shadow-sm"
                                                title="Devolver ao Estoque"
                                            >
                                                <Disc size={16} />
                                            </button>
                                            <button 
                                                onClick={() => openRemovalModal(tire, 'RETREAD')}
                                                className="p-1.5 bg-white text-orange-500 hover:bg-orange-500 hover:text-white rounded border border-slate-200 transition-colors shadow-sm"
                                                title="Enviar para Recapagem"
                                            >
                                                <RefreshCw size={16} />
                                            </button>
                                            <button 
                                                onClick={() => openRemovalModal(tire, 'SCRAP')}
                                                className="p-1.5 bg-white text-red-500 hover:bg-red-500 hover:text-white rounded border border-slate-200 transition-colors shadow-sm"
                                                title="Descarte / Sucata"
                                            >
                                                <Trash2 size={16} />
                                            </button>
                                        </div>
                                    )}

                                    {activeTab === TireStatus.AWAITING_RETREAD && (
                                        <button 
                                            onClick={() => openReturnModal(tire)}
                                            className="px-3 py-1 bg-emerald-600 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 flex items-center gap-1 shadow-sm"
                                        >
                                            <CheckCircle size={14} /> Processar Retorno
                                        </button>
                                    )}
                                    
                                    <button 
                                        onClick={() => setHistoryModalTire(tire)}
                                        className="text-slate-400 hover:text-primary-600 p-2" 
                                        title="Histórico"
                                    >
                                        <History size={18} />
                                    </button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
                </table>
            </div>
        </div>
      )}

      {/* --- MODALS SECTION --- */}

      {/* MOVE / ROTATE MODAL */}
      {moveModalTire && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setMoveModalTire(null)}></div>
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm z-10 p-6 animate-scale-in">
                  <div className="flex justify-between items-center mb-4">
                      <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                          <ArrowRightLeft className="text-blue-600" size={20}/> Mover Pneu
                      </h3>
                      <button onClick={() => setMoveModalTire(null)} className="text-slate-400 hover:text-slate-600"><X size={24}/></button>
                  </div>
                  
                  <div className="space-y-4">
                      <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-sm">
                          <p className="text-slate-500">Pneu selecionado:</p>
                          <p className="font-bold text-slate-800">{moveModalTire.serialNumber}</p>
                          <p className="text-xs text-slate-500 mt-1">
                              {moveModalTire.lifeCount > 0 ? (
                                  <>Marca Banda: <strong>{moveModalTire.treadBrand}</strong></>
                              ) : (
                                  <>Marca: <strong>{moveModalTire.brand}</strong></>
                              )}
                          </p>
                          <p className="text-xs text-slate-500">Veículo: {moveModalTire.location} | Posição Atual: {moveModalTire.position}</p>
                      </div>

                      <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nova Posição</label>
                          <select 
                            value={moveTargetPosition}
                            onChange={(e) => setMoveTargetPosition(e.target.value)}
                            className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-blue-500 bg-white"
                          >
                              <option value="">Selecione...</option>
                              {getValidPositions(moveModalTire.vehicleId).map(pos => (
                                  <option key={pos} value={pos} disabled={pos === moveModalTire.position}>
                                      {pos} {pos === moveModalTire.position ? '(Atual)' : ''}
                                  </option>
                              ))}
                          </select>
                      </div>
                      
                      <button 
                        onClick={handleConfirmMove}
                        className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/20"
                      >
                          Confirmar Movimentação
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* RETURN FROM RETREAD MODAL (NEW) */}
      {returnModalTire && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setReturnModalTire(null)}></div>
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg z-10 p-6 animate-scale-in max-h-[90vh] overflow-y-auto">
                  <div className="flex justify-between items-center mb-6">
                      <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                          <RefreshCw className="text-orange-600" size={20}/> Retorno de Recapagem
                      </h3>
                      <button onClick={() => setReturnModalTire(null)} className="text-slate-400 hover:text-slate-600"><X size={24}/></button>
                  </div>

                  <div className="space-y-4">
                      <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-sm flex justify-between items-center">
                          <div>
                            <p className="text-slate-500 text-xs uppercase font-bold">Pneu (Fogo)</p>
                            <p className="font-bold text-slate-800 text-lg font-mono">{returnModalTire.serialNumber}</p>
                          </div>
                          <div className="text-right">
                              <p className="text-slate-500 text-xs uppercase font-bold">Enviado em</p>
                              <p className="font-bold text-slate-800">{returnModalTire.retreadSendDate || 'N/A'}</p>
                          </div>
                      </div>

                      <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Resultado da Avaliação</label>
                          <div className="grid grid-cols-2 gap-3">
                              <button 
                                onClick={() => setReturnForm({...returnForm, result: 'APPROVED'})}
                                className={clsx(
                                    "p-3 rounded-xl border-2 flex flex-col items-center gap-2 transition-all",
                                    returnForm.result === 'APPROVED' 
                                        ? "border-emerald-500 bg-emerald-50 text-emerald-700" 
                                        : "border-slate-100 bg-white text-slate-400 hover:border-slate-300"
                                )}
                              >
                                  <ThumbsUp size={24} />
                                  <span className="font-bold text-sm">Aprovado</span>
                              </button>
                              <button 
                                onClick={() => setReturnForm({...returnForm, result: 'REJECTED'})}
                                className={clsx(
                                    "p-3 rounded-xl border-2 flex flex-col items-center gap-2 transition-all",
                                    returnForm.result === 'REJECTED' 
                                        ? "border-red-500 bg-red-50 text-red-700" 
                                        : "border-slate-100 bg-white text-slate-400 hover:border-slate-300"
                                )}
                              >
                                  <ThumbsDown size={24} />
                                  <span className="font-bold text-sm">Reprovado (Sucata)</span>
                              </button>
                          </div>
                      </div>

                      <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Data do Retorno</label>
                          <input 
                              type="date" 
                              value={returnForm.date}
                              onChange={(e) => setReturnForm({...returnForm, date: e.target.value})}
                              className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                          />
                      </div>

                      {returnForm.result === 'APPROVED' ? (
                          <div className="space-y-4 animate-fade-in">
                              {/* Recapadora e Tipo de Banda (Novos Campos) */}
                              <div className="grid grid-cols-2 gap-4">
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Recapadora</label>
                                      <select
                                          value={returnForm.retreader}
                                          onChange={(e) => setReturnForm({...returnForm, retreader: e.target.value})}
                                          className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-emerald-500 bg-white"
                                      >
                                          <option value="">Selecione...</option>
                                          {retreaders.map(r => (
                                              <option key={r.id} value={r.name}>{r.name}</option>
                                          ))}
                                      </select>
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tipo de Banda</label>
                                      <select 
                                          value={returnForm.treadType}
                                          onChange={(e) => setReturnForm({...returnForm, treadType: e.target.value as TreadType})}
                                          className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-emerald-500 bg-white"
                                      >
                                          <option value={TreadType.LISA}>Lisa</option>
                                          <option value={TreadType.MISTA}>Mista</option>
                                          <option value={TreadType.BORRACHUDO}>Borrachudo</option>
                                      </select>
                                  </div>
                              </div>

                              <div className="grid grid-cols-2 gap-4">
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nova Marca da Banda</label>
                                      <select
                                          value={returnForm.treadBrand}
                                          onChange={(e) => setReturnForm({...returnForm, treadBrand: e.target.value})}
                                          className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-emerald-500 bg-white"
                                      >
                                          <option value="">Selecione...</option>
                                          {treadBrands.map(b => (
                                              <option key={b.id} value={b.name}>{b.name}</option>
                                          ))}
                                      </select>
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Desenho/Modelo</label>
                                      <select
                                          value={returnForm.treadModel}
                                          onChange={(e) => setReturnForm({...returnForm, treadModel: e.target.value})}
                                          className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-emerald-500 bg-white"
                                      >
                                          <option value="">Selecione...</option>
                                          {treadModels.map(m => (
                                              <option key={m} value={m}>{m}</option>
                                          ))}
                                      </select>
                                  </div>
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Custo Serviço (R$)</label>
                                      <input 
                                          type="number" 
                                          value={returnForm.cost}
                                          onChange={(e) => setReturnForm({...returnForm, cost: Number(e.target.value)})}
                                          className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-emerald-500"
                                      />
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Novo Sulco (mm)</label>
                                      <input 
                                          type="number" 
                                          value={returnForm.newDepth}
                                          onChange={(e) => setReturnForm({...returnForm, newDepth: Number(e.target.value)})}
                                          className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-emerald-500"
                                      />
                                  </div>
                              </div>
                          </div>
                      ) : (
                          <div className="animate-fade-in space-y-3">
                              <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Motivo da Recusa</label>
                                <select 
                                    value={returnForm.rejectionReason}
                                    onChange={(e) => setReturnForm({...returnForm, rejectionReason: e.target.value})}
                                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-red-500 bg-white"
                                >
                                    <option value="">Selecione...</option>
                                    <option>Carcaça Fadiga Excessiva</option>
                                    <option>Separação de Cintas</option>
                                    <option>Danos no Talão</option>
                                    <option>Furos/Cortes Irreparáveis</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Motivo Detalhado / Observações</label>
                                <textarea 
                                    value={returnForm.detailedReason}
                                    onChange={(e) => setReturnForm({...returnForm, detailedReason: e.target.value})}
                                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-red-500 bg-white h-20 resize-none"
                                    placeholder="Descreva detalhes sobre a recusa..."
                                />
                              </div>
                          </div>
                      )}

                      <button 
                        onClick={handleConfirmReturn}
                        className={clsx(
                            "w-full py-3 text-white font-bold rounded-xl shadow-lg mt-2",
                            returnForm.result === 'APPROVED' 
                                ? "bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/20" 
                                : "bg-red-600 hover:bg-red-700 shadow-red-500/20"
                        )}
                      >
                          Confirmar Processamento
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* REMOVAL MODAL (RETREAD/SCRAP/STOCK) */}
      {removalModalTire && removalAction && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setRemovalModalTire(null)}></div>
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-md z-10 p-6 animate-scale-in">
                  <div className="flex justify-between items-center mb-4">
                      <h3 className={clsx(
                          "font-bold text-lg flex items-center gap-2",
                          removalAction === 'RETREAD' ? "text-orange-600" : 
                          removalAction === 'SCRAP' ? "text-red-600" : "text-emerald-600"
                      )}>
                          {removalAction === 'RETREAD' ? <RefreshCw size={20}/> : removalAction === 'SCRAP' ? <Trash2 size={20}/> : <Disc size={20}/>}
                          {removalAction === 'RETREAD' ? 'Enviar para Recapagem' : 
                           removalAction === 'SCRAP' ? 'Confirmar Descarte' : 'Devolver ao Estoque'}
                      </h3>
                      <button onClick={() => setRemovalModalTire(null)} className="text-slate-400 hover:text-slate-600"><X size={24}/></button>
                  </div>
                  
                  <div className="space-y-4">
                      <p className="text-sm text-slate-600">
                          Você está retirando o pneu <strong>{removalModalTire.serialNumber}</strong> do veículo <strong>{removalModalTire.location}</strong>.
                      </p>

                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">
                                  {removalAction === 'RETREAD' ? 'Data de Envio' : 'Data'}
                              </label>
                              <input 
                                type="date" 
                                value={opDate}
                                onChange={(e) => setOpDate(e.target.value)}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                              />
                          </div>
                          <div>
                              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">KM Veículo</label>
                              <input 
                                type="number" 
                                value={opKm}
                                onChange={(e) => setOpKm(Number(e.target.value))}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                              />
                          </div>
                      </div>

                      {removalAction === 'SCRAP' && (
                          <div>
                              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Motivo do Descarte</label>
                              <select 
                                value={opReason}
                                onChange={(e) => setOpReason(e.target.value)}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                              >
                                  <option value="">Selecione...</option>
                                  <option>Fadiga de Carcaça</option>
                                  <option>Corte Lateral Irreparável</option>
                                  <option>Desplacamento</option>
                                  <option>Estouro</option>
                              </select>
                          </div>
                      )}

                      <button 
                        onClick={handleConfirmRemoval}
                        className={clsx(
                            "w-full py-3 text-white font-bold rounded-xl shadow-lg mt-2",
                            removalAction === 'RETREAD' ? "bg-orange-500 hover:bg-orange-600 shadow-orange-500/20" : 
                            removalAction === 'SCRAP' ? "bg-red-600 hover:bg-red-700 shadow-red-600/20" : "bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20"
                        )}
                      >
                          Confirmar Retirada
                      </button>
                  </div>
              </div>
          </div>
      )}


      {/* INSTALLATION MODAL */}
      {isInstallModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsInstallModalOpen(false)}></div>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl z-10 overflow-hidden animate-scale-in flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 bg-primary-600 text-white flex justify-between items-center">
                <h3 className="font-bold text-lg flex items-center gap-2"><Truck size={20}/> Nova Instalação</h3>
                <button onClick={() => setIsInstallModalOpen(false)} className="text-white/80 hover:text-white"><X size={24}/></button>
            </div>
            
            <div className="p-6 overflow-y-auto space-y-6">
                
                {/* 1. Select Tire from Stock */}
                <div>
                    <h4 className="text-sm font-bold text-slate-800 uppercase mb-3 flex items-center gap-2">
                        <Disc size={16} className="text-primary-600"/> 1. Selecione o Pneu (Estoque)
                    </h4>
                    <select 
                        value={installForm.tireId}
                        onChange={(e) => handleTireChange(e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-3 outline-none focus:border-primary-500 bg-white"
                    >
                        <option value="">Selecione um pneu disponível...</option>
                        {stockTires.map(t => (
                            <option key={t.id} value={t.id}>
                                Fogo: {t.serialNumber} | {t.lifeCount > 0 ? `Recapado ${t.treadBrand}` : `${t.brand} ${t.model}`} | ({t.currentDepth}mm)
                            </option>
                        ))}
                    </select>
                </div>

                {/* 2. Select Vehicle */}
                <div>
                    <h4 className="text-sm font-bold text-slate-800 uppercase mb-3 flex items-center gap-2">
                        <Truck size={16} className="text-primary-600"/> 2. Selecione o Veículo
                    </h4>
                    <select 
                        value={installForm.vehicleId}
                        onChange={(e) => handleVehicleChange(e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-3 outline-none focus:border-primary-500 bg-white"
                    >
                        <option value="">Selecione o veículo destino...</option>
                        {MOCK_VEHICLES.map(v => (
                            <option key={v.id} value={v.id}>{v.plate} - {v.model} ({v.type})</option>
                        ))}
                    </select>

                    {/* Selected Vehicle Info */}
                    {installForm.vehicleId && (
                        <div className="mt-3 bg-slate-50 p-4 rounded-lg border border-slate-200 flex gap-6">
                            <div>
                                <span className="block text-[10px] uppercase font-bold text-slate-400">Placa</span>
                                <span className="font-bold text-slate-800">{MOCK_VEHICLES.find(v => v.id === installForm.vehicleId)?.plate}</span>
                            </div>
                            <div>
                                <span className="block text-[10px] uppercase font-bold text-slate-400">Modelo</span>
                                <span className="font-bold text-slate-800">{MOCK_VEHICLES.find(v => v.id === installForm.vehicleId)?.model}</span>
                            </div>
                            <div>
                                <span className="block text-[10px] uppercase font-bold text-slate-400">KM Atual</span>
                                <span className="font-bold text-slate-800">{MOCK_VEHICLES.find(v => v.id === installForm.vehicleId)?.odometer.toLocaleString()} km</span>
                            </div>
                        </div>
                    )}
                </div>

                {/* 3. Install Details */}
                {installForm.vehicleId && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Posição no Veículo</label>
                            <select 
                                value={installForm.position}
                                onChange={(e) => setInstallForm({...installForm, position: e.target.value})}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                            >
                                <option value="">Selecione a posição...</option>
                                {getValidPositions(installForm.vehicleId).map(pos => (
                                    <option key={pos} value={pos}>{pos}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Data da Instalação</label>
                            <input 
                                type="date" 
                                value={installForm.date}
                                onChange={(e) => setInstallForm({...installForm, date: e.target.value})}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">KM Veículo na Instalação</label>
                            <input 
                                type="number" 
                                value={installForm.odometer}
                                onChange={(e) => setInstallForm({...installForm, odometer: Number(e.target.value)})}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Sulco Inicial (mm)</label>
                            <input 
                                type="number" 
                                value={installForm.depth}
                                onChange={(e) => setInstallForm({...installForm, depth: Number(e.target.value)})}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                            />
                        </div>
                    </div>
                )}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex gap-3">
                <button onClick={() => setIsInstallModalOpen(false)} className="flex-1 py-3 text-slate-600 font-bold bg-white border border-slate-200 rounded-xl hover:bg-slate-50">Cancelar</button>
                <button onClick={handleInstallConfirm} className="flex-1 py-3 text-white font-bold bg-primary-600 rounded-xl hover:bg-primary-700 flex items-center justify-center gap-2 shadow-lg">
                    <Save size={18} /> Confirmar Instalação
                </button>
            </div>
          </div>
        </div>
      )}

      {/* HISTORY MODAL (UPDATED) */}
      {historyModalTire && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setHistoryModalTire(null)}></div>
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl z-10 overflow-hidden animate-scale-in flex flex-col max-h-[85vh]">
                <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center shrink-0">
                    <div>
                        <h3 className="font-bold text-lg text-slate-800">Histórico do Pneu</h3>
                        <p className="text-xs text-slate-500 font-mono mt-0.5">{historyModalTire.serialNumber}</p>
                    </div>
                    <button onClick={() => setHistoryModalTire(null)} className="p-1 hover:bg-slate-200 rounded-full transition-colors"><X size={20} className="text-slate-500" /></button>
                </div>
                
                <div className="overflow-y-auto p-0 bg-white">
                    {/* NEW SECTION: CYCLES SUMMARY */}
                    {(() => {
                        const lives = reconstructTireLives(historyModalTire, localMaintenance);
                        if (lives.length > 0) {
                            return (
                                <div className="p-5 border-b border-slate-100 bg-slate-50/50">
                                    <h4 className="text-xs font-bold text-slate-500 uppercase mb-3 flex items-center gap-2">
                                        <RefreshCw size={14}/> Ciclos de Vida (Resumo)
                                    </h4>
                                    <div className="space-y-2">
                                        {lives.map((life, idx) => (
                                            <div key={idx} className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm flex justify-between items-center text-sm">
                                                <div className="flex items-center gap-3">
                                                    <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded text-xs font-bold">
                                                        Vida {life.lifeIndex}
                                                    </span>
                                                    <div className="flex flex-col">
                                                        <span className="font-bold text-slate-700">
                                                            {life.lifeIndex === 0 ? 'Novo' : 'Recapado'}
                                                        </span>
                                                        <span className="text-[10px] text-slate-400 font-mono">
                                                            {MOCK_VEHICLES.find(v => v.id === life.vehicleId)?.plate || 'Placa N/A'}
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-6 text-xs text-slate-600">
                                                    <div className="flex items-center gap-1.5" title="Data Entrada">
                                                        <PlayCircle size={14} className="text-emerald-500"/> 
                                                        {life.installDate}
                                                    </div>
                                                    <div className="flex items-center gap-1.5" title="Data Saída">
                                                        {life.status === 'ACTIVE' ? (
                                                            <span className="text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-full flex items-center gap-1">
                                                                <Disc size={10} className="animate-pulse"/> Ativo
                                                            </span>
                                                        ) : (
                                                            <>
                                                                <StopCircle size={14} className="text-red-500"/> 
                                                                {life.removalDate}
                                                            </>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            );
                        }
                        return null;
                    })()}

                    <div className="px-6 py-3 bg-slate-50 border-b border-slate-100">
                        <h4 className="text-xs font-bold text-slate-500 uppercase">Registros Detalhados</h4>
                    </div>

                    {getTireHistory(historyModalTire).length === 0 ? (
                        <div className="p-8 text-center text-slate-400">
                            Nenhum registro encontrado para este pneu.
                        </div>
                    ) : (
                        <div className="divide-y divide-slate-100">
                            {getTireHistory(historyModalTire).map((record, i) => (
                                <div key={record.id} className="p-5 hover:bg-slate-50 transition-colors group">
                                    <div className="flex justify-between items-start mb-2">
                                        <div className="flex items-center gap-2">
                                            <span className={clsx(
                                                "px-2 py-1 rounded text-[10px] font-bold uppercase flex items-center gap-1",
                                                record.type === MaintenanceType.MOUNT ? "bg-emerald-100 text-emerald-700" :
                                                record.type === MaintenanceType.DISMOUNT ? "bg-red-100 text-red-700" :
                                                record.type === MaintenanceType.ROTATION ? "bg-blue-100 text-blue-700" :
                                                record.type === MaintenanceType.RETREAD ? "bg-orange-100 text-orange-700" : "bg-slate-100 text-slate-700"
                                            )}>
                                                {getMaintenanceIcon(record.type)} {record.type}
                                            </span>
                                            {record.position && (
                                                <span className="text-xs font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                                                    Pos: {record.position}
                                                </span>
                                            )}
                                        </div>
                                        <span className="text-xs font-bold text-slate-400 flex items-center gap-1">
                                            <Calendar size={12}/> {record.date}
                                        </span>
                                    </div>
                                    
                                    <div className="flex items-baseline gap-4 mb-2">
                                        {record.odometer > 0 && (
                                            <div className="text-sm font-bold text-slate-800">
                                                KM: {record.odometer.toLocaleString()}
                                            </div>
                                        )}
                                        {record.cost > 0 && (
                                            <div className="text-sm font-medium text-slate-500">
                                                Custo: R$ {record.cost.toFixed(2)}
                                            </div>
                                        )}
                                    </div>

                                    <p className="text-xs text-slate-600 leading-relaxed mb-2">{record.description}</p>
                                    
                                    <div className="flex items-center gap-2 text-[10px] text-slate-400 uppercase font-bold">
                                        <Wrench size={10} /> {record.performedBy}
                                        {record.vehicleId && (
                                            <>
                                                <span className="text-slate-300">|</span>
                                                <Truck size={10} /> {MOCK_VEHICLES.find(v => v.id === record.vehicleId)?.plate || 'Veículo N/A'}
                                            </>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
          </div>
      )}
    </div>
  );
};
