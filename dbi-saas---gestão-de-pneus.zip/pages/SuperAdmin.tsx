
import React, { useState } from 'react';
import { MOCK_TENANTS, MOCK_PLANS } from '../services/mockData';
import { Tenant } from '../types';
import { Building, Users, CreditCard, Ban, CheckCircle, Plus, Edit2, Search, X, Save, Power, Calendar, DollarSign, PlayCircle, PauseCircle, MapPin, Phone, Mail, MessageSquare, Send } from 'lucide-react';
import { clsx } from 'clsx';

export const SuperAdminPage: React.FC = () => {
  const [tenants, setTenants] = useState<Tenant[]>(MOCK_TENANTS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTenant, setEditingTenant] = useState<Tenant | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // New Note State
  const [newNoteText, setNewNoteText] = useState('');

  // Form State
  const [formData, setFormData] = useState<Tenant>({
    id: '',
    name: '', // Razão Social
    fantasyName: '', // Nome Fantasia
    document: '', // CNPJ
    
    address: {
        street: '',
        number: '',
        district: '',
        state: '',
        zipCode: ''
    },

    contactName: '',
    email: '',
    phone: '',
    
    plan: MOCK_PLANS[0]?.name || '',
    status: 'Active',
    expiresAt: '',
    assetLimit: 5,
    currentAssets: 0,
    
    origin: '',
    internalNotes: []
  });

  const filteredTenants = tenants.filter(t => 
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    t.document.includes(searchTerm)
  );

  const handleOpenModal = (tenant?: Tenant) => {
    setNewNoteText('');
    if (tenant) {
      setEditingTenant(tenant);
      setFormData(tenant);
    } else {
      setEditingTenant(null);
      // Default new tenant
      setFormData({
        id: `t${Date.now()}`,
        name: '',
        fantasyName: '',
        document: '',
        address: {
            street: '',
            number: '',
            district: '',
            state: '',
            zipCode: ''
        },
        contactName: '',
        email: '',
        phone: '',
        plan: MOCK_PLANS[0]?.name || '',
        status: 'Active',
        expiresAt: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0], // +1 month default
        assetLimit: MOCK_PLANS[0]?.assetLimit || 5,
        currentAssets: 0,
        origin: '',
        internalNotes: []
      });
    }
    setIsModalOpen(true);
  };

  const handleAddressChange = (field: string, value: string) => {
      setFormData(prev => ({
          ...prev,
          address: {
              ...prev.address,
              [field]: value
          }
      }));
  };

  // Update asset limit when plan changes
  const handlePlanChange = (planName: string) => {
      const selectedPlan = MOCK_PLANS.find(p => p.name === planName);
      setFormData(prev => ({
          ...prev, 
          plan: planName,
          assetLimit: selectedPlan?.assetLimit || prev.assetLimit
      }));
  };

  const handleAddNote = () => {
      if (!newNoteText.trim()) return;

      const newNote = {
          id: `n${Date.now()}`,
          text: newNoteText,
          date: new Date().toLocaleString('pt-BR'),
          author: 'Super Admin' // Hardcoded for this view context
      };

      setFormData(prev => ({
          ...prev,
          internalNotes: [newNote, ...(prev.internalNotes || [])]
      }));
      setNewNoteText('');
  };

  const handleSave = () => {
    if (!formData.name || !formData.document || !formData.plan || !formData.email) return alert('Campos obrigatórios: Razão Social, CNPJ, Email e Plano');

    if (editingTenant) {
      setTenants(prev => prev.map(t => t.id === editingTenant.id ? formData : t));
    } else {
      const newTenant = { ...formData, id: `t${Date.now()}` };
      setTenants(prev => [...prev, newTenant]);
    }
    setIsModalOpen(false);
  };

  const handlePayment = () => {
      // Extend expiration by 30 days and set status to Active
      const currentExpire = new Date(formData.expiresAt || new Date());
      const newExpire = new Date(currentExpire.setMonth(currentExpire.getMonth() + 1));
      
      setFormData(prev => ({
          ...prev,
          status: 'Active',
          expiresAt: newExpire.toISOString().split('T')[0]
      }));
      alert("Pagamento registrado! Assinatura estendida em 30 dias e status Ativo.");
  };

  const handleStatusChange = (newStatus: 'Active' | 'Paused' | 'Cancelled') => {
      if (confirm(`Tem certeza que deseja alterar o status para ${newStatus}?`)) {
          setFormData(prev => ({ ...prev, status: newStatus }));
      }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
         <div>
            <h1 className="text-2xl font-bold text-slate-800">Painel Super Admin</h1>
            <p className="text-slate-500">Gestão de Clientes (Tenants) e Assinaturas</p>
         </div>
         <button 
            onClick={() => handleOpenModal()}
            className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors shadow-sm"
         >
            <Plus size={18} /> Nova Empresa (Tenant)
         </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <div className="bg-slate-900 text-white p-6 rounded-xl shadow-lg">
            <p className="text-slate-400 text-sm font-bold uppercase">Total MRR (Estimado)</p>
            <h3 className="text-3xl font-bold mt-2">R$ 45.200,00</h3>
            <p className="text-emerald-400 text-xs mt-2">+5% vs mês anterior</p>
         </div>
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <p className="text-slate-500 text-sm font-bold uppercase">Tenants Ativos</p>
            <h3 className="text-3xl font-bold text-slate-800 mt-2">{tenants.filter(t => t.status === 'Active').length}</h3>
         </div>
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <p className="text-slate-500 text-sm font-bold uppercase">Assinaturas Pro</p>
            <h3 className="text-3xl font-bold text-slate-800 mt-2">{tenants.filter(t => t.plan.includes('Pro')).length}</h3>
         </div>
      </div>

      {/* Search */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
         <div className="relative">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input 
               type="text" 
               placeholder="Buscar empresa por nome ou CNPJ..." 
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" 
             />
         </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
         <div className="overflow-x-auto">
            <table className="w-full text-left text-sm whitespace-nowrap">
                <thead className="bg-slate-50 text-slate-500 uppercase text-xs">
                <tr>
                    <th className="px-6 py-4">Empresa</th>
                    <th className="px-6 py-4">Plano</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Assets</th>
                    <th className="px-6 py-4">Vencimento</th>
                    <th className="px-6 py-4 text-right">Ações</th>
                </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                {filteredTenants.map(tenant => (
                    <tr key={tenant.id} className="hover:bg-slate-50">
                        <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded bg-slate-200 flex items-center justify-center text-slate-500">
                                <Building size={16} />
                            </div>
                            <div>
                                <span className="font-bold text-slate-700 block">{tenant.fantasyName || tenant.name}</span>
                                <span className="text-xs text-slate-500">{tenant.document}</span>
                            </div>
                            </div>
                        </td>
                        <td className="px-6 py-4">
                            <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-xs font-bold uppercase">{tenant.plan}</span>
                        </td>
                        <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                                {tenant.status === 'Active' && <CheckCircle size={16} className="text-emerald-500" />}
                                {tenant.status === 'Paused' && <PauseCircle size={16} className="text-amber-500" />}
                                {(tenant.status === 'Cancelled' || tenant.status === 'Expired') && <Ban size={16} className="text-red-500" />}
                                
                                <span className={clsx(
                                    "font-medium", 
                                    tenant.status === 'Active' ? "text-emerald-700" : 
                                    tenant.status === 'Paused' ? "text-amber-700" : "text-red-700"
                                )}>
                                    {tenant.status === 'Active' ? 'Ativo' : 
                                     tenant.status === 'Paused' ? 'Pausado' :
                                     tenant.status === 'Expired' ? 'Vencido' : 'Cancelado'}
                                </span>
                            </div>
                        </td>
                        <td className="px-6 py-4 text-slate-600">
                            {tenant.currentAssets} / {tenant.assetLimit}
                        </td>
                        <td className="px-6 py-4 text-slate-600 font-mono">
                            {tenant.expiresAt}
                        </td>
                        <td className="px-6 py-4 text-right">
                            <button 
                                onClick={() => handleOpenModal(tenant)}
                                className="text-slate-400 hover:text-primary-600 transition-colors p-1"
                                title="Gerenciar"
                            >
                                <Edit2 size={18} />
                            </button>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
         </div>
      </div>

      {/* Modal - Create/Edit Tenant */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl z-10 p-6 animate-scale-in max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6 border-b border-slate-100 pb-4">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                  <Building className="text-primary-600" size={24} />
                  {editingTenant ? 'Gerenciar Empresa (Tenant)' : 'Cadastrar Nova Empresa'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* LEFT COLUMN: REGISTRATION INFO */}
                <div className="space-y-6">
                    <div>
                        <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2 border-l-4 border-primary-500 pl-2">
                             Dados da Empresa
                        </h4>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Razão Social</label>
                                <input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" placeholder="Ex: Transportadora Silva Ltda" />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Fantasia</label>
                                    <input type="text" value={formData.fantasyName} onChange={e => setFormData({...formData, fantasyName: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" placeholder="Ex: Silva Log" />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">CPF / CNPJ</label>
                                    <input type="text" value={formData.document} onChange={e => setFormData({...formData, document: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" placeholder="00.000.000/0000-00" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2 border-l-4 border-purple-500 pl-2">
                             Endereço
                        </h4>
                        <div className="space-y-4">
                            <div className="grid grid-cols-3 gap-4">
                                <div className="col-span-2">
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Logradouro</label>
                                    <input type="text" value={formData.address.street} onChange={e => handleAddressChange('street', e.target.value)} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Número</label>
                                    <input type="text" value={formData.address.number} onChange={e => handleAddressChange('number', e.target.value)} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                                </div>
                            </div>
                            <div className="grid grid-cols-3 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Bairro</label>
                                    <input type="text" value={formData.address.district} onChange={e => handleAddressChange('district', e.target.value)} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">UF</label>
                                    <input type="text" value={formData.address.state} onChange={e => handleAddressChange('state', e.target.value)} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" maxLength={2} placeholder="SP" />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">CEP</label>
                                    <input type="text" value={formData.address.zipCode} onChange={e => handleAddressChange('zipCode', e.target.value)} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2 border-l-4 border-emerald-500 pl-2">
                             Contato Principal
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                             <div className="md:col-span-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Responsável</label>
                                <input type="text" value={formData.contactName} onChange={e => setFormData({...formData, contactName: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                             </div>
                             <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email</label>
                                <input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                             </div>
                             <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Telefone</label>
                                <input type="text" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                             </div>
                        </div>
                    </div>

                    <div>
                        <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2 border-l-4 border-orange-500 pl-2">
                             Origem do Cliente
                        </h4>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Como conheceu?</label>
                            <select 
                                value={formData.origin || ''} 
                                onChange={e => setFormData({...formData, origin: e.target.value})} 
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                            >
                                <option value="">Selecione...</option>
                                <option value="Google">Google / Pesquisa Orgânica</option>
                                <option value="Instagram">Instagram / Facebook</option>
                                <option value="Linkedin">Linkedin</option>
                                <option value="Indicacao">Indicação</option>
                                <option value="Evento">Evento / Feira</option>
                                <option value="Outros">Outros</option>
                            </select>
                        </div>
                    </div>
                </div>

                {/* RIGHT COLUMN: SUBSCRIPTION & ACTIONS & NOTES */}
                <div className="space-y-6">
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 h-fit">
                        <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                            <CreditCard className="text-primary-600" size={20}/> Assinatura e Plano
                        </h4>

                        <div className="space-y-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Plano Atual</label>
                                <select 
                                    value={formData.plan} 
                                    onChange={e => handlePlanChange(e.target.value)} 
                                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                                >
                                    {MOCK_PLANS.map(p => <option key={p.id} value={p.name}>{p.name} - {p.assetLimit} Assets</option>)}
                                </select>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Limite Assets</label>
                                    <input type="number" value={formData.assetLimit} disabled className="w-full border border-slate-300 bg-slate-100 rounded-lg px-3 py-2 text-slate-500" />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Uso Atual</label>
                                    <input type="number" value={formData.currentAssets} disabled className="w-full border border-slate-300 bg-slate-100 rounded-lg px-3 py-2 text-slate-500" />
                                </div>
                            </div>

                            <div className="border-t border-slate-200 my-4"></div>

                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status da Assinatura</label>
                                <div className="flex items-center gap-2 mt-1">
                                    <span className={clsx(
                                        "px-3 py-1 rounded-full text-xs font-bold uppercase flex items-center gap-1",
                                        formData.status === 'Active' ? "bg-emerald-100 text-emerald-700" :
                                        formData.status === 'Paused' ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"
                                    )}>
                                        {formData.status === 'Active' ? <CheckCircle size={14}/> : formData.status === 'Paused' ? <PauseCircle size={14}/> : <Ban size={14}/>}
                                        {formData.status === 'Active' ? 'Ativa' : formData.status === 'Paused' ? 'Pausada' : formData.status === 'Expired' ? 'Vencida' : 'Cancelada'}
                                    </span>
                                </div>
                            </div>
                            
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Vencimento da Fatura</label>
                                <input type="date" value={formData.expiresAt} onChange={e => setFormData({...formData, expiresAt: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                            </div>

                            <div className="pt-6 space-y-2">
                                <button 
                                    onClick={handlePayment}
                                    className="w-full flex items-center justify-center gap-2 px-3 py-3 bg-emerald-600 text-white rounded-lg text-sm font-bold hover:bg-emerald-700 transition-colors shadow-sm"
                                >
                                    <DollarSign size={16} /> Registrar Pagamento (+30 dias)
                                </button>
                                
                                <div className="flex gap-2">
                                    {formData.status !== 'Active' && (
                                        <button 
                                            onClick={() => handleStatusChange('Active')}
                                            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 transition-colors"
                                        >
                                            <PlayCircle size={14} /> Ativar
                                        </button>
                                    )}

                                    {formData.status === 'Active' && (
                                        <button 
                                            onClick={() => handleStatusChange('Paused')}
                                            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-amber-100 text-amber-700 border border-amber-200 rounded-lg text-xs font-bold hover:bg-amber-200 transition-colors"
                                        >
                                            <PauseCircle size={14} /> Pausar
                                        </button>
                                    )}
                                    
                                    {formData.status !== 'Cancelled' && (
                                        <button 
                                            onClick={() => handleStatusChange('Cancelled')}
                                            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-red-50 text-red-600 border border-red-200 rounded-lg text-xs font-bold hover:bg-red-100 transition-colors"
                                        >
                                            <Ban size={14} /> Cancelar
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* INTERNAL NOTES SECTION */}
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-fit">
                        <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                            <MessageSquare className="text-blue-600" size={20}/> Observações Internas
                        </h4>
                        
                        <div className="bg-slate-50 rounded-lg p-3 mb-4 max-h-48 overflow-y-auto space-y-3">
                            {(!formData.internalNotes || formData.internalNotes.length === 0) ? (
                                <p className="text-center text-xs text-slate-400 py-2">Nenhuma observação registrada.</p>
                            ) : (
                                formData.internalNotes.map(note => (
                                    <div key={note.id} className="bg-white p-3 rounded border border-slate-100 shadow-sm">
                                        <p className="text-sm text-slate-700 mb-1">{note.text}</p>
                                        <div className="flex justify-between items-center text-[10px] text-slate-400">
                                            <span className="font-bold">{note.author}</span>
                                            <span>{note.date}</span>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>

                        <div className="flex gap-2">
                            <input 
                                type="text" 
                                value={newNoteText}
                                onChange={(e) => setNewNoteText(e.target.value)}
                                className="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500"
                                placeholder="Adicionar apontamento..."
                                onKeyDown={(e) => e.key === 'Enter' && handleAddNote()}
                            />
                            <button 
                                onClick={handleAddNote}
                                className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 transition-colors"
                            >
                                <Send size={16} />
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="mt-8 flex gap-3 pt-4 border-t border-slate-100">
              <button onClick={() => setIsModalOpen(false)} className="flex-1 py-3 text-slate-600 font-bold bg-slate-100 rounded-xl hover:bg-slate-200">Fechar / Cancelar</button>
              <button onClick={handleSave} className="flex-1 py-3 text-white font-bold bg-primary-600 rounded-xl hover:bg-primary-700 flex items-center justify-center gap-2 shadow-lg shadow-primary-500/30">
                 <Save size={18} /> Salvar e Atualizar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
