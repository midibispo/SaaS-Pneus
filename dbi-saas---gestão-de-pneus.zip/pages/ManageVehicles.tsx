
import React, { useState, useEffect } from 'react';
import { MOCK_VEHICLES, MOCK_BRANDS, GLOBAL_VEHICLE_MODELS, GLOBAL_VEHICLE_TYPES, VEHICLE_LAYOUTS } from '../services/mockData';
import { Vehicle, VehicleCategory } from '../types';
import { Plus, Edit2, Trash2, Search, Save, X, Truck, Bus, Container, Disc } from 'lucide-react';
import { clsx } from 'clsx';

// Implements only for Rigid Trucks (Bodywork)
const IMPLEMENT_TYPES = [
  "Baú",
  "Sider",
  "Carga Seca",
  "Grade Baixa",
  "Tanque",
  "Basculante",
  "Prancha",
  "Cegonha",
  "Betoneira",
  "Poliguindaste",
  "Frigorífico",
  "Canavieiro",
  "Florestal",
  "Munck"
];

export const ManageVehiclesPage: React.FC = () => {
  const [vehicles, setVehicles] = useState<Vehicle[]>(MOCK_VEHICLES);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Form State
  const [formData, setFormData] = useState<Partial<Vehicle>>({
    plate: '',
    category: 'TRUCK',
    brand: '',
    model: '',
    type: 'Toco (4x2)',
    implement: '',
    odometer: 0,
    status: 'ACTIVE'
  });

  // State to hold models based on selected brand
  const [availableModels, setAvailableModels] = useState<string[]>([]);

  // Update available models when brand changes
  useEffect(() => {
      if (formData.brand) {
          const models = GLOBAL_VEHICLE_MODELS[formData.brand] || [];
          setAvailableModels(models);
          
          if (!models.includes(formData.model || '') && !editingVehicle) {
              setFormData(prev => ({ ...prev, model: '' }));
          }
      } else {
          setAvailableModels([]);
      }
  }, [formData.brand, editingVehicle]);

  // Business Logic: Only Rigid Trucks have implements
  const canHaveImplement = (category: string, type: string) => {
      if (category === 'TRAILER') return false; 
      if (category !== 'TRUCK') return false;
      if (type && type.toLowerCase().includes('cavalo')) return false;
      return true; 
  };

  // Reset Type when Category changes
  useEffect(() => {
    if (formData.category) {
        const availableTypes = GLOBAL_VEHICLE_TYPES[formData.category as VehicleCategory] || [];
        // Only reset if current type doesn't belong to new category
        if (!availableTypes.includes(formData.type || '')) {
            const newType = availableTypes[0];
            setFormData(prev => ({
                ...prev, 
                type: newType,
                implement: canHaveImplement(formData.category as string, newType) ? prev.implement : ''
            }));
        }
    }
  }, [formData.category]);

  // Effect to clear implement when type changes if necessary
  useEffect(() => {
      if (formData.category && formData.type) {
          const allowed = canHaveImplement(formData.category, formData.type);
          if (!allowed && formData.implement) {
              setFormData(prev => ({ ...prev, implement: '' }));
          }
      }
  }, [formData.type, formData.category]);

  const filteredVehicles = vehicles.filter(v => 
    v.plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.model.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const vehicleBrands = MOCK_BRANDS.filter(b => b.type === 'VEHICLE');

  // Logic to calculate total tires based on selected type
  const calculateTotalTires = (type: string) => {
      const layout = VEHICLE_LAYOUTS[type];
      if (!layout) return 0;
      
      let count = 0;
      layout.forEach(axle => {
          count += axle.isDual ? 4 : 2;
      });
      return count;
  };

  const currentTireCount = calculateTotalTires(formData.type || '');

  const handleOpenModal = (vehicle?: Vehicle) => {
    if (vehicle) {
      setEditingVehicle(vehicle);
      setFormData(vehicle);
    } else {
      setEditingVehicle(null);
      setFormData({
        plate: '',
        category: 'TRUCK',
        brand: '',
        model: '',
        type: GLOBAL_VEHICLE_TYPES['TRUCK'][0],
        implement: '',
        odometer: 0,
        status: 'ACTIVE'
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.plate || !formData.model || !formData.brand) return alert('Preencha os campos obrigatórios');

    const normalizedPlate = formData.plate.toUpperCase().trim();
    const duplicate = vehicles.find(v => v.plate === normalizedPlate && v.id !== editingVehicle?.id);
    
    if (duplicate) {
        alert("ERRO DE VALIDAÇÃO: Já existe um veículo cadastrado com esta placa.");
        return;
    }

    const normalizeStr = (str: string) => str.toLowerCase().replace(/\s+/g, '');
    const normalizedInputModel = normalizeStr(formData.model);
    const existingModel = availableModels.find(m => normalizeStr(m) === normalizedInputModel);
    const finalModel = existingModel || formData.model;

    if (editingVehicle) {
      setVehicles(prev => prev.map(v => v.id === editingVehicle.id ? { ...v, ...formData, plate: normalizedPlate, model: finalModel } as Vehicle : v));
    } else {
      const newVehicle: Vehicle = {
        ...formData,
        plate: normalizedPlate,
        model: finalModel,
        id: `v${Date.now()}`,
      } as Vehicle;
      setVehicles(prev => [...prev, newVehicle]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir este veículo?')) {
      setVehicles(prev => prev.filter(v => v.id !== id));
    }
  };

  const getCategoryIcon = (cat: VehicleCategory) => {
      switch(cat) {
          case 'TRUCK': return <Truck size={14} />;
          case 'TRAILER': return <Container size={14} />;
          case 'BUS': return <Bus size={14} />;
      }
  };

  const getCategoryLabel = (cat: VehicleCategory) => {
    switch(cat) {
        case 'TRUCK': return 'Caminhão';
        case 'TRAILER': return 'Carreta';
        case 'BUS': return 'Ônibus';
    }
};

  const showImplement = canHaveImplement(formData.category || 'TRUCK', formData.type || '');

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Cadastro de Veículos</h1>
          <p className="text-slate-500">Gerenciar frota e especificações técnicas</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors"
        >
          <Plus size={18} /> Novo Veículo
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
         <div className="relative">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input 
               type="text" 
               placeholder="Buscar por placa ou modelo..." 
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" 
             />
         </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left whitespace-nowrap">
            <thead className="bg-slate-50 text-xs text-slate-500 uppercase border-b border-slate-100">
              <tr>
                <th className="px-6 py-4">Categoria</th>
                <th className="px-6 py-4">Placa</th>
                <th className="px-6 py-4">Marca / Modelo</th>
                <th className="px-6 py-4">Tipo / Implemento</th>
                <th className="px-6 py-4">KM Atual</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredVehicles.map(vehicle => (
                <tr key={vehicle.id} className="hover:bg-slate-50">
                  <td className="px-6 py-4">
                      <span className={clsx(
                          "flex items-center gap-1.5 px-2 py-1 rounded text-xs font-bold w-fit",
                          vehicle.category === 'TRUCK' ? "bg-blue-50 text-blue-700" :
                          vehicle.category === 'TRAILER' ? "bg-amber-50 text-amber-700" : "bg-purple-50 text-purple-700"
                      )}>
                          {getCategoryIcon(vehicle.category)}
                          {getCategoryLabel(vehicle.category)}
                      </span>
                  </td>
                  <td className="px-6 py-4 font-bold text-slate-800">{vehicle.plate}</td>
                  <td className="px-6 py-4 text-slate-600">{vehicle.brand} {vehicle.model}</td>
                  <td className="px-6 py-4 text-slate-500">
                    <div className="font-medium">{vehicle.type}</div>
                    {vehicle.implement && <div className="text-xs text-slate-400">Impl: {vehicle.implement}</div>}
                  </td>
                  <td className="px-6 py-4 font-mono">{vehicle.odometer.toLocaleString()} km</td>
                  <td className="px-6 py-4">
                    <span className={clsx(
                      "px-2 py-1 rounded text-xs font-bold uppercase",
                      vehicle.status === 'ACTIVE' ? "bg-emerald-100 text-emerald-700" : 
                      vehicle.status === 'MAINTENANCE' ? "bg-orange-100 text-orange-700" : "bg-slate-100 text-slate-600"
                    )}>
                      {vehicle.status === 'ACTIVE' ? 'Ativo' : vehicle.status === 'MAINTENANCE' ? 'Manutenção' : 'Inativo'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right flex justify-end gap-2">
                    <button onClick={() => handleOpenModal(vehicle)} className="text-blue-500 hover:text-blue-700 p-1"><Edit2 size={16} /></button>
                    <button onClick={() => handleDelete(vehicle.id)} className="text-red-500 hover:text-red-700 p-1"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg z-10 p-6 animate-scale-in max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-slate-800">{editingVehicle ? 'Editar Veículo' : 'Novo Veículo'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
            </div>
            
            <div className="space-y-4">
              {/* Category Selector */}
              <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Categoria do Veículo</label>
                  <div className="grid grid-cols-3 gap-3">
                      {(['TRUCK', 'TRAILER', 'BUS'] as VehicleCategory[]).map(cat => (
                          <button
                            key={cat}
                            onClick={() => setFormData({...formData, category: cat})}
                            className={clsx(
                                "flex flex-col items-center justify-center py-3 rounded-lg border-2 transition-all",
                                formData.category === cat 
                                    ? "border-primary-500 bg-primary-50 text-primary-700" 
                                    : "border-slate-100 bg-white text-slate-500 hover:border-slate-300"
                            )}
                          >
                              {getCategoryIcon(cat)}
                              <span className="text-xs font-bold mt-1">{getCategoryLabel(cat)}</span>
                          </button>
                      ))}
                  </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Placa</label>
                <input 
                  type="text" 
                  value={formData.plate}
                  onChange={e => setFormData({...formData, plate: e.target.value.toUpperCase()})}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                  maxLength={8}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Marca</label>
                  <select 
                    value={formData.brand}
                    onChange={e => setFormData({...formData, brand: e.target.value})}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                  >
                    <option value="">Selecione...</option>
                    {vehicleBrands.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Modelo</label>
                  <input 
                    type="text" 
                    value={formData.model}
                    onChange={e => setFormData({...formData, model: e.target.value})}
                    list="model-suggestions"
                    disabled={!formData.brand}
                    placeholder={!formData.brand ? "Selecione a marca primeiro" : "Selecione ou digite novo"}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-100 disabled:text-slate-400"
                  />
                  <datalist id="model-suggestions">
                      {availableModels.map(m => <option key={m} value={m} />)}
                  </datalist>
                </div>
              </div>
              
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tipo de Veículo (Configuração de Eixos)</label>
                  <select 
                    value={formData.type}
                    onChange={e => setFormData({...formData, type: e.target.value})}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white mb-2"
                  >
                    {(GLOBAL_VEHICLE_TYPES[formData.category as VehicleCategory] || []).map(t => (
                        <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                  
                  {/* Total Tires Display */}
                  <div className="flex items-center gap-2 text-sm text-primary-700 font-bold bg-white p-2 rounded border border-primary-100">
                      <Disc size={16} />
                      Total de Pneus Previstos: {currentTireCount}
                  </div>
              </div>

              {showImplement && (
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Implemento (Carroceria)</label>
                    <select 
                       value={formData.implement || ''}
                       onChange={e => setFormData({...formData, implement: e.target.value})}
                       className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                    >
                       <option value="">Selecione o tipo de carroceria...</option>
                       {IMPLEMENT_TYPES.map(i => <option key={i} value={i}>{i}</option>)}
                    </select>
                  </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Odômetro (Km)</label>
                    <input 
                      type="number" 
                      value={formData.odometer}
                      onChange={e => setFormData({...formData, odometer: Number(e.target.value)})}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status</label>
                    <select 
                       value={formData.status}
                       onChange={e => setFormData({...formData, status: e.target.value as any})}
                       className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                    >
                      <option value="ACTIVE">Ativo</option>
                      <option value="MAINTENANCE">Em Manutenção</option>
                      <option value="INACTIVE">Inativo</option>
                    </select>
                 </div>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setIsModalOpen(false)} className="flex-1 py-2 text-slate-600 font-bold bg-slate-100 rounded-lg hover:bg-slate-200">Cancelar</button>
              <button onClick={handleSave} className="flex-1 py-2 text-white font-bold bg-primary-600 rounded-lg hover:bg-primary-700 flex items-center justify-center gap-2">
                 <Save size={18} /> Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
