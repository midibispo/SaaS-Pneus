
import React, { useState, useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell 
} from 'recharts';
import { 
  FileText, Download, ArrowLeft, TrendingDown, DollarSign, Award, 
  Activity, Briefcase, Truck, Crosshair, GitCompare, Building, 
  ShoppingCart, Gauge, Filter, Calendar, Info
} from 'lucide-react';
import { clsx } from 'clsx';
import { MOCK_TIRES, MOCK_MAINTENANCE, MOCK_VEHICLES } from '../services/mockData';
import { CalculationRules, reconstructTireLives } from '../services/calculationRules';
import { TireStatus } from '../types';

// --- Types & Config ---

type ReportCategory = 'OPERACIONAL' | 'FINANCEIRO' | 'TECNICO' | 'ESTRATEGICO';

interface ReportDef {
  id: string;
  title: string;
  description: string;
  category: ReportCategory;
  icon: React.ElementType;
}

const REPORTS_LIST: ReportDef[] = [
  // 1. Ficha do Pneu (Timeline) - Operacional -> RELATÓRIO DE VIDA DE PNEUS
  { id: 'timeline', title: 'Vida de Pneus (Detalhado)', description: 'Histórico de KM Inicial, KM Final e datas por vida.', category: 'OPERACIONAL', icon: FileText },
  // 13. Quilometragem Geral - Operacional
  { id: 'mileage', title: 'Quilometragem Geral', description: 'Acúmulo de KM por Pneu (Delta acumulado) e Marca/Modelo.', category: 'OPERACIONAL', icon: Gauge },
  
  // 2. Estoque Valorizado - Financeiro
  { id: 'stock_value', title: 'Estoque Valorizado', description: 'Valor financeiro total imobilizado em pneus novos e usados.', category: 'FINANCEIRO', icon: DollarSign },
  // 3. Perdas/Sucata (Prejuízo) - Financeiro
  { id: 'scrap_loss', title: 'Perdas e Sucata', description: 'Análise de prejuízo financeiro por descarte prematuro.', category: 'FINANCEIRO', icon: TrendingDown },
  // 8. Custo por Veículo - Financeiro (CPK INDICATOR)
  { id: 'vehicle_cost', title: 'Custo por Veículo (CPK)', description: 'Custo total (Pneus + Manutenção) ÷ KM Rodado no período.', category: 'FINANCEIRO', icon: Truck },
  // 4. Econômico Básico - Financeiro
  { id: 'economic_basic', title: 'Econômico Básico', description: 'Comparativo de custos: Pneus Novos vs. Recapagens.', category: 'FINANCEIRO', icon: DollarSign },

  // 5. Ranking de Marcas (CPK) - Técnico
  { id: 'cpk_ranking', title: 'Ranking de Marcas (CPK)', description: 'Custo por Quilômetro rodado por fabricante.', category: 'TECNICO', icon: Award },
  // 6. Desempenho por Banda - Técnico
  { id: 'tread_perf', title: 'Desempenho por Banda', description: 'Rendimento quilométrico por desenho de banda de rodagem.', category: 'TECNICO', icon: Activity },
  // 9. Desempenho por Posição - Técnico
  { id: 'pos_perf', title: 'Desempenho por Posição', description: 'Desgaste comparativo: Tração vs Livre vs Direcional.', category: 'TECNICO', icon: Crosshair },
  // 10. Head-to-Head - Técnico
  { id: 'head_to_head', title: 'Head-to-Head', description: 'Comparativo direto: Marca A vs Marca B.', category: 'TECNICO', icon: GitCompare },

  // 7. Desempenho de Recapadora - Estratégico
  { id: 'retreader_perf', title: 'Desempenho de Recapadora', description: 'Qualidade e durabilidade por fornecedor de serviço.', category: 'ESTRATEGICO', icon: Briefcase },
  // 11. Consolidado Multiempresa - Estratégico
  { id: 'multi_tenant', title: 'Consolidado Multiempresa', description: 'Visão unificada de custos para grupos econômicos.', category: 'ESTRATEGICO', icon: Building },
  // 12. Previsão de Compras - Estratégico
  { id: 'purchase_forecast', title: 'Previsão de Compras', description: 'Preditivo de necessidade de reposição (Consumo x Lead Time).', category: 'ESTRATEGICO', icon: ShoppingCart },
];

const CATEGORIES: { id: ReportCategory; label: string; color: string }[] = [
  { id: 'OPERACIONAL', label: 'Operacional', color: 'bg-blue-100 text-blue-700' },
  { id: 'FINANCEIRO', label: 'Financeiro', color: 'bg-emerald-100 text-emerald-700' },
  { id: 'TECNICO', label: 'Técnico & Performance', color: 'bg-orange-100 text-orange-700' },
  { id: 'ESTRATEGICO', label: 'Estratégico & Gestão', color: 'bg-purple-100 text-purple-700' },
];

const COLORS = ['#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

export const ReportsPage: React.FC = () => {
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null);
  const selectedReport = REPORTS_LIST.find(r => r.id === selectedReportId);

  // Filters State
  const [filterBrand, setFilterBrand] = useState('');
  const [filterTire, setFilterTire] = useState('');

  // --- Dynamic Data Calculation ---

  const reportData = useMemo(() => {
    if (!selectedReportId) return null;

    switch (selectedReportId) {
        
        // RELATÓRIO DE QUILOMETRAGEM GERAL (Calculo 2: Soma Delta)
        case 'mileage': {
            let filteredTires = MOCK_TIRES;
            
            // Apply Filters
            if (filterBrand) {
                filteredTires = filteredTires.filter(t => t.brand.toLowerCase().includes(filterBrand.toLowerCase()));
            }
            if (filterTire) {
                filteredTires = filteredTires.filter(t => t.serialNumber.includes(filterTire));
            }

            const data = filteredTires.map(tire => {
                const lives = reconstructTireLives(tire, MOCK_MAINTENANCE);
                
                // KM_Total_Acumulado: Sum of kmTraveled of all lives (active + ended)
                // reconstructTireLives already calculates 'kmTraveled' for ended lives.
                // For active lives, we need to calculate current delta.
                
                let totalAccumulated = 0;
                let currentLifeKM = 0;

                lives.forEach(life => {
                    let lifeKm = 0;
                    if (life.status === 'ENDED') {
                        lifeKm = life.kmTraveled;
                    } else {
                        // For Active life, calculate Delta: Current Vehicle KM - Install Vehicle KM
                        const vehicle = MOCK_VEHICLES.find(v => v.id === life.vehicleId);
                        if (vehicle) {
                            lifeKm = vehicle.odometer - life.installOdometer;
                            currentLifeKM = lifeKm;
                        }
                    }
                    totalAccumulated += lifeKm;
                });

                return {
                    serialNumber: tire.serialNumber,
                    brand: tire.brand,
                    model: tire.model,
                    currentLifeKM,
                    totalAccumulated
                };
            }).sort((a,b) => b.totalAccumulated - a.totalAccumulated);

            return {
                chartData: data, // For table
                columns: [
                    { key: 'serialNumber', label: 'Fogo (Pneu)' },
                    { key: 'brand', label: 'Marca' },
                    { key: 'model', label: 'Modelo' },
                    { key: 'currentLifeKM', label: 'KM Vida Atual (Delta)', format: (v: number) => `${v.toLocaleString()} km` },
                    { key: 'totalAccumulated', label: 'KM Total Acumulado', format: (v: number) => `${v.toLocaleString()} km` }
                ]
            };
        }

        // RELATÓRIO DE VIDA DE PNEUS (Start/End KM)
        case 'timeline': {
            // Flatten lives from all tires
            let livesData: any[] = [];
            
            MOCK_TIRES.forEach(tire => {
                // Apply Filters
                if (filterBrand && !tire.brand.toLowerCase().includes(filterBrand.toLowerCase())) return;
                if (filterTire && !tire.serialNumber.includes(filterTire)) return;

                const lives = reconstructTireLives(tire, MOCK_MAINTENANCE);
                lives.forEach(life => {
                    // For active life, calculate current end KM as vehicle odometer
                    let endKm = life.removalOdometer;
                    let endDate = life.removalDate;
                    
                    if (life.status === 'ACTIVE') {
                        const v = MOCK_VEHICLES.find(veh => veh.id === life.vehicleId);
                        endKm = v ? v.odometer : life.installOdometer; // Fallback
                        endDate = 'Atual (Ativo)';
                    }

                    livesData.push({
                        id: tire.serialNumber,
                        lifeIndex: life.lifeIndex === 0 ? 'Nova (0)' : `Reforma (${life.lifeIndex})`,
                        installDate: life.installDate,
                        installKm: life.installOdometer,
                        endDate: endDate || '-',
                        endKm: endKm,
                        plate: MOCK_VEHICLES.find(v => v.id === life.vehicleId)?.plate || 'N/A'
                    });
                });
            });

            return {
                chartData: livesData,
                columns: [
                    { key: 'id', label: 'Fogo' },
                    { key: 'plate', label: 'Veículo' },
                    { key: 'lifeIndex', label: 'Vida' },
                    { key: 'installDate', label: 'Data Inicial' },
                    { key: 'installKm', label: 'KM Inicial', format: (v: number) => v.toLocaleString() },
                    { key: 'endDate', label: 'Data Final' },
                    { key: 'endKm', label: 'KM Final (Atual)', format: (v: number) => v ? v.toLocaleString() : '-' },
                ]
            };
        }

        // RELATÓRIO DE CUSTO POR VEÍCULO (CPK Principal)
        case 'vehicle_cost': {
            const data = MOCK_VEHICLES.map(v => {
                // 1. Calculate Total Tire Cost in period (Purchase + Retreads allocated to this vehicle's lives)
                // For MVP, we sum costs of lives that ENDED on this vehicle or are ACTIVE on this vehicle.
                // NOTE: Simply summing PurchaseCost for active tires + Retread costs.
                
                // Get all tires ever installed on this vehicle (via Maintenance Logs)
                const vehicleRecords = MOCK_MAINTENANCE.filter(r => r.vehicleId === v.id);
                const vehicleTireIds = new Set(vehicleRecords.map(r => r.tireId));
                
                let totalCost = 0;
                
                // Logic: Sum costs of Tires/Services linked to this vehicle
                // This is a simplification. Real CPK requires precise allocation.
                // We will use CalculationRules logic but ensure it captures current state.
                
                const vehicleCostTires = CalculationRules.calculateVehicleCostInPeriod(MOCK_TIRES, MOCK_MAINTENANCE, v.id, '2020-01-01', '2030-12-31');
                
                // Also add Service Costs (Maintenance that is NOT Mount/Dismount, e.g. Repairs, Alignments)
                const serviceCosts = vehicleRecords
                    .filter(r => !['MOUNT', 'DISMOUNT'].includes(r.type))
                    .reduce((sum, r) => sum + r.cost, 0);

                totalCost = vehicleCostTires + serviceCosts;

                // 2. Calculate Total KM in period (Vehicle Odometer)
                // Assuming vehicle started at 0 for MVP simple CPK, or use a "period" logic.
                // User asked: "Custo total com pneus no período ÷ KM rodado no período"
                // Let's assume the "Period" is the lifetime of the vehicle data available (Current Odometer).
                const totalKm = v.odometer;

                // 3. CPK
                const cpk = totalKm > 0 ? totalCost / totalKm : 0;

                return { 
                    name: v.plate, 
                    cost: totalCost, 
                    km: totalKm, 
                    cpk,
                    model: v.model 
                };
            }).sort((a,b) => b.cpk - a.cpk); // Sort by CPK (Indicator)

            return {
                chartData: data,
                columns: [
                    { key: 'name', label: 'Placa' },
                    { key: 'model', label: 'Modelo' },
                    { key: 'cost', label: 'Custo Total (R$)', format: (v: number) => `R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` },
                    { key: 'km', label: 'KM Rodado', format: (v: number) => `${v.toLocaleString()} km` },
                    { key: 'cpk', label: 'CPK (R$/km)', format: (v: number) => `R$ ${v.toFixed(4)}` } // Main Indicator
                ]
            };
        }

        // ... (Keep existing reports standard logic)
        case 'cpk_ranking': {
            // Get unique brands
            const brands = Array.from(new Set(MOCK_TIRES.map(t => t.brand)));
            const data = brands.map(brand => {
                const perf = CalculationRules.calculateBrandPerformance(brand, MOCK_TIRES, MOCK_MAINTENANCE);
                return {
                    name: brand,
                    cpk: perf.avgCPK,
                    km: perf.avgKm,
                    rawCpk: perf.avgCPK // For sorting
                };
            }).filter(d => d.km > 0).sort((a,b) => a.rawCpk - b.rawCpk); // Lower CPK is better
            return {
                chartData: data,
                columns: [
                    { key: 'name', label: 'Marca' },
                    { key: 'km', label: 'KM Médio (Vida 0)', format: (v: number) => `${v.toLocaleString()} km` },
                    { key: 'cpk', label: 'CPK (R$/km)', format: (v: number) => `R$ ${v.toFixed(4)}` }
                ]
            };
        }

        case 'stock_value': {
            const stockTires = MOCK_TIRES.filter(t => t.status === TireStatus.STOCK);
            const totalValue = stockTires.reduce((sum, t) => sum + (t.purchaseCost || 0), 0);
            const byBrand: Record<string, number> = {};
            stockTires.forEach(t => {
                byBrand[t.brand] = (byBrand[t.brand] || 0) + (t.purchaseCost || 0);
            });
            const chartData = Object.entries(byBrand).map(([name, value]) => ({ name, value }));

            return {
                summary: `R$ ${totalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
                chartData,
                columns: [
                    { key: 'name', label: 'Marca' },
                    { key: 'value', label: 'Valor em Estoque', format: (v: number) => `R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` }
                ]
            };
        }

        case 'scrap_loss': {
            const scrapTires = MOCK_TIRES.filter(t => t.status === TireStatus.SCRAP);
            const totalLoss = scrapTires.reduce((sum, t) => sum + (t.purchaseCost || 0), 0);
            const rate = CalculationRules.calculateLossRate(MOCK_TIRES);
            const reasons = { "Fadiga": 1, "Dano Acidental": 0 };
            const chartData = Object.entries(reasons).map(([name, value]) => ({ name, value }));

            return {
                summary: `Taxa: ${rate.toFixed(1)}% | Total: R$ ${totalLoss.toLocaleString()}`,
                chartData,
                columns: [
                    { key: 'name', label: 'Motivo' },
                    { key: 'value', label: 'Qtd Pneus' }
                ]
            };
        }

        case 'pos_perf': {
            const positions = ['1L', '1R', '2L-OUT', '2L-IN', '2R-IN', '2R-OUT'];
            const data = positions.map(pos => {
                const cpk = CalculationRules.calculatePositionPerformance(pos, MOCK_TIRES, MOCK_MAINTENANCE);
                return { name: pos, cpk };
            });
            return {
                chartData: data,
                columns: [
                    { key: 'name', label: 'Posição' },
                    { key: 'cpk', label: 'CPK Médio', format: (v: number) => v > 0 ? `R$ ${v.toFixed(4)}` : '-' }
                ]
            };
        }

        default:
            return { chartData: [], columns: [] };
    }
  }, [selectedReportId, filterBrand, filterTire]);

  // --- Views ---

  // 1. Catalog View (Grid of Cards)
  const renderCatalog = () => (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-800">Relatórios & BI</h1>
           <p className="text-slate-500">Inteligência de dados para tomada de decisão</p>
        </div>
      </div>

      {CATEGORIES.map(cat => {
        const catReports = REPORTS_LIST.filter(r => r.category === cat.id);
        if (catReports.length === 0) return null;

        return (
          <div key={cat.id}>
             <div className="flex items-center gap-2 mb-4">
                <span className={clsx("px-3 py-1 rounded-full text-xs font-bold uppercase", cat.color)}>
                  {cat.label}
                </span>
                <div className="h-px bg-slate-200 flex-1"></div>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {catReports.map(report => (
                   <button 
                      key={report.id}
                      onClick={() => setSelectedReportId(report.id)}
                      className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 hover:border-primary-300 hover:shadow-md transition-all text-left group flex flex-col h-full"
                   >
                      <div className="flex items-start justify-between mb-4">
                         <div className="w-12 h-12 bg-slate-50 rounded-lg flex items-center justify-center text-slate-500 group-hover:bg-primary-50 group-hover:text-primary-600 transition-colors">
                            <report.icon size={24} />
                         </div>
                      </div>
                      <h3 className="font-bold text-slate-800 mb-2 group-hover:text-primary-700">{report.title}</h3>
                      <p className="text-sm text-slate-500 mb-4 flex-1">{report.description}</p>
                      <span className="text-primary-600 text-xs font-bold uppercase tracking-wide flex items-center gap-1 group-hover:underline">
                         Visualizar Relatório
                      </span>
                   </button>
                ))}
             </div>
          </div>
        )
      })}
    </div>
  );

  // 2. Report Detail View
  const renderReportDetail = () => {
    if (!selectedReport || !reportData) return null;

    const hasData = reportData.chartData && reportData.chartData.length > 0;
    const showFilters = ['mileage', 'timeline'].includes(selectedReportId!);

    return (
      <div className="space-y-6 animate-scale-in">
         {/* Header */}
         <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center gap-4">
               <button 
                 onClick={() => { setSelectedReportId(null); setFilterBrand(''); setFilterTire(''); }}
                 className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors"
               >
                  <ArrowLeft size={24} />
               </button>
               <div>
                  <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                     <selectedReport.icon className="text-primary-600" size={24}/>
                     {selectedReport.title}
                  </h1>
                  <p className="text-slate-500">{selectedReport.description}</p>
               </div>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-50 font-bold text-sm shadow-sm">
               <Download size={18} /> Exportar Excel / PDF
            </button>
         </div>

         {/* Filters Bar (Conditional) */}
         <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-wrap gap-4 items-center">
            <div className="flex items-center gap-2 text-slate-500 text-sm font-bold border-r border-slate-200 pr-4">
               <Filter size={16} /> Filtros:
            </div>
            
            {showFilters && (
                <>
                    <div className="flex items-center gap-2">
                        <input 
                            type="text" 
                            placeholder="Marca..."
                            value={filterBrand}
                            onChange={(e) => setFilterBrand(e.target.value)}
                            className="bg-slate-50 border border-slate-200 text-sm rounded p-2 outline-none w-32"
                        />
                    </div>
                    <div className="flex items-center gap-2">
                        <input 
                            type="text" 
                            placeholder="Fogo (Serial)..."
                            value={filterTire}
                            onChange={(e) => setFilterTire(e.target.value)}
                            className="bg-slate-50 border border-slate-200 text-sm rounded p-2 outline-none w-32"
                        />
                    </div>
                </>
            )}

            <div className="flex items-center gap-2">
               <Calendar size={16} className="text-slate-400" />
               <select className="bg-slate-50 border-none text-sm font-medium rounded p-1 outline-none">
                  <option>Todo o Período</option>
                  <option>Últimos 30 dias</option>
                  <option>Ano Atual (YTD)</option>
               </select>
            </div>
            <div className="ml-auto">
               <button className="px-4 py-1.5 bg-primary-600 text-white rounded text-xs font-bold hover:bg-primary-700">
                  Aplicar
               </button>
            </div>
         </div>

         {/* Summary Widget */}
         {reportData.summary && (
             <div className="bg-slate-900 text-white p-6 rounded-xl shadow-lg w-full md:w-1/3">
                 <p className="text-slate-400 text-xs font-bold uppercase mb-1">Total Consolidado</p>
                 <h3 className="text-3xl font-bold">{reportData.summary}</h3>
             </div>
         )}

         {/* Chart Section - Only if appropriate for the report type */}
         {!['timeline', 'mileage'].includes(selectedReportId!) && (
             <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                <h3 className="font-bold text-slate-800 mb-6">Visualização Gráfica</h3>
                <div className="h-80 w-full">
                   {hasData ? (
                       <ResponsiveContainer width="100%" height="100%">
                          {['stock_value', 'scrap_loss'].includes(selectedReportId!) ? (
                             <PieChart>
                                <Pie data={reportData.chartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                                    {reportData.chartData.map((entry: any, index: number) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip formatter={(value: number) => ['stock_value'].includes(selectedReportId || '') ? `R$ ${value.toLocaleString()}` : value} />
                             </PieChart>
                          ) : (
                             <BarChart data={reportData.chartData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis dataKey="name" />
                                <YAxis />
                                <Tooltip formatter={(value: number, name: string) => 
                                    (name === 'cpk' || name === 'cost') ? `R$ ${value.toLocaleString('pt-BR', {minimumFractionDigits: 4})}` : value
                                } />
                                <Bar 
                                    dataKey={['vehicle_cost', 'stock_value'].includes(selectedReportId!) ? (selectedReportId === 'vehicle_cost' ? 'cpk' : 'cost') : 'cpk'} 
                                    fill="#0ea5e9" 
                                    radius={[4,4,0,0]} 
                                    name={selectedReportId === 'vehicle_cost' ? 'CPK (R$/Km)' : (selectedReportId === 'stock_value' ? 'Valor' : 'CPK')}
                                />
                             </BarChart>
                          )}
                       </ResponsiveContainer>
                   ) : (
                       <div className="h-full flex flex-col items-center justify-center text-slate-400">
                           <Info size={32} className="mb-2"/>
                           <p>Não há dados suficientes para gerar este gráfico.</p>
                       </div>
                   )}
                </div>
             </div>
         )}

         {/* Data Table Section */}
         <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 bg-slate-50">
               <h3 className="font-bold text-slate-800 text-sm uppercase">Dados Detalhados</h3>
            </div>
            <div className="overflow-x-auto">
               <table className="w-full text-sm text-left">
                  <thead className="text-xs text-slate-500 uppercase bg-white border-b border-slate-100">
                     <tr>
                        {reportData.columns?.map((col: any) => (
                            <th key={col.key} className="px-6 py-3">{col.label}</th>
                        ))}
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                     {hasData ? reportData.chartData.map((row: any, i: number) => (
                        <tr key={i} className="hover:bg-slate-50">
                           {reportData.columns?.map((col: any) => (
                               <td key={col.key} className="px-6 py-4 text-slate-700">
                                   {col.format ? col.format(row[col.key]) : row[col.key]}
                               </td>
                           ))}
                        </tr>
                     )) : (
                         <tr>
                             <td colSpan={reportData.columns?.length || 1} className="px-6 py-8 text-center text-slate-500">
                                 Nenhum registro encontrado.
                             </td>
                         </tr>
                     )}
                  </tbody>
               </table>
            </div>
         </div>
      </div>
    );
  };

  return (
    <div>
       {selectedReportId ? renderReportDetail() : renderCatalog()}
    </div>
  );
};
