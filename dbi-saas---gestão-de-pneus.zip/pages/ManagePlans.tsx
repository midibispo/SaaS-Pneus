
import React, { useState } from 'react';
import { MOCK_PLANS } from '../services/mockData';
import { Plan } from '../types';
import { Plus, Edit2, Trash2, Search, Save, X, CheckCircle, XCircle, CreditCard, Truck, Calendar, Clock } from 'lucide-react';
import { clsx } from 'clsx';

export const ManagePlansPage: React.FC = () => {
  const [plans, setPlans] = useState<Plan[]>(MOCK_PLANS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<Plan | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const [formData, setFormData] = useState<Partial<Plan>>({
    name: '',
    price: 0,
    frequency: 'MONTHLY',
    assetLimit: 0,
    active: true,
    description: ''
  });

  const filteredPlans = plans.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenModal = (plan?: Plan) => {
    if (plan) {
      setEditingPlan(plan);
      setFormData(plan);
    } else {
      setEditingPlan(null);
      setFormData({
        name: '',
        price: 0,
        frequency: 'MONTHLY',
        assetLimit: 1,
        active: true,
        description: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || formData.price === undefined || !formData.assetLimit) {
      return alert('Campos obrigatórios: Nome, Preço e Limite de Caminhões');
    }

    if (editingPlan) {
      setPlans(prev => prev.map(p => p.id === editingPlan.id ? { ...p, ...formData } as Plan : p));
    } else {
      const newPlan: Plan = {
        ...formData,
        id: `p${Date.now()}`,
      } as Plan;
      setPlans(prev => [...prev, newPlan]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir este plano?')) {
      setPlans(prev => prev.filter(p => p.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Planos de Usabilidade</h1>
          <p className="text-slate-500">Gestão de pacotes, preços e limites de recursos</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors"
        >
          <Plus size={18} /> Novo Plano
        </button>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
         <div className="relative">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input 
               type="text" 
               placeholder="Buscar plano por nome..." 
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" 
             />
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPlans.map(plan => (
          <div key={plan.id} className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden flex flex-col transition-all hover:shadow-md hover:border-primary-200">
             <div className="p-6 flex-1">
                <div className="flex justify-between items-start mb-4">
                   <div className={clsx(
                       "w-12 h-12 rounded-full flex items-center justify-center",
                       plan.frequency === 'YEARLY' ? "bg-purple-50 text-purple-600" : "bg-blue-50 text-blue-600"
                   )}>
                      {plan.frequency === 'YEARLY' ? <Calendar size={24} /> : <CreditCard size={24} />}
                   </div>
                   {plan.active ? (
                     <span className="px-2 py-1 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-full flex items-center gap-1">
                        <CheckCircle size={12} /> Ativo
                     </span>
                   ) : (
                     <span className="px-2 py-1 bg-slate-100 text-slate-500 text-xs font-bold rounded-full flex items-center gap-1">
                        <XCircle size={12} /> Inativo
                     </span>
                   )}
                </div>
                
                <h3 className="text-xl font-bold text-slate-800 mb-1">{plan.name}</h3>
                <p className="text-slate-500 text-sm mb-6">{plan.description || 'Sem descrição.'}</p>
                
                <div className="flex items-baseline mb-4">
                   <span className="text-3xl font-bold text-slate-900">R$ {plan.price.toFixed(2).replace('.', ',')}</span>
                   <span className="text-slate-500 text-sm ml-2">/{plan.frequency === 'MONTHLY' ? 'mês' : 'ano'}</span>
                </div>
                
                <div className="border-t border-slate-50 pt-4 mt-2">
                   <div className="flex items-center gap-2 text-slate-600 mb-2">
                      <Truck size={18} className="text-primary-500" />
                      <span className="font-medium">{plan.assetLimit} Caminhões</span>
                   </div>
                   <div className="flex items-center gap-2 text-slate-600">
                      <Clock size={18} className="text-primary-500" />
                      <span className="font-medium">Cobrança {plan.frequency === 'MONTHLY' ? 'Mensal' : 'Anual'}</span>
                   </div>
                </div>
             </div>
             
             <div className="bg-slate-50 p-4 border-t border-slate-100 flex gap-3">
                <button 
                  onClick={() => handleOpenModal(plan)}
                  className="flex-1 py-2 rounded-lg bg-white border border-slate-200 text-slate-600 font-bold text-sm hover:bg-slate-100 hover:text-primary-600 transition-colors flex items-center justify-center gap-2"
                >
                   <Edit2 size={16} /> Editar
                </button>
                <button 
                  onClick={() => handleDelete(plan.id)}
                  className="flex-1 py-2 rounded-lg bg-white border border-red-100 text-red-500 font-bold text-sm hover:bg-red-50 transition-colors flex items-center justify-center gap-2"
                >
                   <Trash2 size={16} /> Excluir
                </button>
             </div>
          </div>
        ))}
        
        {/* Empty State Add Card */}
        <button 
           onClick={() => handleOpenModal()}
           className="border-2 border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center p-8 text-slate-400 hover:text-primary-600 hover:border-primary-300 hover:bg-primary-50 transition-all min-h-[300px]"
        >
           <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-4">
              <Plus size={32} />
           </div>
           <h3 className="font-bold text-lg">Criar Novo Plano</h3>
           <p className="text-sm">Defina limites e preços</p>
        </button>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg z-10 p-6 animate-scale-in">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-slate-800">{editingPlan ? 'Editar Plano' : 'Novo Plano'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome do Plano</label>
                <input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" placeholder="Ex: Básico, Avançado..." />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Frequência</label>
                    <div className="flex gap-2">
                       <button 
                         onClick={() => setFormData({...formData, frequency: 'MONTHLY'})}
                         className={clsx(
                             "flex-1 py-2 text-xs font-bold rounded-lg border transition-colors",
                             formData.frequency === 'MONTHLY' ? "bg-blue-50 border-blue-500 text-blue-700" : "border-slate-200 text-slate-600 hover:bg-slate-50"
                         )}
                       >
                           Mensal
                       </button>
                       <button 
                         onClick={() => setFormData({...formData, frequency: 'YEARLY'})}
                         className={clsx(
                             "flex-1 py-2 text-xs font-bold rounded-lg border transition-colors",
                             formData.frequency === 'YEARLY' ? "bg-purple-50 border-purple-500 text-purple-700" : "border-slate-200 text-slate-600 hover:bg-slate-50"
                         )}
                       >
                           Anual
                       </button>
                    </div>
                 </div>
                 <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Limite Caminhões</label>
                   <input type="number" value={formData.assetLimit} onChange={e => setFormData({...formData, assetLimit: Number(e.target.value)})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                </div>
              </div>
              
              <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Preço {formData.frequency === 'MONTHLY' ? 'Mensal' : 'Anual'} (R$)</label>
                   <input type="number" step="0.01" value={formData.price} onChange={e => setFormData({...formData, price: Number(e.target.value)})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Descrição</label>
                <textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 h-24 resize-none" placeholder="Breve descrição dos benefícios..." />
              </div>

              <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 flex items-center justify-between">
                 <div>
                    <h4 className="font-bold text-slate-800 text-sm">Status do Plano</h4>
                    <p className="text-xs text-slate-500">Disponível para venda?</p>
                 </div>
                 <div className="flex items-center gap-2">
                    <span className={clsx("text-xs font-bold", formData.active ? "text-emerald-600" : "text-slate-400")}>{formData.active ? 'Ativo' : 'Inativo'}</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" checked={formData.active} onChange={e => setFormData({...formData, active: e.target.checked})} className="sr-only peer" />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                    </label>
                 </div>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setIsModalOpen(false)} className="flex-1 py-2 text-slate-600 font-bold bg-slate-100 rounded-lg hover:bg-slate-200">Cancelar</button>
              <button onClick={handleSave} className="flex-1 py-2 text-white font-bold bg-primary-600 rounded-lg hover:bg-primary-700 flex items-center justify-center gap-2">
                 <Save size={18} /> Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
