
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, ArrowRight, Bell, ShieldCheck } from 'lucide-react';

export const WelcomePage: React.FC = () => {
  const navigate = useNavigate();

  const handleStart = () => {
    // Redireciona para configurar alertas antes de liberar o dashboard
    navigate('/alerts', { state: { fromWelcome: true } });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="max-w-2xl w-full bg-white rounded-3xl shadow-2xl overflow-hidden animate-scale-in flex flex-col md:flex-row">
        
        {/* Left Side (Visual) */}
        <div className="bg-[#001529] p-8 md:w-2/5 flex flex-col justify-between text-white relative overflow-hidden">
           <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white to-transparent"></div>
           <div>
              <div className="text-3xl font-black tracking-tighter mb-2">
                FR<span className="text-[#f97316]">O</span>TA
              </div>
              <p className="text-xs uppercase tracking-[0.3em] font-bold opacity-70">Inteligente</p>
           </div>
           <div className="relative z-10 mt-8">
              <h2 className="text-2xl font-bold mb-4">Bem-vindo a bordo!</h2>
              <p className="text-slate-300 text-sm leading-relaxed">
                Você está prestes a transformar a gestão de pneus da sua frota com dados precisos e controle total.
              </p>
           </div>
           <div className="mt-8 text-slate-400 text-xs">
              © 2024 DBI SaaS
           </div>
        </div>

        {/* Right Side (Content) */}
        <div className="p-8 md:w-3/5 flex flex-col justify-center">
           <div className="mb-6">
              <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-bold uppercase">Primeiro Acesso</span>
              <h1 className="text-3xl font-bold text-slate-800 mt-4 mb-2">Olá, Gestor!</h1>
              <p className="text-slate-500">Para garantir a segurança da sua operação, precisamos configurar as regras de alerta antes de prosseguir.</p>
           </div>

           <div className="space-y-4 mb-8">
              <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100">
                 <div className="bg-white p-2 rounded-lg shadow-sm text-orange-500">
                    <Bell size={20} />
                 </div>
                 <div>
                    <h3 className="font-bold text-slate-800 text-sm">Regras de Alerta</h3>
                    <p className="text-xs text-slate-500 mt-1">Defina limites de sulco, pressão e prazos de manutenção.</p>
                 </div>
              </div>
              <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100">
                 <div className="bg-white p-2 rounded-lg shadow-sm text-emerald-500">
                    <ShieldCheck size={20} />
                 </div>
                 <div>
                    <h3 className="font-bold text-slate-800 text-sm">Segurança Ativa</h3>
                    <p className="text-xs text-slate-500 mt-1">O sistema monitorará automaticamente a conformidade da frota.</p>
                 </div>
              </div>
           </div>

           <button 
             onClick={handleStart}
             className="w-full py-4 bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-bold text-lg shadow-lg shadow-primary-600/20 transition-all active:scale-95 flex items-center justify-center gap-2"
           >
             Iniciar Configuração <ArrowRight size={20} />
           </button>
        </div>

      </div>
    </div>
  );
};
