
import React, { useState } from 'react';
import { MOCK_COMPANY } from '../services/mockData';
import { Company } from '../types';
import { Save, Building, MapPin, Phone, Mail, User } from 'lucide-react';

export const CompanyProfilePage: React.FC = () => {
  const [company, setCompany] = useState<Company>(MOCK_COMPANY);
  const [formData, setFormData] = useState<Company>(MOCK_COMPANY);
  const [isEditing, setIsEditing] = useState(false);

  const handleSave = () => {
    setCompany(formData);
    setIsEditing(false);
    alert('Dados da empresa atualizados com sucesso!');
  };

  const handleChange = (section: keyof Company | 'address', field: string, value: string) => {
    if (section === 'address') {
      setFormData(prev => ({
        ...prev,
        address: {
          ...prev.address,
          [field]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Minha Empresa</h1>
          <p className="text-slate-500">Dados cadastrais da organização principal</p>
        </div>
        <div>
           {isEditing ? (
              <div className="flex gap-2">
                 <button 
                    onClick={() => { setIsEditing(false); setFormData(company); }}
                    className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600 font-bold hover:bg-slate-50"
                 >
                    Cancelar
                 </button>
                 <button 
                    onClick={handleSave}
                    className="px-4 py-2 bg-primary-600 text-white rounded-lg font-bold hover:bg-primary-700 flex items-center gap-2"
                 >
                    <Save size={18} /> Salvar Alterações
                 </button>
              </div>
           ) : (
              <button 
                onClick={() => setIsEditing(true)}
                className="px-4 py-2 bg-white border border-slate-200 text-primary-600 rounded-lg font-bold hover:bg-primary-50 hover:border-primary-200"
              >
                 Editar Dados
              </button>
           )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
         {/* General Info */}
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-50">
               <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center text-primary-600">
                  <Building size={20} />
               </div>
               <h3 className="font-bold text-slate-800 text-lg">Dados Corporativos</h3>
            </div>
            
            <div className="space-y-4">
               <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Razão Social</label>
                  <input 
                    type="text" 
                    value={formData.name} 
                    disabled={!isEditing}
                    onChange={(e) => handleChange('name', 'name', e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                  />
               </div>
               <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Fantasia</label>
                  <input 
                    type="text" 
                    value={formData.fantasyName} 
                    disabled={!isEditing}
                    onChange={(e) => handleChange('fantasyName', 'fantasyName', e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                  />
               </div>
               <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">CNPJ</label>
                  <input 
                    type="text" 
                    value={formData.cnpj} 
                    disabled={!isEditing}
                    onChange={(e) => handleChange('cnpj', 'cnpj', e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600 font-mono"
                  />
               </div>
            </div>
         </div>

         {/* Responsible Info */}
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-50">
               <div className="w-10 h-10 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-600">
                  <User size={20} />
               </div>
               <h3 className="font-bold text-slate-800 text-lg">Responsável e Contato</h3>
            </div>
            
            <div className="space-y-4">
               <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome do Responsável</label>
                  <input 
                    type="text" 
                    value={formData.responsibleName} 
                    disabled={!isEditing}
                    onChange={(e) => handleChange('responsibleName', 'responsibleName', e.target.value)}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                  />
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1 flex items-center gap-1"><Mail size={12}/> Email</label>
                      <input 
                        type="email" 
                        value={formData.responsibleEmail} 
                        disabled={!isEditing}
                        onChange={(e) => handleChange('responsibleEmail', 'responsibleEmail', e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                      />
                  </div>
                  <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1 flex items-center gap-1"><Phone size={12}/> Telefone</label>
                      <input 
                        type="text" 
                        value={formData.phone} 
                        disabled={!isEditing}
                        onChange={(e) => handleChange('phone', 'phone', e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                      />
                  </div>
               </div>
            </div>
         </div>

         {/* Address Info */}
         <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 lg:col-span-2">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-50">
               <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center text-purple-600">
                  <MapPin size={20} />
               </div>
               <h3 className="font-bold text-slate-800 text-lg">Endereço Principal</h3>
            </div>
            
            <div className="space-y-4">
               <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Logradouro</label>
                      <input 
                        type="text" 
                        value={formData.address.street} 
                        disabled={!isEditing}
                        onChange={(e) => handleChange('address', 'street', e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                      />
                  </div>
                  <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Número</label>
                      <input 
                        type="text" 
                        value={formData.address.number} 
                        disabled={!isEditing}
                        onChange={(e) => handleChange('address', 'number', e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                      />
                  </div>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Complemento</label>
                      <input 
                        type="text" 
                        value={formData.address.complement || ''} 
                        disabled={!isEditing}
                        onChange={(e) => handleChange('address', 'complement', e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                      />
                  </div>
                  <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Bairro</label>
                      <input 
                        type="text" 
                        value={formData.address.district} 
                        disabled={!isEditing}
                        onChange={(e) => handleChange('address', 'district', e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                      />
                  </div>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">CEP</label>
                      <input 
                        type="text" 
                        value={formData.address.zipCode} 
                        disabled={!isEditing}
                        onChange={(e) => handleChange('address', 'zipCode', e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                      />
                  </div>
                  <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Cidade</label>
                      <input 
                        type="text" 
                        value={formData.address.city} 
                        disabled={!isEditing}
                        onChange={(e) => handleChange('address', 'city', e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                      />
                  </div>
                  <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">UF</label>
                      <input 
                        type="text" 
                        value={formData.address.state} 
                        disabled={!isEditing}
                        onChange={(e) => handleChange('address', 'state', e.target.value)}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50 disabled:text-slate-600"
                      />
                  </div>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};
