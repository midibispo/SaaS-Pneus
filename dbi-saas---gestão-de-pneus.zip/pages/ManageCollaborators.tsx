
import React, { useState } from 'react';
import { MOCK_COLLABORATORS } from '../services/mockData';
import { Collaborator, Role } from '../types';
import { Plus, Edit2, Ban, Search, Save, X, CheckCircle, XCircle, Users, Power, Lock, Key } from 'lucide-react';
import { clsx } from 'clsx';

export const ManageCollaboratorsPage: React.FC = () => {
  const [collaborators, setCollaborators] = useState<Collaborator[]>(MOCK_COLLABORATORS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCollab, setEditingCollab] = useState<Collaborator | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Password state for new account creation
  const [password, setPassword] = useState('');

  const [formData, setFormData] = useState<Partial<Collaborator>>({
    name: '',
    cpf: '',
    email: '',
    phone: '',
    role: Role.MECHANIC,
    admissionDate: '',
    resignationDate: '',
    active: true,
    notes: ''
  });

  const filteredCollaborators = collaborators.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenModal = (collab?: Collaborator) => {
    setPassword(''); // Reset password field
    if (collab) {
      setEditingCollab(collab);
      setFormData(collab);
    } else {
      setEditingCollab(null);
      setFormData({
        name: '',
        cpf: '',
        email: '',
        phone: '',
        role: Role.MECHANIC,
        admissionDate: new Date().toISOString().split('T')[0],
        resignationDate: '',
        active: true,
        notes: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.email || !formData.cpf) return alert('Campos obrigatórios: Nome, CPF e Email');

    if (editingCollab) {
      setCollaborators(prev => prev.map(c => c.id === editingCollab.id ? { ...c, ...formData } as Collaborator : c));
    } else {
      // Logic for new user
      if (formData.email && password) {
          // Simulate account creation
          alert(`Conta de acesso criada com sucesso para ${formData.email}!\nPerfil: ${formData.role}`);
      }

      const newCollab: Collaborator = {
        ...formData,
        id: `col${Date.now()}`,
      } as Collaborator;
      setCollaborators(prev => [...prev, newCollab]);
    }
    setIsModalOpen(false);
  };

  const toggleStatus = (collab: Collaborator) => {
     if (collab.active) {
         // Deactivating
         const date = prompt("Informe a data de desativação (AAAA-MM-DD):", new Date().toISOString().split('T')[0]);
         if (date) {
            setCollaborators(prev => prev.map(c => c.id === collab.id ? { ...c, active: false, resignationDate: date } : c));
         }
     } else {
         // Reactivating
         if(confirm("Deseja reativar este colaborador?")) {
            setCollaborators(prev => prev.map(c => c.id === collab.id ? { ...c, active: true, resignationDate: undefined } : c));
         }
     }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Funcionários</h1>
          <p className="text-slate-500">Gestão de equipe e contas de acesso</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors shadow-sm shadow-primary-500/30"
        >
          <Plus size={18} /> Novo Colaborador
        </button>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
         <div className="relative">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input 
               type="text" 
               placeholder="Buscar por nome ou email..." 
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" 
             />
         </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left whitespace-nowrap">
            <thead className="bg-slate-50 text-xs text-slate-500 uppercase border-b border-slate-100">
                <tr>
                <th className="px-6 py-4">Colaborador</th>
                <th className="px-6 py-4">Função (Role)</th>
                <th className="px-6 py-4">Contato</th>
                <th className="px-6 py-4">Admissão / Saída</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Ações</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
                {filteredCollaborators.map(c => (
                <tr key={c.id} className={clsx("hover:bg-slate-50 transition-colors", !c.active && "bg-slate-50/50 opacity-70")}>
                    <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500">
                            <Users size={16} />
                        </div>
                        <div>
                            <p className="font-bold text-slate-800">{c.name}</p>
                            <p className="text-xs text-slate-500">{c.cpf}</p>
                        </div>
                    </div>
                    </td>
                    <td className="px-6 py-4">
                        <span className={clsx(
                            "px-2 py-1 rounded text-xs font-bold uppercase",
                            c.role === Role.ADMIN ? "bg-purple-100 text-purple-700" :
                            c.role === Role.MECHANIC ? "bg-orange-100 text-orange-700" : "bg-blue-100 text-blue-700"
                        )}>
                            {c.role === Role.ADMIN ? 'Gestor' : c.role === Role.MECHANIC ? 'Mecânico' : 'Auditor'}
                        </span>
                    </td>
                    <td className="px-6 py-4 text-slate-600">
                    <div className="text-xs">{c.email}</div>
                    <div className="text-xs">{c.phone}</div>
                    </td>
                    <td className="px-6 py-4 text-slate-600">
                    <div className="font-medium">{c.admissionDate}</div>
                    {c.resignationDate && <div className="text-xs text-red-500">Saiu: {c.resignationDate}</div>}
                    </td>
                    <td className="px-6 py-4">
                    {c.active ? (
                        <span className="flex items-center gap-1 text-emerald-600 text-xs font-bold"><CheckCircle size={14}/> Ativo</span>
                    ) : (
                        <span className="flex items-center gap-1 text-red-500 text-xs font-bold"><XCircle size={14}/> Inativo</span>
                    )}
                    </td>
                    <td className="px-6 py-4 text-right flex justify-end gap-2">
                    <button onClick={() => handleOpenModal(c)} className="text-blue-500 hover:text-blue-700 p-1" title="Editar"><Edit2 size={16} /></button>
                    <button 
                        onClick={() => toggleStatus(c)} 
                        className={clsx("p-1", c.active ? "text-red-500 hover:text-red-700" : "text-emerald-500 hover:text-emerald-700")}
                        title={c.active ? "Desativar" : "Reativar"}
                    >
                        <Power size={16} />
                    </button>
                    </td>
                </tr>
                ))}
            </tbody>
            </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg z-10 p-6 animate-scale-in max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-slate-800">{editingCollab ? 'Editar Colaborador' : 'Novo Colaborador'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Completo</label>
                <input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">CPF</label>
                    <input type="text" value={formData.cpf} onChange={e => setFormData({...formData, cpf: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Função (Perfil)</label>
                    <select 
                        value={formData.role} 
                        onChange={e => setFormData({...formData, role: e.target.value as Role})} 
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                    >
                        <option value={Role.ADMIN}>Gestor de Frota</option>
                        <option value={Role.MECHANIC}>Mecânico / Operacional</option>
                        <option value={Role.AUDITOR}>Auditor / Leitura</option>
                    </select>
                 </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email (Login)</label>
                    <input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Telefone</label>
                    <input type="text" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                 </div>
              </div>

              {/* Password Field - Only for new users or if we allowed reset here (mock only new) */}
              {!editingCollab && (
                  <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1 flex items-center gap-1">
                          <Lock size={12} /> Senha de Acesso
                      </label>
                      <input 
                        type="password" 
                        value={password} 
                        onChange={e => setPassword(e.target.value)} 
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" 
                        placeholder="Definir senha inicial..."
                      />
                      <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                          <Key size={10} /> Ao preencher email e senha, uma conta será criada automaticamente.
                      </p>
                  </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Data Admissão</label>
                    <input type="date" value={formData.admissionDate} onChange={e => setFormData({...formData, admissionDate: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Data Desligamento</label>
                    <input 
                        type="date" 
                        value={formData.resignationDate || ''} 
                        onChange={e => setFormData({...formData, resignationDate: e.target.value})} 
                        disabled={formData.active}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 disabled:bg-slate-50" 
                    />
                 </div>
              </div>
              
              <div>
                 <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Observações</label>
                 <textarea value={formData.notes || ''} onChange={e => setFormData({...formData, notes: e.target.value})} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 h-20 resize-none" />
              </div>

              <div className="flex items-center gap-2 mt-2">
                 <input type="checkbox" checked={formData.active} onChange={e => setFormData({...formData, active: e.target.checked})} className="w-5 h-5 text-primary-600 rounded" />
                 <label className="text-sm text-slate-700 font-medium">Colaborador Ativo</label>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setIsModalOpen(false)} className="flex-1 py-2 text-slate-600 font-bold bg-slate-100 rounded-lg hover:bg-slate-200">Cancelar</button>
              <button onClick={handleSave} className="flex-1 py-2 text-white font-bold bg-primary-600 rounded-lg hover:bg-primary-700 flex items-center justify-center gap-2">
                 <Save size={18} /> Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
