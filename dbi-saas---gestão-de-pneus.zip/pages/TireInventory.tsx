
import React, { useState, useMemo } from 'react';
import { User, TireStatus, TireCondition, Tire } from '../types';
import { MOCK_TIRES, MOCK_BRANDS } from '../services/mockData';
import { Plus, Download, Search, Package, Disc, Save, X } from 'lucide-react';
import { clsx } from 'clsx';

const TIRE_SIZES = [
  "275/80R22.5", "295/80R22.5", "315/80R22.5", "11R22.5", "12R22.5",
  "255/70R22.5", "215/75R17.5", "385/65R22.5", "385/55R22.5"
];

export const TireInventoryPage: React.FC<{ user: User }> = ({ user }) => {
  // Local state to simulate database
  const [tires, setTires] = useState<Tire[]>(MOCK_TIRES);
  
  // Tabs now filter by Condition within Stock
  const [activeTab, setActiveTab] = useState<'ALL_STOCK' | TireCondition.NEW | TireCondition.RETREADED>('ALL_STOCK');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false); // Closed by default

  // New Tire Form State (Simplified for Quick Stock Creation)
  const [formData, setFormData] = useState<Partial<Tire>>({
      serialNumber: '',
      brand: '',
      model: '',
      size: '295/80R22.5',
      status: TireStatus.STOCK,
      condition: TireCondition.NEW,
      lifeCount: 0,
      currentDepth: 16,
      purchaseCost: 0
  });

  const tireBrands = MOCK_BRANDS.filter(b => b.type === 'TIRE');

  // Base filter: Only STOCK tires from local state
  const stockTires = tires.filter(t => t.status === TireStatus.STOCK);

  // Derive available models from all mock tires for suggestions
  const availableModels = useMemo(() => {
    const models = new Set(tires.map(t => t.model));
    return Array.from(models).sort();
  }, [tires]);

  // Applied filter based on tab
  const filteredTires = stockTires.filter(t => {
     if (activeTab === 'ALL_STOCK') return true;
     return t.condition === activeTab;
  });

  const handleSaveTire = () => {
      if (!formData.serialNumber || !formData.brand || !formData.model) {
          alert("Campos obrigatórios: Fogo, Marca e Modelo.");
          return;
      }
      // Normalize model to uppercase
      const normalizedModel = (formData.model || '').trim().toUpperCase();
      
      const newTire: Tire = {
          id: `t-new-${Date.now()}`,
          serialNumber: formData.serialNumber || '',
          brand: formData.brand || '',
          model: normalizedModel,
          size: formData.size || '295/80R22.5',
          status: TireStatus.STOCK,
          condition: formData.condition || TireCondition.NEW,
          lifeCount: formData.lifeCount || 0,
          currentDepth: formData.currentDepth || 16,
          originalDepth: formData.currentDepth || 16,
          currentPressure: 0,
          accumulatedMileage: 0,
          location: 'Estoque',
          purchaseDate: new Date().toISOString().split('T')[0],
          purchaseCost: formData.purchaseCost || 0,
      };

      setTires(prev => [newTire, ...prev]);
      
      alert(`Pneu ${formData.serialNumber} (${normalizedModel}) cadastrado com sucesso no estoque!`);
      setIsAddModalOpen(false);
      
      // Reset form
      setFormData({
          serialNumber: '',
          brand: '',
          model: '',
          size: '295/80R22.5',
          status: TireStatus.STOCK,
          condition: TireCondition.NEW,
          lifeCount: 0,
          currentDepth: 16,
          purchaseCost: 0
      });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
           <h1 className="text-2xl font-bold text-slate-800">Estoque de Pneus</h1>
           <p className="text-slate-500">Gestão de pneus disponíveis no almoxarifado</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
            <button 
                onClick={() => setIsAddModalOpen(true)}
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors shadow-lg shadow-primary-500/20"
            >
               <Plus size={18} /> Cadastrar Pneu (Estoque)
            </button>
            <button className="px-3 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-600">
               <Download size={20} />
            </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-200">
         <nav className="-mb-px flex space-x-8 overflow-x-auto">
            {[
               { id: 'ALL_STOCK', label: 'Estoque Geral', icon: Package },
               { id: TireCondition.NEW, label: 'Pneus Novos', icon: Disc },
               { id: TireCondition.RETREADED, label: 'Pneus Recapados', icon: Disc },
            ].map(tab => (
               <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={clsx(
                     "whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors flex items-center gap-2",
                     activeTab === tab.id
                        ? "border-primary-500 text-primary-600"
                        : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
                  )}
               >
                  <tab.icon size={18} />
                  {tab.label}
                  <span className={clsx(
                      "ml-2 py-0.5 px-2 rounded-full text-xs",
                      activeTab === tab.id ? "bg-primary-50 text-primary-700" : "bg-slate-100 text-slate-600"
                  )}>
                     {tab.id === 'ALL_STOCK' 
                        ? stockTires.length 
                        : stockTires.filter(t => t.condition === tab.id).length}
                  </span>
               </button>
            ))}
         </nav>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4">
         <div className="relative flex-1">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input type="text" placeholder="Buscar por fogo, marca ou modelo..." className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" />
         </div>
         <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
             <select className="px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white outline-none focus:border-primary-500">
                <option>Todas as Medidas</option>
                <option>295/80R22.5</option>
                <option>275/80R22.5</option>
             </select>
         </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
         <div className="overflow-x-auto">
            <table className="w-full text-sm text-left whitespace-nowrap">
               <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-b border-slate-100">
                  <tr>
                     <th className="px-6 py-4">Fogo</th>
                     <th className="px-6 py-4">Marca / Banda</th>
                     <th className="px-6 py-4">Medida</th>
                     <th className="px-6 py-4">Condição</th>
                     <th className="px-6 py-4">Vida</th>
                     <th className="px-6 py-4">Localização</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                  {filteredTires.map(tire => (
                     <tr key={tire.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4 font-bold text-slate-800 font-mono">{tire.serialNumber}</td>
                        <td className="px-6 py-4 text-slate-600">
                           {tire.lifeCount === 0 ? tire.brand : (
                              <div className="flex flex-col">
                                 <span className="font-bold">{tire.treadBrand}</span>
                                 <span className="text-xs text-slate-400">Carcaça: {tire.brand}</span>
                              </div>
                           )}
                        </td>
                        <td className="px-6 py-4 text-slate-600">{tire.size}</td>
                        <td className="px-6 py-4">
                           <span className={clsx(
                              "px-2 py-1 rounded-full text-xs font-bold",
                              tire.condition === TireCondition.NEW ? "bg-emerald-50 text-emerald-700" : 
                              tire.condition === TireCondition.RETREADED ? "bg-blue-50 text-blue-700" : "bg-slate-100 text-slate-600"
                           )}>
                              {tire.condition}
                           </span>
                        </td>
                        <td className="px-6 py-4">
                           <div className="flex items-center gap-1">
                              <span className={clsx(
                                  "w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white",
                                  tire.lifeCount === 0 ? "bg-emerald-500" : "bg-blue-600"
                              )}>V{tire.lifeCount}</span>
                           </div>
                        </td>
                        <td className="px-6 py-4 text-slate-500">
                           {tire.location || 'Almoxarifado Central'}
                        </td>
                     </tr>
                  ))}
               </tbody>
            </table>
         </div>
         {filteredTires.length === 0 && (
             <div className="p-8 text-center text-slate-400">
                 Nenhum pneu encontrado no estoque com os filtros atuais.
             </div>
         )}
      </div>

      {/* QUICK ADD STOCK MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsAddModalOpen(false)}></div>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg z-10 p-6 animate-scale-in max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-slate-800">Cadastrar Pneu (Entrada Estoque)</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Número de Fogo</label>
                    <input 
                    type="text" 
                    value={formData.serialNumber}
                    onChange={e => setFormData({...formData, serialNumber: e.target.value})}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 font-mono"
                    />
                </div>
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Medida</label>
                    <select 
                        value={formData.size}
                        onChange={e => setFormData({...formData, size: e.target.value})}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                    >
                        {TIRE_SIZES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Marca</label>
                  <select 
                    value={formData.brand}
                    onChange={e => setFormData({...formData, brand: e.target.value})}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                  >
                    <option value="">Selecione...</option>
                    {tireBrands.map(b => <option key={b.id} value={b.name}>{b.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Modelo</label>
                  <input 
                    type="text" 
                    value={formData.model}
                    onChange={e => setFormData({...formData, model: e.target.value})}
                    list="tire-model-suggestions"
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 uppercase"
                    placeholder="DIGITE O MODELO..."
                  />
                  <datalist id="tire-model-suggestions">
                      {availableModels.map(m => <option key={m} value={m} />)}
                  </datalist>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Custo Compra (R$)</label>
                    <input 
                      type="number" 
                      value={formData.purchaseCost}
                      onChange={e => setFormData({...formData, purchaseCost: Number(e.target.value)})}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                    />
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Sulco Inicial (mm)</label>
                    <input 
                      type="number" 
                      value={formData.currentDepth}
                      onChange={e => setFormData({...formData, currentDepth: Number(e.target.value)})}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                    />
                 </div>
              </div>

              <div>
                 <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Status</label>
                 <div className="w-full px-3 py-2 bg-slate-100 rounded-lg text-slate-500 text-sm font-bold border border-slate-200">
                     Em Estoque (Padrão)
                 </div>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setIsAddModalOpen(false)} className="flex-1 py-2 text-slate-600 font-bold bg-slate-100 rounded-lg hover:bg-slate-200">Cancelar</button>
              <button onClick={handleSaveTire} className="flex-1 py-2 text-white font-bold bg-primary-600 rounded-lg hover:bg-primary-700 flex items-center justify-center gap-2">
                 <Save size={18} /> Cadastrar no Estoque
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
