
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Vehicle, Tire, TireStatus, TireCondition } from '../types';
import { MOCK_VEHICLES, MOCK_TIRES } from '../services/mockData';
import { VehicleSchematic } from '../components/VehicleSchematic';
import { ArrowLeft, Search, Save, RefreshCw, Trash2, ArrowRightLeft, Truck, AlertTriangle, Settings, Bus, Container, Plus, X, Calendar, Gauge, ArrowRight, CheckCircle, MousePointerClick, Disc, ShieldAlert } from 'lucide-react';
import { clsx } from 'clsx';

export const VehicleMapPage: React.FC<{ user: User }> = ({ user }) => {
  const navigate = useNavigate();
  
  // Local state to simulate database updates
  const [localTires, setLocalTires] = useState<Tire[]>(MOCK_TIRES);
  
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  
  // Selection States
  const [selectedPosition, setSelectedPosition] = useState<string | null>(null); // The position clicked
  const [sourceForRotation, setSourceForRotation] = useState<string | null>(null); // The source position during a move
  
  // Modals
  const [isMenuOpen, setIsMenuOpen] = useState(false); // The tire action menu
  const [isEmptySlotModalOpen, setIsEmptySlotModalOpen] = useState(false); // Choice: Stock or Rotate
  const [isStockPickerOpen, setIsStockPickerOpen] = useState(false); // List of stock tires
  const [isRetreadScrapModalOpen, setIsRetreadScrapModalOpen] = useState(false); // Removal modal
  const [isSelectSourceModalOpen, setIsSelectSourceModalOpen] = useState(false); // NEW: Select Source for Rotation

  // Removal State
  const [removalAction, setRemovalAction] = useState<'RETREAD' | 'SCRAP' | 'STOCK'>('STOCK');
  const [opDate, setOpDate] = useState(new Date().toISOString().split('T')[0]);
  const [opKm, setOpKm] = useState(0);
  const [removalReason, setRemovalReason] = useState('');

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | 'TRUCK' | 'TRAILER' | 'BUS'>('ALL');

  // Helper to get tire at position
  const getTireAt = (pos: string) => {
      if (!selectedVehicle) return undefined;
      return localTires.find(t => t.vehicleId === selectedVehicle.id && t.position === pos && t.status === TireStatus.INSTALLED);
  };

  // Helper Check Front Axle
  const isFrontAxle = (pos: string) => pos.startsWith('1');

  // --- HANDLERS ---

  const handleNodeClick = (tire: Tire | undefined, position: string) => {
      // CASE 1: Moving a tire (Target Selection) - Manual mode
      if (sourceForRotation) {
          if (sourceForRotation === position) {
              setSourceForRotation(null); // Cancel select
              return;
          }
          executeRotation(sourceForRotation, position);
          return;
      }

      // CASE 2: Clicking a filled slot (Open Action Menu)
      if (tire) {
          setSelectedPosition(position);
          setIsMenuOpen(true);
          return;
      }

      // CASE 3: Clicking an empty slot (Open Install/Move Choice)
      setSelectedPosition(position);
      setIsEmptySlotModalOpen(true);
  };

  const startRotation = () => {
      setSourceForRotation(selectedPosition);
      setIsMenuOpen(false);
  };

  const executeRotation = (sourcePos: string, targetPos: string) => {
      const sourceTire = getTireAt(sourcePos);
      const targetTire = getTireAt(targetPos);

      if (!sourceTire) return;

      // REGRA DE SEGURANÇA: Bloqueio de Recapados na Dianteira
      const isTargetFront = isFrontAxle(targetPos);
      const isSourceRetread = sourceTire.lifeCount > 0; // Life 0 = Novo, Life 1+ = Recapado

      // Validação Principal: Se destino é frente, origem tem que ser NOVO
      if (isTargetFront && isSourceRetread) {
          alert(`⛔ BLOQUEIO DE SEGURANÇA ⛔\n\nÉ PROIBIDO instalar pneus RECAPADOS (Vida ${sourceTire.lifeCount}) no EIXO DIANTEIRO.\nPosição Alvo: ${targetPos}\n\nOperação cancelada.`);
          setSourceForRotation(null);
          return;
      }

      // Validação Secundária (Swap): Se existe pneu no destino e estamos trocando
      // Verificamos se o pneu que sai do destino (se for recapado) vai para a frente (origem)
      if (targetTire) {
          const isSourceFront = isFrontAxle(sourcePos);
          const isTargetRetread = targetTire.lifeCount > 0;
          
          if (isSourceFront && isTargetRetread) {
              alert(`⛔ BLOQUEIO DE SEGURANÇA ⛔\n\nO pneu da posição de troca (${targetTire.serialNumber}) é RECAPADO e não pode ir para a DIANTEIRA.\n\nOperação cancelada.`);
              setSourceForRotation(null);
              return;
          }
      }

      // Perform Swap in Local State
      const updatedTires = localTires.map(t => {
          if (t.id === sourceTire.id) {
              return { ...t, position: targetPos };
          }
          if (targetTire && t.id === targetTire.id) {
              return { ...t, position: sourcePos };
          }
          return t;
      });

      setLocalTires(updatedTires);
      setSourceForRotation(null);
      
      // UX Feedback
      // alert("Movimentação realizada com sucesso."); 
  };

  const handleMountFromStock = (stockTire: Tire) => {
      if (!selectedVehicle || !selectedPosition) return;

      // REGRA DE SEGURANÇA: Bloqueio de Recapados na Dianteira
      if (isFrontAxle(selectedPosition) && stockTire.lifeCount > 0) {
          alert(`⛔ BLOQUEIO DE SEGURANÇA ⛔\n\nÉ PROIBIDO instalar pneus RECAPADOS (Vida ${stockTire.lifeCount}) no EIXO DIANTEIRO.\n\nSelecione um pneu NOVO (Vida 0).`);
          return;
      }

      // Update tire to Installed
      const updatedTires = localTires.map(t => {
          if (t.id === stockTire.id) {
              return { 
                  ...t, 
                  status: TireStatus.INSTALLED, 
                  vehicleId: selectedVehicle.id, 
                  position: selectedPosition,
                  location: selectedVehicle.plate 
              };
          }
          return t;
      });

      setLocalTires(updatedTires);
      setIsStockPickerOpen(false);
      setIsEmptySlotModalOpen(false);
  };

  const startRemoval = (action: 'RETREAD' | 'SCRAP' | 'STOCK') => {
      setRemovalAction(action);
      setOpKm(selectedVehicle?.odometer || 0);
      setIsRetreadScrapModalOpen(true);
      setIsMenuOpen(false);
  };

  const confirmRemoval = () => {
      const tire = getTireAt(selectedPosition!);
      if (!tire) return;

      const newStatus = removalAction === 'RETREAD' ? TireStatus.AWAITING_RETREAD : 
                        removalAction === 'SCRAP' ? TireStatus.SCRAP : TireStatus.STOCK;

      const updatedTires = localTires.map(t => {
          if (t.id === tire.id) {
              return {
                  ...t,
                  status: newStatus,
                  vehicleId: undefined,
                  position: undefined,
                  location: removalAction === 'STOCK' ? 'Estoque' : (removalAction === 'RETREAD' ? 'Aguardando Coleta' : 'Sucata'),
                  retreadSendDate: removalAction === 'RETREAD' ? opDate : undefined
              };
          }
          return t;
      });

      setLocalTires(updatedTires);
      setIsRetreadScrapModalOpen(false);
      alert(`Pneu ${tire.serialNumber} removido com sucesso.\nDestino: ${removalAction === 'RETREAD' ? 'Recapagem' : removalAction === 'SCRAP' ? 'Sucata' : 'Estoque'}`);
  };
  
  const handleOpenSourcePicker = () => {
      setIsEmptySlotModalOpen(false);
      setIsSelectSourceModalOpen(true);
  };
  
  const handleSelectSource = (sourcePos: string) => {
      if (!selectedPosition) return;
      executeRotation(sourcePos, selectedPosition);
      setIsSelectSourceModalOpen(false);
  };

  // Render logic for list
  const filteredVehicles = MOCK_VEHICLES.filter(v => {
    const matchesSearch = v.plate.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          v.model.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'ALL' || v.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  // Render Detail View
  if (selectedVehicle) {
      const currentVehicleTires = localTires.filter(t => t.vehicleId === selectedVehicle.id && t.status === TireStatus.INSTALLED);
      const stockTires = localTires.filter(t => t.status === TireStatus.STOCK); // Simple filter for picker

      return (
        <div className="animate-fade-in relative min-h-screen pb-20">
            {/* Header / Nav */}
            <div className="flex items-center justify-between mb-6">
                <button 
                    onClick={() => { setSelectedVehicle(null); setSourceForRotation(null); }}
                    className="flex items-center text-slate-500 hover:text-primary-600 transition-colors font-medium"
                >
                    <ArrowLeft size={20} className="mr-2" />
                    Voltar para Lista
                </button>
                {sourceForRotation && (
                    <div className="bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-bold animate-pulse shadow-lg flex items-center gap-2">
                        <MousePointerClick size={16} />
                        Selecione o local de destino
                        <button onClick={() => setSourceForRotation(null)} className="ml-2 bg-white/20 hover:bg-white/30 rounded-full p-1"><X size={14}/></button>
                    </div>
                )}
            </div>

            {/* Vehicle Info Card */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 mb-6">
                <div className="flex flex-col md:flex-row justify-between items-start gap-4">
                    <div>
                        <h2 className="text-3xl font-black text-slate-800">{selectedVehicle.plate}</h2>
                        <p className="text-slate-500 font-medium">{selectedVehicle.brand} {selectedVehicle.model} <span className="text-slate-300">|</span> {selectedVehicle.type}</p>
                    </div>
                    <div className="flex gap-6 bg-slate-50 p-3 rounded-xl border border-slate-100">
                        <div className="text-center">
                            <span className="text-[10px] uppercase font-bold text-slate-400 block">Odômetro</span>
                            <span className="text-lg font-bold text-slate-800">{selectedVehicle.odometer.toLocaleString()} km</span>
                        </div>
                        <div className="w-px bg-slate-200"></div>
                        <div className="text-center">
                            <span className="text-[10px] uppercase font-bold text-slate-400 block">Pneus</span>
                            <span className="text-lg font-bold text-primary-600">{currentVehicleTires.length}</span>
                        </div>
                    </div>
                </div>

                {/* SCHEMATIC */}
                <div className={clsx(
                    "mt-8 overflow-x-auto pb-4 transition-all duration-300 p-4 rounded-xl border-2 border-transparent",
                    sourceForRotation ? "bg-blue-50/50 border-blue-200 border-dashed" : ""
                )}>
                    {sourceForRotation && (
                        <p className="text-center text-blue-600 font-bold mb-4 text-sm">Clique em qualquer posição (vazia ou ocupada) para mover o pneu.</p>
                    )}
                    <VehicleSchematic 
                        vehicle={selectedVehicle} 
                        tires={currentVehicleTires}
                        onTireClick={handleNodeClick}
                    />
                </div>
            </div>

            {/* ACTION MENU MODAL (Filled Slot) */}
            {isMenuOpen && selectedPosition && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" onClick={() => setIsMenuOpen(false)}></div>
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm z-10 overflow-hidden animate-scale-in relative">
                        <button onClick={() => setIsMenuOpen(false)} className="absolute top-3 right-3 text-slate-400 hover:text-slate-600"><X size={20}/></button>
                        
                        <div className="p-5 border-b border-slate-100 bg-slate-50">
                            <h3 className="font-bold text-slate-800">Posição {selectedPosition}</h3>
                            <p className="text-xs text-slate-500 font-mono mt-1">
                               {getTireAt(selectedPosition)?.serialNumber} - {
                                   getTireAt(selectedPosition)?.lifeCount! > 0 
                                   ? <span className="font-bold text-slate-700">Recapado {getTireAt(selectedPosition)?.treadBrand}</span>
                                   : getTireAt(selectedPosition)?.brand
                               }
                            </p>
                        </div>
                        
                        <div className="p-4 grid grid-cols-1 gap-2">
                            <button onClick={startRotation} className="flex items-center gap-3 p-3 hover:bg-blue-50 rounded-lg text-left group transition-colors border border-transparent hover:border-blue-100">
                                <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                                    <ArrowRightLeft size={20} />
                                </div>
                                <div>
                                    <span className="block font-bold text-slate-700 group-hover:text-blue-700">Mover / Rodízio</span>
                                    <span className="text-xs text-slate-400">Trocar de lugar neste veículo</span>
                                </div>
                            </button>

                            <div className="h-px bg-slate-100 my-1"></div>

                            <button onClick={() => startRemoval('RETREAD')} className="flex items-center gap-3 p-3 hover:bg-orange-50 rounded-lg text-left group transition-colors border border-transparent hover:border-orange-100">
                                <div className="w-10 h-10 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center group-hover:bg-orange-600 group-hover:text-white transition-colors">
                                    <RefreshCw size={20} />
                                </div>
                                <div>
                                    <span className="block font-bold text-slate-700 group-hover:text-orange-700">Enviar para Recapagem</span>
                                    <span className="text-xs text-slate-400">Remover e enviar p/ reforma</span>
                                </div>
                            </button>

                            <button onClick={() => startRemoval('STOCK')} className="flex items-center gap-3 p-3 hover:bg-emerald-50 rounded-lg text-left group transition-colors border border-transparent hover:border-emerald-100">
                                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                                    <Disc size={20} />
                                </div>
                                <div>
                                    <span className="block font-bold text-slate-700 group-hover:text-emerald-700">Devolver ao Estoque</span>
                                    <span className="text-xs text-slate-400">Guardar pneu em boas condições</span>
                                </div>
                            </button>

                            <button onClick={() => startRemoval('SCRAP')} className="flex items-center gap-3 p-3 hover:bg-red-50 rounded-lg text-left group transition-colors border border-transparent hover:border-red-100">
                                <div className="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center group-hover:bg-red-600 group-hover:text-white transition-colors">
                                    <Trash2 size={20} />
                                </div>
                                <div>
                                    <span className="block font-bold text-slate-700 group-hover:text-red-700">Sucata / Descarte</span>
                                    <span className="text-xs text-slate-400">Fim de vida útil</span>
                                </div>
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* EMPTY SLOT MODAL */}
            {isEmptySlotModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setIsEmptySlotModalOpen(false)}></div>
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm z-10 p-6 animate-scale-in text-center">
                        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400 border-2 border-dashed border-slate-300">
                            <Settings size={32} />
                        </div>
                        <h3 className="text-lg font-bold text-slate-800 mb-2">Posição {selectedPosition} Vazia</h3>
                        <p className="text-slate-500 text-sm mb-6">O que deseja fazer com este espaço?</p>
                        
                        <div className="space-y-3">
                            <button 
                                onClick={() => { setIsEmptySlotModalOpen(false); setIsStockPickerOpen(true); }}
                                className="w-full py-3 bg-primary-600 text-white font-bold rounded-xl shadow-lg shadow-primary-500/30 hover:bg-primary-700 flex items-center justify-center gap-2"
                            >
                                <Disc size={20} /> Montar do Estoque
                            </button>
                            <button 
                                onClick={handleOpenSourcePicker}
                                className="w-full py-3 bg-white border-2 border-slate-100 text-slate-600 font-bold rounded-xl hover:border-primary-100 hover:text-primary-600 flex items-center justify-center gap-2"
                            >
                                <ArrowRightLeft size={20} /> Trazer de Outro Eixo
                            </button>
                        </div>
                        <button onClick={() => setIsEmptySlotModalOpen(false)} className="mt-4 text-xs text-slate-400 hover:text-slate-600 font-medium">Cancelar</button>
                    </div>
                </div>
            )}
            
            {/* SOURCE SELECTION MODAL (NEW POP-UP) */}
            {isSelectSourceModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsSelectSourceModalOpen(false)}></div>
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-md z-10 flex flex-col max-h-[80vh] animate-scale-in">
                        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50 rounded-t-xl">
                            <div>
                                <h3 className="font-bold text-slate-800">Selecione o Pneu de Origem</h3>
                                <p className="text-xs text-slate-500">Mover para posição vazia <strong>{selectedPosition}</strong></p>
                            </div>
                            <button onClick={() => setIsSelectSourceModalOpen(false)}><X size={20} className="text-slate-400" /></button>
                        </div>
                        <div className="overflow-y-auto p-2 space-y-1 bg-white flex-1">
                            {currentVehicleTires.length === 0 ? (
                                <div className="text-center py-10 text-slate-400">Não há pneus instalados para mover.</div>
                            ) : (
                                currentVehicleTires.sort((a,b) => a.position!.localeCompare(b.position!)).map(tire => (
                                    <button 
                                        key={tire.id} 
                                        onClick={() => handleSelectSource(tire.position!)}
                                        className="w-full text-left bg-white p-3 rounded-lg border border-slate-100 hover:border-primary-500 hover:bg-primary-50 cursor-pointer transition-all flex justify-between items-center group"
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 rounded bg-slate-100 flex items-center justify-center text-slate-600 font-bold text-xs border border-slate-200">
                                                {tire.position}
                                            </div>
                                            <div>
                                                <h4 className="font-bold text-slate-800 font-mono text-sm">{tire.serialNumber}</h4>
                                                <p className="text-xs text-slate-500">
                                                    {tire.lifeCount > 0 ? `Banda ${tire.treadBrand}` : tire.brand}
                                                </p>
                                            </div>
                                        </div>
                                        <ArrowRightLeft size={16} className="text-slate-300 group-hover:text-primary-600" />
                                    </button>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* STOCK PICKER MODAL */}
            {isStockPickerOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsStockPickerOpen(false)}></div>
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl z-10 flex flex-col max-h-[80vh] animate-scale-in">
                        <div className="p-4 border-b border-slate-100 flex justify-between items-center">
                            <h3 className="font-bold text-slate-800">Selecionar Pneu do Estoque</h3>
                            <button onClick={() => setIsStockPickerOpen(false)}><X size={20} className="text-slate-400" /></button>
                        </div>
                        <div className="overflow-y-auto p-4 space-y-3 bg-slate-50 flex-1">
                            {stockTires.length === 0 ? (
                                <div className="text-center py-10 text-slate-400">Estoque vazio. Cadastre pneus novos.</div>
                            ) : (
                                stockTires.map(tire => (
                                    <div key={tire.id} className="bg-white p-4 rounded-xl border border-slate-200 hover:border-primary-500 hover:shadow-md cursor-pointer transition-all flex justify-between items-center group" onClick={() => handleMountFromStock(tire)}>
                                        <div className="flex items-center gap-4">
                                            <div className={clsx(
                                                "w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xs",
                                                tire.lifeCount === 0 ? "bg-emerald-500" : "bg-blue-600"
                                            )}>
                                                V{tire.lifeCount}
                                            </div>
                                            <div>
                                                <h4 className="font-bold text-slate-800 font-mono">{tire.serialNumber}</h4>
                                                <p className="text-xs text-slate-500">
                                                    {tire.lifeCount > 0 
                                                        ? <span className="font-bold text-slate-700">Recapado {tire.treadBrand}</span>
                                                        : `${tire.brand} ${tire.model}`} 
                                                    <span className="ml-1 text-slate-400">- {tire.size}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div className="opacity-0 group-hover:opacity-100 text-primary-600 font-bold text-sm flex items-center gap-1 transition-opacity">
                                            Instalar <ArrowRight size={16} />
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* REMOVAL MODAL (Retread / Scrap) */}
            {isRetreadScrapModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsRetreadScrapModalOpen(false)}></div>
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg z-10 overflow-hidden animate-scale-in">
                        <div className={clsx(
                            "px-6 py-4 flex justify-between items-center text-white",
                            removalAction === 'RETREAD' ? "bg-orange-500" : 
                            removalAction === 'SCRAP' ? "bg-red-600" : "bg-emerald-600"
                        )}>
                            <h3 className="font-bold text-lg">
                                {removalAction === 'RETREAD' ? 'Enviar para Recapagem' : 
                                 removalAction === 'SCRAP' ? 'Confirmar Descarte' : 'Devolver ao Estoque'}
                            </h3>
                            <button onClick={() => setIsRetreadScrapModalOpen(false)} className="text-white/80 hover:text-white"><X size={24}/></button>
                        </div>
                        <div className="p-6 space-y-4">
                            <p className="text-sm text-slate-600">
                                Você está removendo o pneu <strong>{getTireAt(selectedPosition!)?.serialNumber}</strong> da posição <strong>{selectedPosition}</strong>.
                            </p>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Data</label>
                                    <input type="date" value={opDate} onChange={e => setOpDate(e.target.value)} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">KM Veículo</label>
                                    <input type="number" value={opKm} onChange={e => setOpKm(Number(e.target.value))} className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500" />
                                </div>
                            </div>

                            {removalAction !== 'STOCK' && (
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Motivo</label>
                                    <select className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white">
                                        <option>Desgaste Natural</option>
                                        <option>Dano Acidental</option>
                                        <option>Defeito de Fabricação</option>
                                    </select>
                                </div>
                            )}

                            <div className="flex gap-3 mt-4">
                                <button onClick={() => setIsRetreadScrapModalOpen(false)} className="flex-1 py-3 text-slate-600 font-bold bg-slate-100 rounded-xl hover:bg-slate-200">Cancelar</button>
                                <button onClick={confirmRemoval} className={clsx(
                                    "flex-1 py-3 text-white font-bold rounded-xl shadow-lg",
                                    removalAction === 'RETREAD' ? "bg-orange-500 hover:bg-orange-600 shadow-orange-500/20" : 
                                    removalAction === 'SCRAP' ? "bg-red-600 hover:bg-red-700 shadow-red-600/20" : "bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20"
                                )}>
                                    Confirmar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
      );
  }

  // --- LIST VIEW ---
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Mapa de Veículos</h1>
          <p className="text-slate-500">Selecione um veículo para inspecionar, realizar rodízio ou manutenção.</p>
        </div>
        <button 
            onClick={() => navigate('/manage-vehicles')}
            className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors shadow-sm"
        >
            <Plus size={18} /> Cadastrar Veículo
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Buscar por placa ou modelo..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm"
          />
        </div>
        <div className="flex gap-2">
           {['ALL', 'TRUCK', 'TRAILER', 'BUS'].map(cat => (
             <button 
               key={cat}
               onClick={() => setCategoryFilter(cat as any)}
               className={clsx(
                 "px-4 py-2 rounded-lg text-sm font-bold transition-colors",
                 categoryFilter === cat ? "bg-primary-600 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
               )}
             >
               {cat === 'ALL' ? 'Todos' : cat === 'TRUCK' ? 'Caminhões' : cat === 'TRAILER' ? 'Carretas' : 'Ônibus'}
             </button>
           ))}
        </div>
      </div>

      {/* Grid of Vehicles */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredVehicles.map(vehicle => {
           const tires = localTires.filter(t => t.vehicleId === vehicle.id && t.status === TireStatus.INSTALLED);
           return (
             <div 
               key={vehicle.id} 
               onClick={() => setSelectedVehicle(vehicle)}
               className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-all cursor-pointer group hover:border-primary-200"
             >
               <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                     <div className={clsx("w-10 h-10 rounded-lg flex items-center justify-center", 
                        vehicle.category === 'TRUCK' ? "bg-blue-50 text-blue-600" :
                        vehicle.category === 'TRAILER' ? "bg-amber-50 text-amber-600" : "bg-purple-50 text-purple-600"
                     )}>
                        {vehicle.category === 'TRUCK' ? <Truck size={20} /> : vehicle.category === 'TRAILER' ? <Container size={20} /> : <Bus size={20} />}
                     </div>
                     <div>
                        <h3 className="font-bold text-slate-800 text-lg group-hover:text-primary-600 transition-colors">{vehicle.plate}</h3>
                        <p className="text-xs text-slate-500">{vehicle.brand} - {vehicle.model}</p>
                     </div>
                  </div>
                  <span className={clsx("px-2 py-1 rounded text-[10px] font-bold uppercase", 
                     vehicle.status === 'ACTIVE' ? "bg-emerald-100 text-emerald-700" : "bg-orange-100 text-orange-700"
                  )}>
                     {vehicle.status === 'ACTIVE' ? 'Operacional' : 'Manutenção'}
                  </span>
               </div>
               
               <div className="flex items-center gap-4 text-sm text-slate-600 mb-4 bg-slate-50 p-3 rounded-lg">
                  <div>
                     <span className="block text-[10px] uppercase font-bold text-slate-400">Pneus Instalados</span>
                     <span className="font-bold">{tires.length}</span>
                  </div>
                  <div className="w-px h-8 bg-slate-200"></div>
                  <div>
                     <span className="block text-[10px] uppercase font-bold text-slate-400">Odômetro</span>
                     <span className="font-bold">{vehicle.odometer.toLocaleString()} km</span>
                  </div>
               </div>

               <button className="w-full py-2 bg-white border border-slate-200 rounded-lg text-primary-600 font-bold text-sm group-hover:bg-primary-50 group-hover:border-primary-100">
                  Gerenciar Pneus
               </button>
             </div>
           )
        })}
      </div>
    </div>
  );
};
