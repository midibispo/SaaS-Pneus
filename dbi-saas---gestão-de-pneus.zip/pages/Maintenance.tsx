
import React, { useState } from 'react';
import { MOCK_MAINTENANCE, MOCK_TIRES, MOCK_VEHICLES } from '../services/mockData';
import { MaintenanceRecord, MaintenanceType, Tire } from '../types';
import { Plus, Edit2, Trash2, Search, Save, X, Wrench, Clock, Calendar, FileText, Filter, MoreVertical, LayoutList, Disc, Truck } from 'lucide-react';
import { clsx } from 'clsx';

export const MaintenancePage: React.FC = () => {
  const [records, setRecords] = useState<MaintenanceRecord[]>(MOCK_MAINTENANCE);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<MaintenanceRecord | null>(null);
  
  // View State
  const [viewMode, setViewMode] = useState<'TABLE' | 'TIMELINE'>('TABLE');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('');

  const [formData, setFormData] = useState<Partial<MaintenanceRecord>>({
    tireId: '',
    vehicleId: '',
    date: new Date().toISOString().split('T')[0],
    type: MaintenanceType.INSPECTION,
    cost: 0,
    odometer: 0,
    description: '',
    performedBy: 'Usuário Atual'
  });

  const filteredRecords = records.filter(r => {
    const matchesSearch = r.tireId.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          r.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType ? r.type === filterType : true;
    return matchesSearch && matchesType;
  });

  // Group by Tire for Timeline View
  const recordsByTire = filteredRecords.reduce((acc, record) => {
      if (!acc[record.tireId]) acc[record.tireId] = [];
      acc[record.tireId].push(record);
      return acc;
  }, {} as Record<string, MaintenanceRecord[]>);

  const handleOpenModal = (record?: MaintenanceRecord) => {
    if (record) {
      setEditingRecord(record);
      setFormData(record);
    } else {
      setEditingRecord(null);
      setFormData({
        tireId: '',
        vehicleId: '',
        date: new Date().toISOString().split('T')[0],
        type: MaintenanceType.INSPECTION,
        cost: 0,
        odometer: 0,
        description: '',
        performedBy: 'Usuário Atual'
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formData.tireId || !formData.date || !formData.description) return alert('Campos obrigatórios: Pneu, Data e Descrição');

    if (editingRecord) {
      setRecords(prev => prev.map(r => r.id === editingRecord.id ? { ...r, ...formData } as MaintenanceRecord : r));
    } else {
      const newRecord: MaintenanceRecord = {
        ...formData,
        id: `m${Date.now()}`,
      } as MaintenanceRecord;
      setRecords(prev => [newRecord, ...prev]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir este registro de manutenção?')) {
      setRecords(prev => prev.filter(r => r.id !== id));
    }
  };

  const getTypeColor = (type: MaintenanceType) => {
      switch(type) {
          case MaintenanceType.INSPECTION: return 'bg-blue-100 text-blue-700';
          case MaintenanceType.PRESSURE: return 'bg-emerald-100 text-emerald-700';
          case MaintenanceType.REPAIR: return 'bg-red-100 text-red-700';
          case MaintenanceType.ROTATION: return 'bg-purple-100 text-purple-700';
          default: return 'bg-slate-100 text-slate-700';
      }
  };

  const getVehiclePlate = (vId?: string) => MOCK_VEHICLES.find(v => v.id === vId)?.plate || '-';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Registros de Manutenção</h1>
          <p className="text-slate-500">Histórico de intervenções técnicas, reparos e inspeções</p>
        </div>
        <div className="flex gap-2">
            <div className="flex bg-slate-100 p-1 rounded-lg">
                <button 
                    onClick={() => setViewMode('TABLE')}
                    className={clsx(
                        "px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2",
                        viewMode === 'TABLE' ? "bg-white shadow text-primary-600" : "text-slate-500 hover:text-slate-700"
                    )}
                >
                    <LayoutList size={16} /> Tabela
                </button>
                <button 
                    onClick={() => setViewMode('TIMELINE')}
                    className={clsx(
                        "px-3 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2",
                        viewMode === 'TIMELINE' ? "bg-white shadow text-primary-600" : "text-slate-500 hover:text-slate-700"
                    )}
                >
                    <Clock size={16} /> Linha do Tempo
                </button>
            </div>
            <button 
                onClick={() => handleOpenModal()}
                className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors shadow-sm"
            >
                <Plus size={18} /> Nova Manutenção
            </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4">
         <div className="relative flex-1">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input 
               type="text" 
               placeholder="Buscar por pneu (fogo) ou descrição..." 
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary-500 outline-none text-sm" 
             />
         </div>
         <div className="flex gap-2">
            <select 
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white outline-none focus:border-primary-500"
            >
               <option value="">Todos os Tipos</option>
               {Object.values(MaintenanceType)
                .filter(t => t !== MaintenanceType.RETREAD)
                .map(t => <option key={t} value={t}>{t}</option>)}
            </select>
         </div>
      </div>

      {viewMode === 'TABLE' ? (
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left whitespace-nowrap">
                <thead className="bg-slate-50 text-xs text-slate-500 uppercase border-b border-slate-100">
                    <tr>
                        <th className="px-6 py-4">Data</th>
                        <th className="px-6 py-4">Pneu (Fogo)</th>
                        <th className="px-6 py-4">Tipo Serviço</th>
                        <th className="px-6 py-4">Veículo</th>
                        <th className="px-6 py-4">Descrição</th>
                        <th className="px-6 py-4">Custo</th>
                        <th className="px-6 py-4 text-right">Ações</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {filteredRecords.map(record => (
                    <tr key={record.id} className="hover:bg-slate-50">
                        <td className="px-6 py-4 text-slate-600">
                            <div className="flex items-center gap-2">
                                <Calendar size={14} className="text-slate-400" />
                                {record.date}
                            </div>
                        </td>
                        <td className="px-6 py-4 font-bold text-slate-800 font-mono">{record.tireId}</td>
                        <td className="px-6 py-4">
                            <span className={clsx("px-2 py-1 rounded-full text-xs font-bold", getTypeColor(record.type))}>
                                {record.type}
                            </span>
                        </td>
                        <td className="px-6 py-4 text-slate-600">{getVehiclePlate(record.vehicleId)}</td>
                        <td className="px-6 py-4 text-slate-600 max-w-xs truncate" title={record.description}>{record.description}</td>
                        <td className="px-6 py-4 font-medium text-slate-800">
                            {record.cost > 0 ? `R$ ${record.cost.toFixed(2)}` : '-'}
                        </td>
                        <td className="px-6 py-4 text-right flex justify-end gap-2">
                            <button onClick={() => handleOpenModal(record)} className="text-blue-500 hover:text-blue-700 p-1"><Edit2 size={16} /></button>
                            <button onClick={() => handleDelete(record.id)} className="text-red-500 hover:text-red-700 p-1"><Trash2 size={16} /></button>
                        </td>
                    </tr>
                    ))}
                </tbody>
                </table>
            </div>
        </div>
      ) : (
        <div className="space-y-6">
            {Object.entries(recordsByTire).map(([tireId, tireRecords]: [string, MaintenanceRecord[]]) => (
                <div key={tireId} className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                        <h3 className="font-bold text-slate-800 flex items-center gap-2">
                            <Disc size={18} className="text-primary-600" /> Pneu {tireId}
                        </h3>
                        <span className="text-xs text-slate-500 bg-white px-2 py-1 rounded border border-slate-200">
                            {tireRecords.length} Registros
                        </span>
                    </div>
                    <div className="p-6 relative">
                         {/* Timeline Line */}
                         <div className="absolute left-9 top-6 bottom-6 w-0.5 bg-slate-200"></div>
                         
                         <div className="space-y-6">
                            {tireRecords.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(record => (
                                <div key={record.id} className="relative pl-10 flex flex-col sm:flex-row sm:items-start gap-4 group">
                                    {/* Dot */}
                                    <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-white border-2 border-primary-500 flex items-center justify-center z-10 group-hover:scale-110 transition-transform">
                                        <div className="w-2 h-2 bg-primary-500 rounded-full"></div>
                                    </div>
                                    
                                    <div className="flex-1">
                                        <div className="flex flex-wrap items-center gap-2 mb-1">
                                            <span className="text-sm font-bold text-slate-800">{record.date}</span>
                                            <span className={clsx("px-2 py-0.5 rounded text-[10px] font-bold uppercase", getTypeColor(record.type))}>
                                                {record.type}
                                            </span>
                                        </div>
                                        <p className="text-slate-600 text-sm mb-2">{record.description}</p>
                                        <div className="flex items-center gap-4 text-xs text-slate-400">
                                            <span className="flex items-center gap-1"><Wrench size={12} /> {record.performedBy}</span>
                                            {record.vehicleId && <span className="flex items-center gap-1"><Truck size={12} /> {getVehiclePlate(record.vehicleId)}</span>}
                                            {record.cost > 0 && <span className="font-bold text-slate-600">R$ {record.cost.toFixed(2)}</span>}
                                        </div>
                                    </div>
                                    
                                    <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                                        <button onClick={() => handleOpenModal(record)} className="p-1 text-blue-500 hover:bg-blue-50 rounded"><Edit2 size={14} /></button>
                                        <button onClick={() => handleDelete(record.id)} className="p-1 text-red-500 hover:bg-red-50 rounded"><Trash2 size={14} /></button>
                                    </div>
                                </div>
                            ))}
                         </div>
                    </div>
                </div>
            ))}
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg z-10 p-6 animate-scale-in max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                 <Wrench className="text-primary-600" size={20} />
                 {editingRecord ? 'Editar Manutenção' : 'Nova Manutenção'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Pneu (Fogo)</label>
                    <input 
                      type="text" 
                      value={formData.tireId}
                      onChange={e => setFormData({...formData, tireId: e.target.value})}
                      list="tire-list"
                      placeholder="Digite ou selecione"
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 font-mono"
                    />
                    <datalist id="tire-list">
                        {MOCK_TIRES.map(t => <option key={t.id} value={t.serialNumber} />)}
                    </datalist>
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Data</label>
                    <input 
                      type="date" 
                      value={formData.date}
                      onChange={e => setFormData({...formData, date: e.target.value})}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                    />
                 </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tipo de Serviço</label>
                    <select 
                       value={formData.type}
                       onChange={e => setFormData({...formData, type: e.target.value as MaintenanceType})}
                       className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                    >
                       {/* Filter out RETREAD as it should be handled in Lifecycle flow */}
                       {Object.values(MaintenanceType)
                        .filter(t => t !== MaintenanceType.RETREAD)
                        .map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Custo (R$)</label>
                    <input 
                      type="number" 
                      value={formData.cost}
                      onChange={e => setFormData({...formData, cost: Number(e.target.value)})}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                    />
                 </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Descrição Detalhada</label>
                <textarea 
                  value={formData.description}
                  onChange={e => setFormData({...formData, description: e.target.value})}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 h-24 resize-none"
                  placeholder="Descreva o serviço realizado..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Veículo (Opcional)</label>
                    <select 
                       value={formData.vehicleId || ''}
                       onChange={e => setFormData({...formData, vehicleId: e.target.value})}
                       className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500 bg-white"
                    >
                       <option value="">Nenhum / Em Estoque</option>
                       {MOCK_VEHICLES.map(v => <option key={v.id} value={v.id}>{v.plate}</option>)}
                    </select>
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Odômetro (Km)</label>
                    <input 
                      type="number" 
                      value={formData.odometer}
                      onChange={e => setFormData({...formData, odometer: Number(e.target.value)})}
                      className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                    />
                 </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Realizado Por</label>
                <input 
                    type="text" 
                    value={formData.performedBy}
                    onChange={e => setFormData({...formData, performedBy: e.target.value})}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 outline-none focus:border-primary-500"
                />
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setIsModalOpen(false)} className="flex-1 py-2 text-slate-600 font-bold bg-slate-100 rounded-lg hover:bg-slate-200">Cancelar</button>
              <button onClick={handleSave} className="flex-1 py-2 text-white font-bold bg-primary-600 rounded-lg hover:bg-primary-700 flex items-center justify-center gap-2">
                 <Save size={18} /> Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
